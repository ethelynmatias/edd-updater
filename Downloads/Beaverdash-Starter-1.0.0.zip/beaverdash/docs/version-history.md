
= 0.9.3 =

Release Date: 2019-11-02

- Field connections: Add course price custom URL for closed courses

= 0.9.2 =

Release Date: 2019-11-01

- Replace the existing progress bar with a customizable one
- Field connections: Add/Improve course price fields
- Field connections: Add course grid's addon field connections
- Field connection: Add course completed date
- Themer focus mode: body class logic - fix formatting issue
- Loop module base, User Loop module: Improve escaping config/value JSON, default settings connection
- Loops module base: Extending loop for content types other than posts
- Post Loop: Fix getting current post type for settings

= 0.8.2 =

Release Date: 2019-07-31

- BeaverLoops: Loop module base and item template builder
- Post Loop module with part types: heading, featured image, excerpt
- Improve Themer Extension: Focus Mode

= 0.8.1 =

Release Date: 2019-07-05

- Require PHP 7 and above
- Add settings to set the width of the video module
- Navigation and Mark Complete modules: Add the possibility to use the learndash 3.0 style
- Navigation and Mark Complete field connections: Use learndash 3.0 style if LearnDash 3.0 theme is used
- Breadcrumb module: Set the padding and the margin of the element to 0 by default
- Fix beaver builder's dock drag and drop issue

= 0.8.0 =

Release Date: 2019-07-02

- Improve support for LearnDash >= 3.0 and legacy
- Add BB modules: Breadcrumb, Course Price, Course Content Overview, User Profile, Focus Mode (User Dropdown, Sidebar Navigation)
- Add fields / field connections: Typography fields, Course Price, Colors (LD3 theme colors, course and post color), Lesson/Topic navigation
- Add Quizzes/Topics number by lesson
- Course content table: Add sections support
- Starting Beaver Loops modules: Post Loop module
- Improve modules: Video, Status
- Improve the LearnDash focus mode themer layout by providing templates in the builder (for header, content and sidebar)
- Themer extension: Add the possibility to edit the templates of the focus mode

= 0.7.3 =

Release Date: 2019-05-21

- Mark complete module: Add priority setting
- Field connections: Add timer countdown

= 0.7.2 =

Release Date: 2019-04-10

- Materials: Run shortcode in post context
- Fix filter for extending LD video providers

= 0.6.9 =

Release Date: 2019-03-12

- Add shortcodes and field connections: bdash_{course,lesson,topic,parent}_materials
- Add Materials module option "From post": current, parent, course, lesson, topic
- Improve getting topic quiz parents inside builder preview
- Video: Add filter `bdash_video_hosts` to support hosting video on CDNs
- Post Grid: Improve applying filter conditions and when not to apply
- Post grid modules: Support featured image with fixed sizes

= 0.6.7 =

Release Date: 2019-02-15

- Improve "smart links", sibling/previous/next logic
- Add shortcodes: bdash_{previous,next,parent}_id, bdash_has_{previous,next,parent}
- Improve getting course/lesson/topic/quiz ID when "shared steps" is enabled AND no permalink for parents (i.e.,  inside page builder)
- Navigation, expand/collapse: Set height auto for initially hidden child list, i.e., on next page
- Correct label for "Back to Course" nav button under all conditions
- Field connections: Move Labels group below Links

= 0.6.6 =

Release Date: 2019-02-14

- Post content: Fix getting lesson when unavailable due to drip date
- Post Grid modules: Pass global settings to CSS render for media query breakpoints

= 0.6.5 =

Release Date: 2019-02-12

- Post Grid: Follow existing orderby query

= 0.6.4 =

Release Date: 2019-02-05

- Solve issue with empty value getting escaped multiple times

= 0.6.3 =

Release Date: 2019-01-04

- Navigation: Improve prev/next, parent, sibling logic - especially when "shared steps" enabled
- Admin Settings: Option to make groups post type available on the frontend

= 0.6.2 =

Release Date: 2019-01-03

- Navigation: Use list tags (ol, li) by default
- Navigation: Expand item if current post is grand/child item
- Video: Option to show message if progression is incomplete
- Video: Improve CSS
- Content, Video: Consistent behavior for checking course progression and displaying message
- Admin notice - Persist dismiss state

= 0.6.1 =

Release Date: 2018-12-28

- Improve conditional logic UI
- Improve dependency check, admin notices
- Documentation: Search shortcodes

= 0.6.0 =

Release Date: 2018-12-24

- Course Navigation: Improve handling shortcode attributes

= 0.5.9 =

Release Date: 2018-12-20

- Add "Support" tab in plugin settings page
- Documentation: Shortcode parameters
- Improve support for Shared Course Steps
- Improve Post Grid, Navigation, Content Table modules

= 0.5.7 =

Release Date: 2018-12-15

- Featured Image module
- Video module: more style options
- Field connections: select current/other post
- Improve license de/activation process
- Improve debug logging

= 0.5.6 =

Release Date: 2018-12-07

- Documentation: Builder Modules, Field Connections, Shortcodes
- Progress Bar: Style and text options
- Mark Complete button: Improve button label preview

= 0.5.5 =

Release Date: 2018-12-05

- Conditional Logic UI: Fix for padding hiding input value in Firefox on some themes

= 0.5.4 =

Release Date: 2018-11-28

- Content Table: Status icons; Quiz/video/certificate indicators; Extend style options
- Course Nav: Current link style options; Improve live preview
- Start documentation; New plugin framework: updater, settings page
- Improve behavior when Beaver Builder not active

= 0.5.0 =

Release Date: 2018-11-19

- Conditional Logic UI
- Improvements in Visiblity options and Post Grid filters
- Improved support for Shared Course Steps
- New modules: Status, Materials
- Extended styling options for Course Navigation

= 0.4.4 =

Release Date: 2018-11-07

- Course Progress - Improve stats display when no lesson started
- Navigation button - Improve Smart link: Next

= 0.4.3 =

Release Date: 2018-11-01

- Improve logic for checking lesson status

= 0.4.2 =

Release Date: 2018-10-31

- Course/Lesson/Topic Content Table modules
- Course/Lesson/Topic/Quiz List modules
- Expand/collapse and pagination without Bootstrap dependency

= 0.4.1 =

Release Date: 2018-10-30

- Course/Lesson/Topic/Quiz/Certificate Grid modules
- Progress Bar module

= 0.4.0 =

Release Date: 2018-10-23

- Extensive re-organization and refactoring
- Course Navigation module: Current item class for topics/quizzes
- Visibility options: Move to its own menu, LearnDash Conditions
- Post grid filters: show only for LearnDash post types - course, lesson, topic, quiz, certificate
- Navigation button: Padding for icon

= 0.3.6 =

Release Date: 2018-10-06

- Course Content Table: Quiz List, Pagination, Expand/Collapse All
- Course Content Table: Content Options - Lessons, Topics, Course Quizzes
- Certificate: Link/URL, Post grid filters, Visibility, shortcodes and field connections

= 0.3.5 =

Release Date: 2018-09-21

- Progress Bar: Automatically detect IE/Edge compatibility mode

= 0.3.4 =

Release Date: 2018-09-21

- Progress Bar: Add IE/Edge compatibility mode for circle/semi-circle
- Progress Bar: Add text color option; text_color="555"

= 0.3.3 =

- Visibility: Show/hide on lesson/topic/quiz completion status
- Course Lessons: Add pagination
- Course Lessons: Show toggle only if lesson has topics
- Course Lessons: Option to allow only one panel to be open or not
- Course Content Table: Base structure and styles

= 0.3.2 =

Release Date: 2018-09-01

- Course materials: Handle case when materials field doesn't exist
- Course Progress: Handle cases when total or completed are empty
- Improve plugin settings link in admin

= 0.3.0 =

Release Date: 2018-08-29

- CSS & JS: Organize; enqueue styles early; prefix class names; support activation in builder, and multiple instances

Breaking changes:

- CSS class names have been updated to have consistent prefix `bdash-`
- Course Lessons: Removed style presets "basic" and "normal"

= 0.2.3 =

Release Date: 2018-08-23

- Course Navigation module
- Check compatibility with PHP 5.6

= 0.2.2 =

Release Date: 2018-08-17

- Nav Button: Display notice in builder if target item is not found
- Nav Button: Any parent
- Parent link shortcode/field connections: bdash_parent, bdash_parent_url, bdash_parent_title

= 0.2.1 =

Release Date: 2018-08-16

- Button module: Navigation
- Button module: Enroll
- Button module: Mark Complete

= 0.2.0 =

Release Date: 2018-08-15

- Stats: Exclude autoenrolled admin users by default
- Stats: Course Progress Percentage; bdash_course_progress_percent, bdash_course_progress_total, bdash_course_progress_completed
- Visibility: Previous/next item, lesson/topic/quiz
- Course Stats: bdash_course_quiz_pass_rate, bdash_course_quiz_certificate_award_rate
- Lesson Stats: bdash_lesson_order_number, bdash_lesson_status, bdash_lesson_progress, bdash_lesson_progress_{total,count}, bdash_lesson_completion_rate, bdash_lesson_completion_rate_{total,count}, bdash_lesson_quiz_pass_rate, bdash_lesson_quiz_attempt_rate, bdash_lesson_quiz_completion_rate, bdash_lesson_quiz_certificate_award_rate, bdash_lesson_quiz_certificate_award_rate_{total,count}
- Topic Stats: bdash_topic_order_number, bdash_topic_order_number_in_course, bdash_topic_status, bdash_topic_progress, bdash_topic_progress_{total,count}, bdash_topic_completion_rate, bdash_topic_completion_rate_{total,count}, bdash_topic_quiz_pass_rate, bdash_topic_quiz_attempt_rate, bdash_topic_quiz_completion_rate, bdash_topic_quiz_certificate_award_rate, bdash_topic_quiz_certificate_award_rate_{total,count}
- Quiz Stats: bdash_quiz_order_number, bdash_quiz_order_number_in_course, bdash_quiz_status, bdash_quiz_attempt_rate_{total,count}, bdash_quiz_pass_rate, bdash_quiz_completion_rate, bdash_quiz_certificate_award_rate, bdash_quiz_repeats, bdash_quiz_certificate_threshold, bdash_quiz_passing_percentage, bdash_quiz_time_limit, bdash_quiz_execute_once, bdash_quiz_average_score, bdash_quiz_score, bdash_quiz_leaderboard_enabled

= 0.1.9 =

Release Date: 2018-08-09

- Course Stats: Quiz pass rate; bdash_quiz_pass_rate
- Course Stats: Quiz certificate award rate; bdash_quiz_certificate_award_rate
- Course Stats: Course certificate award rate; bdash_course_certificate_award_rate
- Course Stats: Rate details - bdash_{course_completion,course_certificate_award,quiz_pass,quiz_certificate_award}_rate_{total,count}
- Create BeaverBuilder group "LearnDash Modules"
- Video Module: Add option "Fallback to featured image"

= 0.1.8 =

Release Date: 2018-08-08

- Visibility: Video Progression; Conditional shortcodes: bdash_video_progression_enabled, bdash_has_video
- bdash_video - Improve CSS for responsive video
- BeaverBuilder Module: Lesson/Topic Video
- Course Stats: bdash_number_of_lessons, bdash_number_of_topics, bdash_number_of_quizzes, bdash_number_of_students, bdash_course_has_certificate, bdash_course_points_enabled, bdash_course_completion_rate

= 0.1.7 =

Release Date: 2018-08-07

- Visibility: Lesson Progression; Conditional shortcode bdash_lesson_progression_enabled
- Visiblity: Course Status - started, in progress, completed; shortcodes and field connections: bdash_course_started, bdash_course_in_progress, bdash_course_completed
- Visiblity: Course Progress Threshold
- Visiblity: Enrolled Status - Show/hide if enrolled in any course

= 0.1.6 =

Release Date: 2018-08-02

- Progress bar: Support "load more" button and infinite scroll
- Post Grid: Improve handling of item classes for paged content
- Post Grid: Add filter "Limit by Enrollment"
- Visibility: Option to show/hide if "Hide Course Content Table" setting applies; Add conditional shortcode bdash_hide_content_table
- Improve previous/next navigation logic
- Improve mark complete button
- Improve handling of shortcode attributes

= 0.1.5 =

- Add URL fields as link connection
- Add shortcodes and field connections: bdash_next_url, bdash_next_title
- Add bdash_parent_topic_url, bdash_parent_topic_title
- Add bdash_previous, bdash_previous_url, bdash_previous_title
- Improve bdash_next

= 0.1.4 =

- Make sure all labels allow custom and translated
- Progression: Add module visibility options, shortcode conditions: bdash_can_progress, bdash_cannot_progress
- Post Grid: LearnDash Filters - Limit by availability, drip date, or progression
- Course lessons options - Limit by availability, drip date, or progression; Link to unavailable lessons or not
- Mark complete button - Add redirect options: parent-course, parent-lesson, parent-topic, self, next (default)
- Shortcodes and field connections: bdash_next_url, bdash_next_title
