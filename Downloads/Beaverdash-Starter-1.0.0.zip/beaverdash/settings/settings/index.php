<?php

namespace BeaverDash\Settings;

use BetterDash as bdash;
use Tangible\PluginFramework as framework;

function render_settings( $config ) {

  $beaverdash = beaverdash();
  $framework  = $beaverdash->framework;
  $plugin     = $beaverdash->plugin;

  $settings_key = $plugin->get_settings_key();
  $settings     = $plugin->get_settings();

  $public_groups_enabled = isset( $settings['enable_public_groups'] )
    && $settings['enable_public_groups'] === 'true';

  $public_groups_on_last_flush = isset( $settings['public_groups_on_last_flush'] )
    && $settings['public_groups_on_last_flush'] === 'true';

  if ( $public_groups_enabled !== $public_groups_on_last_flush ) {

    flush_rewrite_rules();

    $settings['public_groups_on_last_flush'] = $public_groups_enabled ? 'true' : 'false';

    $plugin->update_settings( $settings );

    $public_groups_on_last_flush = $public_groups_enabled;
  }

  ?>
  <div class="beaverdash-settings">

    <h3 style="margin-bottom: 25px">Settings</h3>
<?php
// Feature to make "groups" post type public - REMOVED
/*
    <div class="setting-row">
      <input type="hidden" name="<?= $settings_key ?>[public_groups_on_last_flush]" value="<?=
        $public_groups_on_last_flush ? 'true' : 'false'
      ?>">
      <?php
        $framework->render_setting_field([
          'type'  => 'checkbox',
          'name'  => "{$settings_key}[enable_public_groups]",
          'value' => @$settings['enable_public_groups'],
          'label' => 'Make the <code>groups</code> post type available on the frontend',
        ]);
      ?>
    </div>
*/
?>

    <?php
    submit_button();
    ?>

  </div><?php
}

// Feature to make "groups" post type public - REMOVED

// See: plugins/sfwd-lms/includes/ld-groups.php, learndash_groups_post_content()
/*add_filter('learndash-cpt-options', function ( $args, $post_type ) {

  // Temporary until framework is updated to use module loader
  $settings = framework\get_settings( beaverdash()->plugin );

  // Replace with:
  // $settings = beaverdash()->plugin->get_settings();

  $public_groups_enabled = isset( $settings['enable_public_groups'] )
    && $settings['enable_public_groups'] === 'true';

  if ( $post_type === 'groups' && $public_groups_enabled ) {

    $args = array_merge($args, [
      'public'             => true,
      'show_in_nav_menus'  => true,
      'has_archive'        => true,
      'publicly_queryable' => true,
    ]);

    $args['capabilities']['read_post'] = 'read_post';
  }

  return $args;

}, 10, 2);*/
