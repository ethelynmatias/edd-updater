<?php

namespace BeaverDash\Settings\Doc;

use BeaverDash as beaverdash;

function field_connections() {

  // See ../field-connections, ../utils/themer
  $groups = beaverdash()->state['themer_groups'];

  ?><div class="area"><h3 class="area-title">Field Connections</h3><?php

    $levels = [ 0 ]; // [index, index..]

foreach ( $groups as $group_title => $fields ) {

  $levels[0]++;
  $levels [] = 0;

  $section_title = str_replace( 'BeaverDash - ', '', $group_title );

  ?><div class="section" data-expand="false"><div class="section-title"><b><?= $section_title ?></b><span class="expand-toggle"></span></div><?php

foreach ( $fields as $field ) {

  if ($field['type'] === 'none') continue; // Conditional shortcode

  $levels[1]++;
  $levels [] = 0;

  ?><div class="part"><?php

    /*?><div class="part-title"><?= $field['label'] ?></div><?php*/
?><?= $field['label'] ?><br></div><?php
// Section part
  array_pop( $levels );
}

?></div><?php
// Section
  array_pop( $levels );
}

?><hr></div><?php
// Area
}
