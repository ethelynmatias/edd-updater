<?php

namespace BeaverDash\Settings;

use BetterDash as bdash;

require __DIR__ . '/builder-modules.php';
require __DIR__ . '/field-connections.php';
require __DIR__ . '/shortcodes.php';

function render_documentation() {

  ?>
  <div class="beaverdash-doc">
    <aside>
      <p>
        <input class="search-box" type="text" name="search_shortcode" placeholder="Search shortcodes..">
      </p>
    </aside>
    <main><?php

    Doc\builder_modules();
    Doc\field_connections();
    Doc\shortcodes();

    ?>
    </main>
  </div><?php
}
