<?php

namespace BeaverDash\Settings\Doc;

use BeaverDash as beaverdash;

function builder_modules() {

  if ( ! class_exists( 'FLBuilder' )) return;

  // See ../builder-modules
  foreach ( beaverdash()->state['module_groups'] as $group ) {
    builder_module_group( $group );
  }
}

function builder_module_group( $group ) {

  $group_name         = $group['name'];
  $group_prefix       = $group['prefix'];
  $modules_definition = $group['modules'];

  // Organize modules by category

  $sections = [];

  foreach ( $modules_definition as $slug ) {

    $slug = "$group_prefix-$slug";

    if ( ! isset( \FLBuilderModel::$modules[ $slug ] )) continue;
    $m = \FLBuilderModel::$modules[ $slug ];

    $category = $m->category;
    if ( ! isset( $sections[ $category ] )) $sections[ $category ] = [];

    $sections[ $category ] [] = [
      'name'        => $m->name,
      'description' => @$m->description,
    ];
  }

  ?><div class="area"><h3 class="area-title"><?= $group_name ?></h3><?php

    $levels = [ 0 ]; // [index, index..]

foreach ( $sections as $category => $modules ) {

  $levels[0]++;
  $levels [] = 0;

  ?><div class="section"><div class="section-title"><b><?= $category ?></b></div><?php

foreach ( $modules as $module ) {

  $levels[1]++;
  $levels [] = 0;

  ?><div class="part"><div class="part-title"><b><?= $module['name'] ?></b></div><?php

if ( ! empty( $module['description'] ) ) {
  ?><?= $module['description'] ?><?php
}

?></div><?php
// Section part
  array_pop( $levels );
}

?></div><?php
// Section
  array_pop( $levels );
}

?><hr></div><?php
// Area
}
