<?php

namespace BeaverDash\Settings\Doc;

use BetterDash as bdash;

function shortcodes() {

  $shortcode_definition = bdash\get_shortcode_groups();

  ?><div class="area area--shortcodes"><h3 class="area-title">Shortcodes</h3><?php

    $levels = [ 0 ]; // [index, index..]

  foreach ( $shortcode_definition as $section_title => $parts ) {

    $levels[0]++;
    $levels [] = 0;

    ?><div class="section" data-expand="false"><div class="section-title"><b><?= $section_title ?></b><span class="expand-toggle"></span></div><?php

    foreach ( $parts as $part_title => $items ) {

      $levels[1]++;
      $levels [] = 0;

      ?><div class="part"><div class="part-title"><b><?= $part_title ?></b></div><?php

      foreach ( $items as $item_definition ) {

        $levels[2]++;

        // Support definition object or string shorthand
        if ( is_string( $item_definition ) ) {
          $item_definition = [ 'name' => $item_definition ];
        }
        $name = $item_definition['name'];
        $atts = @$item_definition['attributes'];

        ?>
        <div class="item">
          <div class="item-name">
            <?= "bdash_{$name}" ?>
          </div>
          <?php

          if ( ! empty( $atts ) ) {

            ?><div class="item-attributes"><?php
            foreach ( $atts as $key => $value ) {
              ?>
              <div class="item-attribute">
                <code><?= $key ?></code> <?= $value ?>
              </div>
              <?php
            }
            ?></div><?php
          }
          ?>
        </div><?php
        // Item
      }

      ?></div><?php
      // Section part
      array_pop( $levels );
    }

    ?></div><?php

    array_pop( $levels );
  }

  ?></div><?php
}
