<?php

namespace BeaverDash\Settings;

require __DIR__ . '/doc/index.php';
require __DIR__ . '/admin-notice.php';
require __DIR__ . '/settings/index.php';

function settings_title_callback( $plugin, $tabs, $active_tab ) {
  ?>
    <div class="beaverdash-logo"><?php include __DIR__ . '/assets/logo.svg'; ?></div>
    <?= $plugin['title'] ?>
  <?php
}
