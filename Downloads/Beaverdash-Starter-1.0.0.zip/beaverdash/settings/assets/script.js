jQuery(document).ready(function($) {
  // Expand/collapse sections

  var $toggles = $('.section[data-expand] .section-title')

  $toggles.on('click', function() {
    var $el = $(this)
    var $section = $el.closest('.section')
    var $area = $el.closest('.area')

    // Note: Use attr instead of data(), for styling to apply
    $section.attr(
      'data-expand',
      $section.attr('data-expand') === 'true' ? 'false' : 'true'
    )
  })

  // Search shortcodes

  var $doc = $('.beaverdash-doc')
  if (!$doc.length) return

  var $searchBox = $doc.find('.search-box')
  var $shortcodesArea = $doc.find('.area--shortcodes')
  var $otherAreas = $doc.find('.area:not(.area--shortcodes)')

  var $shortcodeSections = $shortcodesArea.find('.section')

  // Build search map

  var searchMap = {
    sections: []
  }

  $shortcodeSections.each(function() {
    var $section = $(this)
    var parts = []

    $section.find('.part').each(function() {
      var $part = $(this)
      var items = []

      $part.find('.item').each(function() {
        var $item = $(this)

        items.push({
          $el: $item,
          text: $item
            .text()
            .trim()
            .toLowerCase()
        })
      })

      parts.push({
        $el: $part,
        title: $part
          .find('.part-title')
          .text()
          .trim()
          .toLowerCase(),
        items: items
      })
    })

    searchMap.sections.push({
      $el: $section,
      title: $section
        .find('.section-title')
        .text()
        .trim()
        .toLowerCase(),
      parts: parts
    })
  })

  // Prevent form submit
  $searchBox.on('keypress', function(e) {
    var keyCode = e.keyCode || e.which
    if (keyCode === 13) {
      e.preventDefault()
      return false
    }
  })

  $searchBox.on('keyup', function(e) {
    e.preventDefault()

    var val = $(this).val()

    if (!val) {
      $shortcodeSections.find('.part,.item').removeClass('hide')
      $shortcodeSections.removeClass('hide')
      showAllAreas()
      return false
    }

    var searchTerms = val.toLowerCase().split(' ')

    showShortcodeArea()

    $.each(searchMap.sections, function(sectionIndex, section) {
      var showSection = matchesAllTerms(searchTerms, section.title)

      if (showSection) {
        // Show all parts and items
        $.each(section.parts, function(partIndex, part) {
          $.each(part.items, function(itemIndex, item) {
            item.$el.removeClass('hide')
          })
          part.$el.removeClass('hide')
        })

        section.$el.removeClass('hide')
        return
      }

      $.each(section.parts, function(partIndex, part) {
        var showPart = matchesAllTerms(searchTerms, part.title)

        if (showPart) {
          showSection = true
          $.each(part.items, function(itemIndex, item) {
            item.$el.removeClass('hide')
          })
          part.$el.removeClass('hide')
          return
        }

        $.each(part.items, function(itemIndex, item) {
          var showItem = matchesAllTerms(searchTerms, item.text)

          if (showItem) {
            showSection = true
            showPart = true
          }

          item.$el[showItem ? 'removeClass' : 'addClass']('hide')
        })

        part.$el[showPart ? 'removeClass' : 'addClass']('hide')
      })

      section.$el[showSection ? 'removeClass' : 'addClass']('hide')
    })

    return false
  })

  function showAllAreas() {
    $otherAreas.removeClass('hide')
    $shortcodesArea.removeClass('hide')
    $shortcodeSections.attr('data-expand', 'false')
  }

  function showShortcodeArea() {
    $otherAreas.addClass('hide')
    $shortcodesArea.removeClass('hide')
    $shortcodeSections.attr('data-expand', 'true')
  }

  function matchesAllTerms(needles, haystack) {
    var matchesAll = true

    if (typeof needles === 'string') needles = [needles]

    $.each(needles, function(i, needle) {
      if (!matchesAll) return
      matchesAll = haystack.indexOf(needle) !== -1
    })

    return matchesAll
  }
})
