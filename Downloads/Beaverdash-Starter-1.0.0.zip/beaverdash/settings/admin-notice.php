<?php

namespace BeaverDash\Settings;

use Tangible\PluginFramework as framework;

function admin_notice( $plugin ) {

  $welcome_notice_key = 'beaverdash_welcome_notice';

  if ( ! framework\is_admin_notice_dismissed( $welcome_notice_key ) ) {
    ?>
    <div class="notice notice-info is-dismissible"
      data-tangible-admin-notice="<?= $welcome_notice_key ?>"
    >
      <p>Welcome to <?= $plugin['title'] ?>! Make sure to take a look at our list of recommended plugins.</p>
      <p><a href="<?= framework\get_settings_page_url( $plugin, 'recommend' ) ?>">See our recommendations &raquo;</a></p>
    </div>
    <?php
  }

  if ( ! framework\has_valid_license( $plugin ) ) {
    ?>
    <div class="notice notice-error">
      <p>Please <a href="<?= framework\get_settings_page_url( $plugin, 'license' ) ?>">enter your license key</a> to enable plugin updates for <?= $plugin['title'] ?>.</p>
    </div>
    <?php
  }
}
