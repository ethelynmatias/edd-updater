<?php

/**
 * To run these tests, use shortcode: [ttester beaverdash]
 */

?><h1>BeaverDash - Starter Edition</h1><?php

$tgbl = tgbl(); // Tangible plugin framework

$tester = tangible_tester(); // Tester module

use BeaverDash\Settings\Doc as doc;

?>
<div class="beaverdash-doc">
  <main><?php

  doc\builder_modules();
  doc\field_connections();
  doc\shortcodes();

  ?>
  </main>
</div><?php
