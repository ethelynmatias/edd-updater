<?php

namespace BeaverDash;

use BetterDash as bdash;

/**
 * Allow us to modify the LD3 focus mode as a themer layout
 *
 * @see https://kb.wpbeaverbuilder.com/article/389-add-header-footer-and-parts-support-to-your-theme-themer
 */

// If Beaver Themer is activate and if LearnDash >= 3.0.0
if ( class_exists( 'FLThemeBuilderLoader' ) && bdash\utils\is_ld3() ) {

    // Register the template part
    include __DIR__ . '/register.php';

}
