<?php

namespace BeaverDash;

use BetterDash as bdash;

add_theme_support( 'fl-theme-builder-parts' );

require __DIR__ . '/hooks/fields.php';
require __DIR__ . '/hooks/builder.php';
require __DIR__ . '/hooks/custom.php';
require __DIR__ . '/hooks/render.php';
