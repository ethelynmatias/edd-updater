jQuery(function() {
  let d = document
  let $ = jQuery

  if (d.getElementsByClassName('bdash-is-focus-builder')[0]) {
    let bdashBody = d.getElementsByTagName('body')[0]
    let bdashAdminBar = d.getElementById('wpadminbar')

    bdashBody.appendChild(bdashAdminBar)
  }

  if (d.getElementById('bdash-sidebar-builder')) {
    removeThemeElements('ld-focus-sidebar')
  }

  if (d.getElementById('bdash-content-builder')) {
    removeThemeElements('ld-focus-content')
  }

  if (d.getElementById('bdash-header-builder')) {
    removeThemeElements('bdash-focus-header')
  }

  function removeThemeElements(className) {
    let onlyBeaverContent = false

    let title = false

    while (!onlyBeaverContent) {
      let element = d.getElementsByClassName(className)[0]
      let child = element.firstChild

      if ($(child).hasClass('fl-builder-content')) {
        onlyBeaverContent = true
        if (title !== false) {
          title.textContent = titleText
          element.insertBefore(title, element.firstChild)
        }
      } else {
        if (child.tagName === 'H1') {
          title = child
          titleText = child.textContent
        }

        if (child.firstChild === null) {
          child.parentNode.removeChild(child)
        } else {
          $(child.firstChild).unwrap()
        }
      }
    }
  }
})
