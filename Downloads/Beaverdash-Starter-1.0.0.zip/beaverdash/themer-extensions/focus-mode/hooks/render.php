<?php

namespace BeaverDash;

use BetterDash as bdash;

/**
 *  Changelog of the LearnDash 3.0.3 say:
 *  "Updated the template override logic to work better with new templates"
 *  Right version? TODO: check
 *
 *  @see https://www.learndash.com/changelog/
 */
$hook_name = bdash\utils\is_version_lower( '3.0.3' ) ? 'learndash_30_get_template_part' : 'learndash_template';

/**
 * Remplace the original template by our template (if needed)
 * for allowing us to customize the header, the sidebar or the
 * footer
 *
 * For the content, we are using another method because LearnDash
 * don't use a template for that
 *
 * @see  templates/content.php
 */
add_filter( $hook_name, function( $filepath ) {

  if ( has_action( 'bdash_focus_header', false ) ) {
    if ( $filepath === LD_30_TEMPLATE_DIR . 'focus/masthead.php' ) {
        $filepath = BeaverDash_DIR . 'themer-extensions/focus-mode/templates/header.php';
    }
  }

  if ( has_action( 'bdash_focus_sidebar', false ) ) {
    if ( $filepath === LD_30_TEMPLATE_DIR . 'focus/sidebar.php' ) {
        $filepath = BeaverDash_DIR . 'themer-extensions/focus-mode/templates/sidebar.php';
    }
  }

  if ( has_action( 'bdash_focus_content', false ) ) {
      include BeaverDash_DIR . 'themer-extensions/focus-mode/templates/content.php';
  }

    return $filepath;

}, 10, 1);


/**
 * Enqueue the css needed for the focus parts
 */
add_action( 'wp_enqueue_scripts', function() {

    $url = BeaverDash_URL . 'themer-extensions/focus-mode/css/';
    wp_enqueue_style( 'bdash-focus-mode-css', $url . 'bdash-focus-mode.css' );

}, 10, 1 );
