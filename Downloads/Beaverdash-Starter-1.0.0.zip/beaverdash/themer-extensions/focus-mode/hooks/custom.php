<?php

namespace BeaverDash;

use BetterDash as bdash;

add_action( 'wp_enqueue_scripts', function() {

    // Only buffer output for builder
    if ( ! \FLBuilderModel::is_builder_active()) return;

    /**
     * Can cause unexcepted conflicts with other plugins in AJAX
     * (Display HTML/scripts tag before the JSON response)
     *
     * @see https://app.asana.com/0/958969759287428/1131915704101734/f
     */
    if (defined( 'DOING_AJAX' ) && DOING_AJAX) return;

    ob_start();

    /**
     * Get the whole output from WordPress and allow us to modify
     * it before displaying the final HTML
     */
    add_action('shutdown', function() {

      $final = ob_get_clean();

      // NOTE: This was breaking some pages with page builder

      // $final = '';

      // // We'll need to get the number of ob levels we're in, so that we can iterate over each, collecting
      // // that buffer's output into the final output.
      // $levels = ob_get_level();

      // for ( $i = 0; $i < $levels; $i++ ) {
      //   $final .= ob_get_clean();
      // }

      // Apply any filters to the final output
      echo apply_filters( 'bdash-themer-final-output', $final );

    }, 10 ** 19); // Important

}, 1, 1 );
