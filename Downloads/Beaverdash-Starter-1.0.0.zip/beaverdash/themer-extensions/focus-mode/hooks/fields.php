<?php

namespace BeaverDash;

use BetterDash as bdash;

/**
 * Add a themer layout for the LD3 focus mode (we could add more
 * themer part in the future)
 *
 * @see sfwd/themes/ld30/templates/focus/index.php
 */
add_filter( 'fl_theme_builder_part_hooks', function( $parts ) {

    $parts[] = [
        'label' => 'Focus Mode',
        'hooks' => [
            /*'learndash-focus-masthead-before' => 'Before Header',*/
            'bdash_focus_header'  => 'Header',
            /*'learndash-focus-masthead-after' => 'After Header',*/
            'bdash_focus_sidebar' => 'Sidebar',
            /*
            'learndash-focus-content-title-before' => 'Before Title',*/
            /*'learndash-focus-content-content-before' => 'Before Content',*/
            'bdash_focus_content' => 'Content',
            /*
            'learndash-focus-content-content-after' => 'After Content',*/
            /*
            'learndash-focus-content-comments-before' => 'Before comments',*/
            /*
            'learndash-focus-content-comments-after' => 'After comments',*/
            /*'learndash-focus-content-footer-before' => 'Footer',*/
        ],
    ];

    return $parts;

}, 99, 1);
