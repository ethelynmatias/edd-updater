<?php

namespace BeaverDash;
use BetterDash as bdash;

/**
 * When we are on the builder side, add the right template
 * according to the current themer part
 */
add_action('wp_enqueue_scripts', function() {

  if ( !\FLBuilderModel::is_builder_active()) return;

  /**
   * Custom filter
   *
   * @see  custom.php
   */
  add_filter('bdash-themer-final-output', function($output) {

    if (defined('DOING_AJAX') && DOING_AJAX) return $output;

    global $post;
    $hook = \get_post_meta ($post->ID, '_fl_theme_layout_hook', false );

    if (empty($hook)) return $output;

    ob_start();
    switch($hook[0]) {
      case 'bdash_focus_sidebar':
        include BeaverDash_DIR . 'themer-extensions/focus-mode/templates/sidebar-builder.php';
        break;
      case 'bdash_focus_header':
        include BeaverDash_DIR . 'themer-extensions/focus-mode/templates/header-builder.php';
        break;
      case 'bdash_focus_content':
        include BeaverDash_DIR . 'themer-extensions/focus-mode/templates/content-builder.php';
        break;
    }
    $content = ob_get_clean();

    if (empty($content)) return $output;

    /**
     * In the initial content, we will hide the current html and display our template instead
     */

    /**
     * TODO: Try to use DOMDocument class instead of the regex (more reliable)
     */

    // Remove HTML comments for avoiding issues (if a <body> is commented for exemple)
    $output = preg_replace('/<!--(.|\s)*?-->/', '', $output);
    $content = preg_replace('/<!--(.|\s)*?-->/', '', $content);

    // Add our content + open a tag for hiding the rest of the HTML
    preg_match("/<body[^>]*>/", $output, $matches);
    $new_html_start = (string) $matches[0] . $content . '<section style="display: none !important">';
    $output = preg_replace("/<body[^>]*>/", $new_html_start, $output);

    // Close the tag
    preg_match("/<\/body>/", $output, $matches);
    $new_html_end = (string) '</section>' . $matches[0];
    $output = preg_replace("/<\/body>/", $new_html_end, $output);

    return $output;

  }, 10, 1 );


  /**
   * Script for moving out the admin bar from the hidden section
   * and css specific to the builder
   */
  $url = BeaverDash_URL . 'themer-extensions/focus-mode/';
  wp_enqueue_style( 'bdash-focus-mode-builder-css', $url . "css/bdash-focus-mode-builder.css"  );
  wp_enqueue_script( 'bdash-focus-mode-builder-js', $url . "js/bdash-focus-mode-builder.js", array('jquery') );

}, 1 );


/**
 * Add focus class on the body when we are in builder mode
 * and a custom class (for the js)
 */
add_filter('body_class', function( $classes ) {

  if ( \FLBuilderModel::is_builder_active() ) {

    $layouts = \FLThemeBuilderLayoutData::get_current_page_layouts();

    if (!empty($layouts) && array_key_exists('part', $layouts) && !empty($layouts['part'])) {
      foreach ( $layouts['part'] as $part ) {
        if ( in_array($part['hook'], ['bdash_focus_sidebar', 'bdash_focus_content', 'bdash_focus_header']) ) {
          $classes[] = 'ld-in-focus-mode';
          $classes[] = 'bdash-is-focus-builder';
        }
      }
    }
  }

    return $classes;
} );
