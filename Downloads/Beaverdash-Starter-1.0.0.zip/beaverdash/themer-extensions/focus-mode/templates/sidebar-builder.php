<?php

use BetterDash as bdash;

/**
 * @see  sfwd-lms/themes/ld30/templates/focus/index.php
 */

$course_id = bdash\course_id();
$user_id   = get_current_user_id();
?>
    
<div id='bdash-sidebar-builder' class='learndash-wrapper'>
    <div class='ld-focus'>
        <?php do_action( 'learndash-focus-sidebar-before', $course_id, $user_id ); ?>
        <div class='ld-focus-sidebar'>
            <?php \FLThemeBuilderLayoutRenderer::render_content(); ?>
        </div>
        <div class="ld-focus-main">
            <?php do_action( 'learndash-focus-masthead-before', $course_id, $user_id ); ?>               
            
            <?php
            learndash_get_template_part( 'focus/masthead.php', array(
                'course_id' => $course_id,
                'user_id'   => $user_id,
                'context'   => 'focus',
            ), true );
            ?>

            <?php do_action( 'learndash-focus-masthead-after', $course_id, $user_id ); ?>
            <div class="ld-focus-content">
            </div>
        </div>
    </div>
</div> 



