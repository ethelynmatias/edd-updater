<div class="ld-focus-sidebar">
    <?php do_action( 'bdash_focus_sidebar' ); ?>
</div>
    
