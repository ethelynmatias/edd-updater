<?php

use BetterDash as bdash;

/**
 * @see  sfwd-lms/themes/ld30/templates/focus/index.php
 */

$course_id = bdash\course_id();
$user_id   = get_current_user_id();
?>

<div id='bdash-content-builder' class='learndash-wrapper'>
    <div class='ld-focus'>
        <?php
        learndash_get_template_part( 'focus/sidebar.php', array(
            'course_id' => $course_id,
            'user_id'   => $user_id,
            'context'   => 'focus',
        ), true );
        ?>

        <div class="ld-focus-main">
            <?php do_action( 'learndash-focus-masthead-before', $course_id, $user_id ); ?>               
            
            <?php
            learndash_get_template_part( 'focus/masthead.php', array(
                'course_id' => $course_id,
                'user_id'   => $user_id,
                'context'   => 'focus',
            ), true );
            ?>

            <?php do_action( 'learndash-focus-masthead-after', $course_id, $user_id ); ?>
            <div class="ld-focus-content">
                <?php do_action( 'learndash-focus-content-title-before', $course_id, $user_id ); ?>
                <h1><?php the_title(); ?></h1>
                <?php do_action( 'learndash-focus-content-content-before', $course_id, $user_id ); ?>
                    
                    <?php \FLThemeBuilderLayoutRenderer::render_content(); ?>
                
                <?php do_action( 'learndash-focus-content-content-after', $course_id, $user_id ); ?>
            </div>
        </div>
    </div>
</div> 

