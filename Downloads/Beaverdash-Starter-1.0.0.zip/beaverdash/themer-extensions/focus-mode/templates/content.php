<?php

/**
 * Allow us to overite the content on the focus mode page
 *
 * We can't use the same method for the content than for the
 * header and for the sidebar because there is no learndash template
 * file for it
 *
 * For some reasons, the content appears severals time one the page
 * so we will use the variable $displayed for preventing issues
 */

global $_bdash_is_focus_content_displayed;
$_bdash_is_focus_content_displayed = false;

add_filter( 'the_content', function( $content ) {

    global $_bdash_is_focus_content_displayed;

  if ( $_bdash_is_focus_content_displayed === false ) {
      $content = '
	    	<div class="ld-focus-content">
	    		' . do_action( 'bdash_focus_content' ) . '
	    	</div>
	    ';

      $_bdash_is_focus_content_displayed = true;
  }

    // Returns the content.
    return $content;

}, 1);
