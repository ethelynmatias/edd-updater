<div id="bdash-header-builder">
    <div class="ld-focus-header">
        <?php do_action( 'bdash_focus_header' ); ?>
    </div>
</div>
