<?php

/**
 * @see  sfwd-lms/themes/ld30/templates/focus/masthead.php
 */

?>
<div id='bdash-header-builder' class='learndash-wrapper'>
    <div class='ld-focus'>
        <div class="ld-focus-main">
            <div class="ld-focus-header">       
                <div class="bdash-focus-header">    
                        <?php \FLThemeBuilderLayoutRenderer::render_content(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
