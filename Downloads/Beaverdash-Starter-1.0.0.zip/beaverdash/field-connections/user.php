<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - User', [
  [
    'name'   => 'bdash_profile',
    'type'   => [ 'string', 'html' ],
    'label'  => 'User Profile',
    'getter' => 'bdash_profile',
  ],

  // Below fields only for use with wpbb-if
  // Prevent showing on builder setting by setting type=none
  [
    'name'   => 'bdash_visitor',
    'type'   => 'none',
    'label'  => 'Visitor',
    'getter' => 'bdash_visitor',
  ],
  [
    'name'   => 'bdash_student',
    'type'   => 'none',
    'label'  => 'Student',
    'getter' => 'bdash_student',
  ],
]);

