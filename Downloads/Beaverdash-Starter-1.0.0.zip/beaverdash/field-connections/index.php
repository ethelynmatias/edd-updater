<?php

namespace BeaverDash;

// See also: ../themer.php

// Shown in the same order as loaded

require_once __DIR__ . '/post.php';
require_once __DIR__ . '/course.php';
require_once __DIR__ . '/buttons.php';
require_once __DIR__ . '/links.php';
require_once __DIR__ . '/labels.php';
require_once __DIR__ . '/lesson.php';
require_once __DIR__ . '/lists.php';
require_once __DIR__ . '/user.php';
require_once __DIR__ . '/certificate.php';
require_once __DIR__ . '/theme.php';
require_once __DIR__ . '/topic.php';

// Fields connections which require extenstion
require_once __DIR__ . '/extensions/index.php';
