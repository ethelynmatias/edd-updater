<?php

namespace BeaverDash;
use BetterDash as bdash;

$fields = [
  [
    'name' => 'bdash_course_title',
    'label'   => 'Course Title',
    'type'    => ['string', 'html'],
    'getter'  => 'bdash_course_title',
    // 'form'    => 'bbld_course_content_connection_form',
    'settings' => [
      'target_post' => [
        'type'   => 'select',
        'label'  => 'Source',
        'default' => '',
        'options' => [
          '' => 'Current post',
          'other' => 'Other post',
        ],
        'toggle' => [ 'other' => [ 'fields' => ['course_id'] ] ],
      ],
      'course_id' => [
        'type'   => 'text',
        'label'  => 'Course ID',
        'help' => __('Leave empty to load from current course.', 'beaverdash')
      ]
    ]
  ],
  [
    'name' => 'bdash_course_content',
    'label'   => 'Course Content',
    'type'    => 'html',
    'getter'  => 'bdash_course_content',
    // 'form'    => 'bbld_course_content_connection_form',
    'settings' => [
      'target_post' => [
        'type'   => 'select',
        'label'  => 'Source',
        'default' => '',
        'options' => [
          '' => 'Current post',
          'other' => 'Other post',
        ],
        'toggle' => [ 'other' => [ 'fields' => ['course_id'] ] ],
      ],
      'course_id' => [
        'type'   => 'text',
        'label'  => 'Course ID',
        'help' => __('Leave empty to load from current course.', 'beaverdash')
      ]
    ],
  ],
  [
    'name' => 'bdash_course_description',
    'type'    => ['string', 'html'],
    'label' => 'Course Description',
    'getter' => 'bdash_course_description',
  ],

  [
    'name' => 'bdash_image',
    'label'   => 'Featured Image',
    'type'    => ['html'],
    'getter'  => 'bdash_image',
  ],
  [
    'name' => 'bdash_video',
    'label'   => 'Featured Video',
    'type'    => ['html'],
    'getter'  => 'bdash_video',
  ],
  [
    'name' => 'bdash_video_or_image',
    'label'   => 'Featured Video with Image fallback',
    'type'    => ['html'],
    'getter'  => 'bdash_video_or_image',
  ],
  [
    'name' => 'bdash_course_navigation',
    'label'   => 'Course Navigation',
    'type'    => ['html'],
    'getter'  => 'bdash_course_navigation',
    'settings' => [
      'expand' => [
        'type'   => 'select',
        'label'  => 'Expand topics/quizzes',
        'default' => 'all',
        'options' => [
          'all' => 'Expand all',
          'current' => 'Expand for current lesson',
          'collapse' => 'Collapse all',
        ],
      ],
      'highlight_current_page' => [
        'type'   => 'select',
        'label'  => 'Highlight the name of the current page',
        'default' => 'true',
        'options' => [
          'true' => 'Yes',
          'false' => 'No',
        ],
      ],
    ]
  ],

  [
    'name' => 'bdash_course_progress',
    'type'    => ['string', 'html'],
    'label' => 'Course Progress Bar',
    'getter' => 'bdash_course_progress',
    //'form' => 'bdash_course_progress_connection_form',
    'settings' => [
      /*'course_id' => [
        'type'   => 'text',
        'label'  => 'Course ID',
        'help' => __('Leave empty to load from current course.', 'beaverdash')
      ],
      'style' => [
        'type'   => 'text',
        'label'  => 'Style'
      ],*/
      'shape' => [
        'type'   => 'select',
        'label'  => 'Shape',
        'default' => '',
        'options' => [
          '' => 'Default LearnDash progress bar',
          'line' => 'Line',
          'circle' => 'Circle',
          'semicircle' => 'Semi-Circle',
          'text' => 'Text',
          'raw' => 'Raw',
        ],
      ],
      'text_color' => [
        'type' => 'color',
        'label'  => 'Text color',
        'default' => '555555',
      ],
      /*'ie' => [
        'type' => 'select',
        'label' => 'IE/Edge compatibility mode',
        'help' => 'Apply workaround for a known browser issue with circular progress bar',
        'default' => 'false',
        'options' => [
          'false' => 'False',
          'true' => 'True',
        ],
      ],*/
    ],
  ],

  [
    'name' => 'bdash_course_expire_status',
    'type'    => ['string', 'html'],
    'label' => 'Course Expire Status',
    'getter' => 'bdash_course_expire_status',
    'settings' => [
      'target_post' => [
        'type'   => 'select',
        'label'  => 'Source',
        'default' => '',
        'options' => [
          '' => 'Current post',
          'other' => 'Other post',
        ],
        'toggle' => [ 'other' => [ 'fields' => ['course_id'] ] ],
      ],
      'course_id' => [
        'type'   => 'text',
        'label'  => 'Course ID'
      ],
      'user_id' => [
        'type'   => 'text',
        'label'  => 'User ID'
      ],
      'label_before' => [
        'type'   => 'text',
        'label'  => 'Label Before'
      ],
      'label_after' => [
        'type'   => 'text',
        'label'  => 'Label After'
      ],
      'format' => [
        'type'   => 'text',
        'label'  => 'Format'
      ],
    ],
  ],

  // Below fields only for use with wpbb-if
  // Prevent showing on builder setting by setting type=none

  [
    'name' => 'bdash_course_started',
    'type'    => 'none',
    'label' => 'Current course is started',
    'getter' => 'bdash_course_started',
  ],
  [
    'name' => 'bdash_course_in_progress',
    'type'    => 'none',
    'label' => 'Current course is in progress',
    'getter' => 'bdash_course_in_progress',
  ],
  [
    'name' => 'bdash_course_completed',
    'type'    => 'none',
    'label' => 'Current course is completed',
    'getter' => 'bdash_course_completed',
  ],

  [
    'name' => 'bdash_course_has_certificate',
    'type'    => 'none',
    'label' => 'Course has associated certificate',
    'getter' => 'bdash_course_has_certificate',
  ],
  [
    'name' => 'bdash_course_points_enabled',
    'type'    => 'none',
    'label' => 'The setting "Course points enabled" is checked',
    'getter' => 'bdash_course_points_enabled',
  ],

  [
    'name' => 'bdash_hide_course_content_table',
    'type'    => 'none',
    'label' => 'If "Hide Course Content Table" setting applies',
    'getter' => 'bdash_hide_course_content_table_enabled',
  ],

  /*[
    // Current course has progression enabled (option to disable is unchecked)
    'name' => 'bdash_progression_enabled',
    'type'    => 'none',
    'label' => 'Progression enabled',
    'getter' => 'bdash_lesson_progression_enabled',
  ],*/
  [
    'name' => 'bdash_lesson_progression_enabled',
    'type'    => 'none',
    'label' => 'Lesson progression is enabled for this course',
    'getter' => 'bdash_lesson_progression_enabled',
  ],
  [
    'name'  => 'bdash_course_user_date_completed',
    'type'  => ['string', 'html'],
    'label' => 'Course Date Completed',
    'getter'=> 'bdash_course_user_date_completed',
  ],

];

// Field connections only supported by LD3 or higher
if( bdash\utils\is_ld3() ) {
  
  array_push( $fields, [
    'name'    => 'bdash_course_color_background',
    'label'   => 'Background Color',
    'type'    => ['color'],
    'getter'  => 'bdash_course_color_background',
  ] );
  
  array_push( $fields,[
    'name'    => 'bdash_course_color_text',
    'label'   => 'Text Color',
    'type'    => ['color'],
    'getter'  => 'bdash_course_color_text',
  ] );
  
  array_push( $fields,[
    'name'    => 'bdash_course_price',
    'label'   => 'Course Price',
    'type'    => ['string', 'html'],
    'getter'  => 'bdash_course_price',
    'settings'=> [
      'output' => [
        'type'    => 'select',
        'label'   => 'Output',
        'default' => 'text',
        'options' => [
          'text'    => 'Full text',
          'number'  => 'Only number',
        ],
      ],
    ],
  ]);

  array_push( $fields, [
    'name'    => 'bdash_course_price_type_label',
    'label'   => 'Course Price Status',
    'type'    => ['string', 'html'],
    'getter'  => 'bdash_course_price_type_label',
  ]);

  array_push( $fields, [
    'name'    => 'bdash_course_price_currency',
    'label'   => 'Course Price Currency',
    'type'    => ['string', 'html'],
    'getter'  => 'bdash_course_price_currency',
    'settings'=> [
      'output' => [
        'type'    => 'select',
        'label'   => 'Output',
        'default' => 'code',
        'options' => [
          'code'    => 'Currency code',
          'symbol'  => 'Currency symbol',
        ],
      ],
    ],
  ]);

  array_push( $fields, [
    'name'    => 'bdash_course_price_interval',
    'label'   => 'Course Price Interval',
    'type'    => ['string', 'html'],
    'getter'  => 'bdash_course_price_interval',
  ]);

  array_push( $fields, [
    'name'    => 'bdash_course_price_frequency',
    'label'   => 'Course Price Frequency',
    'type'    => ['string', 'html'],
    'getter'  => 'bdash_course_price_frequency',
  ]);

  array_push( $fields, [
    'name'    => 'bdash_course_price_url',
    'label'   => 'Course Price Custom URL',
    'type'    => ['string', 'html', 'url'],
    'getter'  => 'bdash_course_price_url',
  ]);

}

add_beaver_themer_group('BeaverDash - Course', $fields);
