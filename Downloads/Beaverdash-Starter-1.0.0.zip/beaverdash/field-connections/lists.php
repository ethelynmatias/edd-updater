<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Lists', [
/*
  [
    'name' => 'bdash_course_lessons',
    'type'    => ['string', 'html'],
    'label' => 'Course Lessons',
    'getter' => 'bdash_course_lessons',
    'settings' => [
      'available' => [
        'type'   => 'select',
        'label'  => 'Limit by availability to current user',
        'default' => '',
        'options' => [
          '' => 'None',
          'true' => 'Available',
          'false' => 'Unavailable',
        ],
      ],
      'link_unavailable' => [
        'type'   => 'select',
        'label'  => 'Link to unavailable lessons',
        'default' => '',
        'options' => [
          '' => 'None',
          'true' => 'True',
          'false' => 'False',
        ],
      ],
      'progression' => [
        'type'   => 'select',
        'label'  => 'Limit by progression',
        'default' => '',
        'options' => [
          '' => 'None',
          'true' => 'Lessons that user can progress to',
          'false' => 'Lessons that user cannot progress to',
        ],
      ],
      'drip' => [
        'type'   => 'select',
        'label'  => 'Limit by drip date',
        'default' => '',
        'options' => [
          '' => 'None',
          'past' => 'Drip: past',
          'future' => 'Drip: future',
        ],
      ],
    ],
  ], */
  [
    'name'     => 'bdash_course_list',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Course List',
    'getter'   => 'bdash_course_list',
    // 'form' => '',
    'settings' => [
      /*
      'num' => [
        'type'   => 'text',
        'label'  => 'Num'
      ],
      'order' => [
        'type'   => 'text',
        'label'  => 'Order'
      ],
      'orderby' => [
        'type'   => 'text',
        'label'  => 'Orderby'
      ],
      'tag' => [
        'type'   => 'text',
        'label'  => 'Tag'
      ],
      'tag_id' => [
        'type'   => 'text',
        'label'  => 'Tag ID'
      ],
      'cat' => [
        'type'   => 'text',
        'label'  => 'Cat'
      ],
      'category_name' => [
        'type'   => 'text',
        'label'  => 'Category Name'
      ],
      'mycourses' => [
        'type'   => 'text',
        'label'  => 'Mycourses'
      ],*/
    ],
  ],
  [
    'name'     => 'bdash_lesson_list',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Lesson List',
    'getter'   => 'bdash_lesson_list',
    // 'form' => '',
    'settings' => [],
  ],
  [
    'name'     => 'bdash_topic_list',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Topic List',
    'getter'   => 'bdash_topic_list',
    // 'form' => '',
    'settings' => [],
  ],
  [
    'name'     => 'bdash_quiz_list',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Quiz List',
    'getter'   => 'bdash_quiz_list',
    // 'form' => '',
    'settings' => [],
  ],
  [
    'name'   => 'bdash_materials',
    'type'   => [ 'html' ],
    'label'  => 'Materials for course, lesson, topic or quiz',
    'getter' => 'bdash_materials',
  ],
  [
    'name'   => 'bdash_course_materials',
    'type'   => [ 'html' ],
    'label'  => 'Course Materials',
    'getter' => 'bdash_course_materials',
  ],
  [
    'name'   => 'bdash_lesson_materials',
    'type'   => [ 'html' ],
    'label'  => 'Lesson Materials',
    'getter' => 'bdash_lesson_materials',
  ],
  [
    'name'   => 'bdash_topic_materials',
    'type'   => [ 'html' ],
    'label'  => 'Topic Materials',
    'getter' => 'bdash_topic_materials',
  ],
  [
    'name'   => 'bdash_parent_materials',
    'type'   => [ 'html' ],
    'label'  => 'Parent Item\'s Materials',
    'getter' => 'bdash_parent_materials',
  ],

]);
