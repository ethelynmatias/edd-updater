<?php

namespace BeaverDash;
use BetterDash as bdash;

$fields = [];

// Field connections only supported by LD3 or higher
if ( bdash\utils\is_ld3() ) {

  array_push( $fields, [
    'name'   => 'bdash_theme_color_primary',
    'label'  => 'Primary Color',
    'type'   => [ 'color' ],
    'getter' => 'bdash_theme_color_primary',
  ] );

  array_push( $fields, [
    'name'   => 'bdash_theme_color_secondary',
    'label'  => 'Seconday Color',
    'type'   => [ 'color' ],
    'getter' => 'bdash_theme_color_secondary',
  ] );

  array_push( $fields, [
    'name'   => 'bdash_theme_color_tertiary',
    'label'  => 'Tertiary Color',
    'type'   => [ 'color' ],
    'getter' => 'bdash_theme_color_tertiary',
  ] );

}

add_beaver_themer_group( 'BeaverDash - Theme', $fields );
