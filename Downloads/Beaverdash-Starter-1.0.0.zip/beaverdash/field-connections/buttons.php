<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Buttons', [
  [
    'name'     => 'bdash_mark_complete_button',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Mark Complete Button',
    'getter'   => 'bdash_mark_complete_button',
    'settings' => [
      'redirect' => [
        'type'    => 'select',
        'label'   => 'Redirect after mark complete',
        'default' => '',
        'options' => [
          ''              => 'Default - next item',
          'parent-course' => 'Parent course',
          'parent-lesson' => 'Parent lesson',
          'parent-topic'  => 'Parent topic',
          'self'          => 'Same page',
        ],
      ],
    ],
  ],
  [
    'name'   => 'bdash_enroll_button',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Enroll Button',
    'getter' => 'bdash_enroll_button',
  ],
]);
