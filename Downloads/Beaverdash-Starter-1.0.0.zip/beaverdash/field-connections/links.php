<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Links', [
  [
    'name'   => 'bdash_parent_course_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Parent Course',
    'getter' => 'bdash_parent_course_title',
  ],
  [
    'name'   => 'bdash_parent_course_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Parent Course',
    'getter' => 'bdash_parent_course_url',
  ],
  [
    'name'   => 'bdash_parent_lesson_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Parent Lesson',
    'getter' => 'bdash_parent_lesson_title',
  ],
  [
    'name'   => 'bdash_parent_lesson_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Parent Lesson',
    'getter' => 'bdash_parent_lesson_url',
  ],
  [
    'name'   => 'bdash_parent_topic_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Parent Topic',
    'getter' => 'bdash_parent_topic_title',
  ],
  [
    'name'   => 'bdash_parent_topic_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Parent Topic',
    'getter' => 'bdash_parent_topic_url',
  ],

  [
    'name'   => 'bdash_parent',
    'type'   => [ 'html' ],
    'label'  => 'Link to Parent Item',
    'getter' => 'bdash_parent_link',
  ],
  [
    'name'   => 'bdash_parent_url',
    'type'   => [ 'html', 'url' ],
    'label'  => 'URL of Parent Item',
    'getter' => 'bdash_parent_url',
  ],
  [
    'name'   => 'bdash_parent_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Parent Item',
    'getter' => 'bdash_parent_title',
  ],

  [
    'name'   => 'bdash_next',
    'type'   => [ 'html' ],
    'label'  => 'Link to Next Item',
    'getter' => 'bdash_next_link',
  ],
  [
    'name'   => 'bdash_next_url',
    'type'   => [ 'html', 'url' ],
    'label'  => 'URL of Next Item',
    'getter' => 'bdash_next_url',
  ],
  [
    'name'   => 'bdash_next_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Next Item',
    'getter' => 'bdash_next_title',
  ],
  [
    'name'   => 'bdash_previous',
    'type'   => [ 'html' ],
    'label'  => 'Link to Previous Item',
    'getter' => 'bdash_previous_link',
  ],
  [
    'name'   => 'bdash_previous_url',
    'type'   => [ 'html', 'url' ],
    'label'  => 'URL of Previous Item',
    'getter' => 'bdash_previous_url',
  ],
  [
    'name'   => 'bdash_previous_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Previous Item',
    'getter' => 'bdash_previous_title',
  ],

  [
    'name'   => 'bdash_next_lesson_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Next Lesson',
    'getter' => 'bdash_next_lesson_url',
  ],
  [
    'name'   => 'bdash_previous_lesson_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Previous Lesson',
    'getter' => 'bdash_previous_lesson_url',
  ],
  [
    'name'   => 'bdash_next_lesson_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Next Lesson',
    'getter' => 'bdash_next_lesson_title',
  ],
  [
    'name'   => 'bdash_previous_lesson_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Previous Lesson',
    'getter' => 'bdash_previous_lesson_title',
  ],

  [
    'name'   => 'bdash_next_topic_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Next Topic',
    'getter' => 'bdash_next_topic_url',
  ],
  [
    'name'   => 'bdash_previous_topic_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Previous Topic',
    'getter' => 'bdash_previous_topic_url',
  ],
  [
    'name'   => 'bdash_next_topic_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Next Topic',
    'getter' => 'bdash_next_topic_title',
  ],
  [
    'name'   => 'bdash_previous_topic_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Previous Topic',
    'getter' => 'bdash_previous_topic_title',
  ],

  [
    'name'   => 'bdash_next_quiz_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Next Quiz',
    'getter' => 'bdash_next_quiz_url',
  ],
  [
    'name'   => 'bdash_previous_quiz_url',
    'type'   => [ 'string', 'html', 'url' ],
    'label'  => 'URL to Previous Quiz',
    'getter' => 'bdash_previous_quiz_url',
  ],
  [
    'name'   => 'bdash_next_quiz_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Next Quiz',
    'getter' => 'bdash_next_quiz_title',
  ],
  [
    'name'   => 'bdash_previous_quiz_title',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Title of Previous Quiz',
    'getter' => 'bdash_previous_quiz_title',
  ],

]);
