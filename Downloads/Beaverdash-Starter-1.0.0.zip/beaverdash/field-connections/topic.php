<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Topic', [
  [
    'name'     => 'bdash_topic_navigation',
    'label'    => 'Topic Navigation',
    'type'     => [ 'html' ],
    'getter'   => 'bdash_topic_navigation',
    'settings' => [
      'expand'                 => [
        'type'    => 'select',
        'label'   => 'Expand topics/quizzes',
        'default' => 'all',
        'options' => [
          'all'      => 'Expand all',
          'collapse' => 'Collapse all',
        ],
      ],
      'highlight_current_page' => [
        'type'    => 'select',
        'label'   => 'Highlight the name of the current page',
        'default' => 'true',
        'options' => [
          'true'  => 'Yes',
          'false' => 'No',
        ],
      ],
    ],
  ],
]);
