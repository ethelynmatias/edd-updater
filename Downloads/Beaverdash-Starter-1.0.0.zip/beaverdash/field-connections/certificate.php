<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Certificate', [
  [
    'name'     => 'bdash_course_certificate_link',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Course certificate link',
    'getter'   => 'bdash_course_certificate_link',
    'settings' => [
      'target_post' => [
        'type'    => 'select',
        'label'   => 'Source',
        'default' => '',
        'options' => [
          ''      => 'Current post',
          'other' => 'Other post',
        ],
        'toggle'  => [ 'other' => [ 'fields' => [ 'course_id' ] ] ],
      ],
      'course_id'   => [
        'type'  => 'text',
        'label' => 'Course ID',
        'help'  => __( 'Leave empty to load from current course.', 'beaverdash' ),
      ],
      'label'       => [
        'type'  => 'text',
        'label' => 'Label text',
        'help'  => __( 'Leave empty for default label.', 'beaverdash' ),
      ],
      'class'       => [
        'type'  => 'text',
        'label' => 'Link class',
        'help'  => __( 'Default is "btn-blue".', 'beaverdash' ),
      ],
    ],
  ],
  [
    'name'     => 'bdash_course_certificate_url',
    'type'     => [ 'string', 'html', 'url' ],
    'label'    => 'Course certificate URL',
    'getter'   => 'bdash_course_certificate_url',
    'settings' => [
      'target_post' => [
        'type'    => 'select',
        'label'   => 'Source',
        'default' => '',
        'options' => [
          ''      => 'Current post',
          'other' => 'Other post',
        ],
        'toggle'  => [ 'other' => [ 'fields' => [ 'course_id' ] ] ],
      ],
      'course_id'   => [
        'type'  => 'text',
        'label' => 'Course ID',
        'help'  => __( 'Leave empty to load from current course.', 'beaverdash' ),
      ],
    ],
  ],
  [
    'name'     => 'bdash_quiz_certificate_link',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Quiz certificate link',
    'getter'   => 'bdash_quiz_certificate_link',
    'settings' => [
      'target_post' => [
        'type'    => 'select',
        'label'   => 'Source',
        'default' => '',
        'options' => [
          ''      => 'Current post',
          'other' => 'Other post',
        ],
        'toggle'  => [ 'other' => [ 'fields' => [ 'quiz_id' ] ] ],
      ],
      'quiz_id'     => [
        'type'  => 'text',
        'label' => 'Quiz ID',
        'help'  => __( 'Leave empty to load from current quiz.', 'beaverdash' ),
      ],
      'label'       => [
        'type'  => 'text',
        'label' => 'Label text',
        'help'  => __( 'Leave empty for default label.', 'beaverdash' ),
      ],
      'class'       => [
        'type'  => 'text',
        'label' => 'Link class',
      ],
    ],
  ],
  [
    'name'     => 'bdash_quiz_certificate_url',
    'type'     => [ 'string', 'html', 'url' ],
    'label'    => 'Quiz certificate URL',
    'getter'   => 'bdash_quiz_certificate_url',
    'settings' => [
      'target_post' => [
        'type'    => 'select',
        'label'   => 'Source',
        'default' => '',
        'options' => [
          ''      => 'Current post',
          'other' => 'Other post',
        ],
        'toggle'  => [ 'other' => [ 'fields' => [ 'quiz_id' ] ] ],
      ],
      'quiz_id'     => [
        'type'  => 'text',
        'label' => 'Quiz ID',
        'help'  => __( 'Leave empty to load from current quiz.', 'beaverdash' ),
      ],
    ],
  ],
]);
