<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Labels', [
  [
    'name'   => 'bdash_course_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "course"',
    'getter' => 'bdash_course_label',
  ],
  [
    'name'   => 'bdash_next_course_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Next course"',
    'getter' => 'bdash_next_course_label',
  ],
  [
    'name'   => 'bdash_previous_course_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Previous course"',
    'getter' => 'bdash_previous_course_label',
  ],
  [
    'name'   => 'bdash_back_to_course_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Back to course"',
    'getter' => 'bdash_back_to_course_label',
  ],
  [
    'name'   => 'bdash_lesson_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "lesson"',
    'getter' => 'bdash_lesson_label',
  ],
  [
    'name'   => 'bdash_next_lesson_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Next lesson"',
    'getter' => 'bdash_next_lesson_label',
  ],
  [
    'name'   => 'bdash_previous_lesson_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Previous lesson"',
    'getter' => 'bdash_previous_lesson_label',
  ],

  [
    'name'   => 'bdash_topic_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "topic"',
    'getter' => 'bdash_topic_label',
  ],
  [
    'name'   => 'bdash_next_topic_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Next topic"',
    'getter' => 'bdash_next_topic_label',
  ],
  [
    'name'   => 'bdash_previous_topic_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Previous topic"',
    'getter' => 'bdash_previous_topic_label',
  ],

  [
    'name'   => 'bdash_quiz_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "quiz"',
    'getter' => 'bdash_quiz_label',
  ],
  [
    'name'   => 'bdash_next_quiz_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Next quiz"',
    'getter' => 'bdash_next_quiz_label',
  ],
  [
    'name'   => 'bdash_previous_quiz_label',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Label for "Previous quiz"',
    'getter' => 'bdash_previous_quiz_label',
  ],

]);
