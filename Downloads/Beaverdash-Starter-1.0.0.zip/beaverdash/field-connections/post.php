<?php

namespace BeaverDash;

use BetterDash as bdash;

$fields = [
  [
    'name'     => 'bdash_content',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Post Content',
    'getter'   => 'bdash_content',
    'settings' => [
      'drip'          => [
        'type'    => 'select',
        'label'   => 'Drip',
        'options' => [
          ''      => 'Enabled',
          'false' => 'Disabled',
        ],
      ],
      'drip_text'     => [
        'type'  => 'textarea',
        'label' => 'Drip Text',
        'help'  => 'Text to display if drip is future. Leave empty to display default message.',
      ],
      'drip_redirect' => [
        'type'  => 'text',
        'label' => 'Drip Redirect',
        'help'  => 'Redirect to URL if drip is future. Leave empty to not redirect.',
      ],
    ],
  ],

  [
    'name'     => 'bdash_drip_date',
    'type'     => [ 'string', 'html' ],
    'label'    => 'Drip date (if any)',
    'getter'   => 'bdash_drip_date',
    // get_option('date_format')
    'settings' => [
      'format' => [
        'type'  => 'text',
        'label' => 'Date format',
        'help'  => 'Leave empty to use date format in site settings. See <a href="http://php.net/manual/en/function.date.php" target="_blank">reference for date format</a>.',
      ],
    ],
  ],

  // Below fields only for use with wpbb-if

  [
    'name'   => 'bdash_drip_future',
    'type'   => 'none',
    'label'  => 'Drip is future',
    'getter' => 'bdash_drip_future',
  ],
  [
    'name'   => 'bdash_drip_past',
    'type'   => 'none',
    'label'  => 'Drip is past',
    'getter' => 'bdash_drip_past',
  ],
  [
    'name'   => 'bdash_no_drip',
    'type'   => 'none',
    'label'  => 'No drip',
    'getter' => 'bdash_no_drip',
  ],

  [
    'name'   => 'bdash_can_progress',
    'type'   => 'none',
    'label'  => 'User can progress to current item',
    'getter' => 'bdash_can_progress',
  ],
  [
    'name'   => 'bdash_cannot_progress',
    'type'   => 'none',
    'label'  => 'User cannot progress to current item',
    'getter' => 'bdash_cannot_progress',
  ],

  [
    'name'   => 'bdash_available',
    'type'   => 'none',
    'label'  => 'User has access to current item',
    'getter' => 'bdash_available',
  ],
  [
    'name'   => 'bdash_unavailable',
    'type'   => 'none',
    'label'  => 'User doesn\'t have access to current item',
    'getter' => 'bdash_unavailable',
  ],

  [
    'name'   => 'bdash_video_progression_enabled',
    'type'   => 'none',
    'label'  => 'Video progression is enabled for this lesson or topic',
    'getter' => 'bdash_video_progression_enabled',
  ],
  [
    'name'   => 'bdash_has_video',
    'type'   => 'none',
    'label'  => 'This lesson or topic has video URL',
    'getter' => 'bdash_has_video',
  ],

];

// Field connections only supported by LD3 or higher
if ( bdash\utils\is_ld3() ) {

  array_push( $fields, [
    'name'   => 'bdash_color_background',
    'label'  => 'Background Color',
    'type'   => [ 'color' ],
    'getter' => 'bdash_color_background',
  ] );

  array_push( $fields, [
    'name'   => 'bdash_color_text',
    'label'  => 'Text Color',
    'type'   => [ 'color' ],
    'getter' => 'bdash_color_text',
  ] );

}

add_beaver_themer_group( 'BeaverDash - Post', $fields );
