<?php

namespace BeaverDash;

add_beaver_themer_group('BeaverDash - Lesson', [
  [
    'name'     => 'bdash_lesson_navigation',
    'label'    => 'Lesson Navigation',
    'type'     => [ 'html' ],
    'getter'   => 'bdash_lesson_navigation',
    'settings' => [
      'expand'                 => [
        'type'    => 'select',
        'label'   => 'Expand topics/quizzes',
        'default' => 'all',
        'options' => [
          'all'      => 'Expand all',
          'collapse' => 'Collapse all',
        ],
      ],
      'highlight_current_page' => [
        'type'    => 'select',
        'label'   => 'Highlight the name of the current page',
        'default' => 'true',
        'options' => [
          'true'  => 'Yes',
          'false' => 'No',
        ],
      ],
    ],
  ],
]);
