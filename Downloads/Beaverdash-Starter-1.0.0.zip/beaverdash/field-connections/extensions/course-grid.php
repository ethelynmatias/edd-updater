<?php

namespace BeaverDash;

use BetterDash as bdash;

/**
 * @see https://www.learndash.com/support/docs/add-ons/course-grid/
 */

$fields = [
  [
    'name'   => 'bdash_course_grid_short_description',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Short Description',
    'getter' => 'bdash_course_grid_short_description',
  ],
  [
    'name'   => 'bdash_course_grid_ribbon_text',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Custom Ribbon Text',
    'getter' => 'bdash_course_grid_ribbon_text',
  ],
  [
    'name'   => 'bdash_course_grid_button_text',
    'type'   => [ 'string', 'html' ],
    'label'  => 'Custom Button Text',
    'getter' => 'bdash_course_grid_button_text',
  ],
  [
    'name'   => 'bdash_course_grid_video_preview_code',
    'type'   => [ 'html' ],
    'label'  => 'Preview Video',
    'getter' => 'bdash_course_grid_video_preview_code',
  ],
  [
    'name'   => 'bdash_course_grid_video_preview_enable',
    'type'   => 'none',
    'label'  => 'Preview video is enable for this course',
    'getter' => 'bdash_course_grid_video_preview_enable',
  ],
];

add_beaver_themer_group( 'BeaverDash - Course Grid', $fields );
