<?php

namespace BeaverDash;

use BetterDash as bdash;

if ( function_exists('BetterDash\\course_grid_activated') && bdash\course_grid_activated() ) {
  require_once __DIR__ . '/course-grid.php';
}
