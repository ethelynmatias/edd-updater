<?php

use BetterDash as bdash;

class BDash_Button_MarkComplete extends FLBuilderModule {

  /**
   * @method __construct
   */
  public function __construct() {
    parent::__construct(array(
      'name'            => __( 'Mark Complete', 'beaverdash' ),
      'description'     => __( 'Mark complete button', 'beaverdash' ),
      'group'           => beaverdash()->state['module_group_name'],
      'category'        => __( 'Button', 'beaverdash' ),
      'dir'             => __DIR__,
      'url'             => plugins_url( '', __FILE__ ),
      'partial_refresh' => true,
      'icon'            => 'button.svg',
    ));
  }

  public function get_classname() {
    $classname = 'fl-button-wrap bdash-button-wrap';

    if ( ! empty( $this->settings->width ) ) {
      $classname .= ' fl-button-width-' . $this->settings->width;
    }
    if ( ! empty( $this->settings->align ) ) {
      $classname .= ' fl-button-' . $this->settings->align;
    }
    if ( ! empty( $this->settings->icon ) ) {
      $classname .= ' fl-button-has-icon';
    }

    return $classname;
  }
}

$fields = array(
  'general' => array(
    'title'    => __( 'General', 'fl-builder' ),
    'sections' => array(
      'general' => array(
        'title'  => '',
        'fields' => array(
          'text'              => array(
            'type'    => 'text',
            'label'   => __( 'Text', 'fl-builder' ),
            'default' => __( 'Mark Complete', 'fl-builder' ),
            'help'    => 'Leave empty to use default label for "Mark Complete"',
            /*
            'preview'         => array(
              'type'            => 'text',
              'selector'        => '.fl-button-text',
            ),*/
            // 'connections'         => array( 'string' ),
          ),
          'redirect'          => [
            'type'    => 'select',
            'label'   => __( 'Redirect', 'beaverdash' ),
            'help'    => 'Redirect destination after marked complete',
            'default' => 'next',
            'options' => [
              'next'          => __( 'Next', 'beaverdash' ),
              'parent-course' => __( 'Parent course', 'beaverdash' ),
              'parent-lesson' => __( 'Parent lesson', 'beaverdash' ),
              'parent-topic'  => __( 'Parent topic', 'beaverdash' ),
              'self'          => __( 'Self', 'beaverdash' ),
            ],
          ],
          'button_style'      => [
            'type'    => 'select',
            'label'   => __( 'Style of the button', 'beaverdash' ),
            'default' => 'custom',
            'options' => [
              'custom'    => __( 'Custom', 'beaverdash' ),
              'learndash' => __( 'Learndash', 'beaverdash' ),
            ],
            'toggle'  => [
              'custom' => [
                'fields' => [
                  'icon',
                  'icon_position',
                  'icon_animation',
                  'disable_apparence',
                ],
              ],
            ],
          ],
          'icon'              => array(
            'type'        => 'icon',
            'label'       => __( 'Icon', 'fl-builder' ),
            'show_remove' => true,
          ),
          'icon_position'     => array(
            'type'    => 'select',
            'label'   => __( 'Icon Position', 'fl-builder' ),
            'default' => 'before',
            'options' => array(
              'before' => __( 'Before Text', 'fl-builder' ),
              'after'  => __( 'After Text', 'fl-builder' ),
            ),
          ),
          'icon_animation'    => array(
            'type'    => 'select',
            'label'   => __( 'Icon Visibility', 'fl-builder' ),
            'default' => 'disable',
            'options' => array(
              'disable' => __( 'Always Visible', 'fl-builder' ),
              'enable'  => __( 'Fade In On Hover', 'fl-builder' ),
            ),
          ),
          'progress_priority' => array(
            'type'    => 'select',
            'label'   => __( 'Mark Complete Priority', 'fl-builder' ),
            'default' => 'video',
            'options' => array(
              'video'     => __( 'Video Progression', 'fl-builder' ),
              'countdown' => __( 'Forced Timer Countdown', 'fl-builder' ),
            ),
          ),
          'disable_apparence' => array(
            'type'    => 'select',
            'label'   => __( 'Apparence when disable', 'fl-builder' ),
            'help'    => 'This option will be effective only when the button is disable by the video progression or by a timer countdown',
            'default' => 'disable',
            'options' => array(
              'visible'   => __( 'Regular', 'fl-builder' ),
              'disable'   => __( 'Disable', 'fl-builder' ),
              'invisible' => __( 'Invisible', 'fl-builder' ),
            ),
          ),
          'show_timer'        => [
            'type'    => 'button-group',
            'label'   => 'Show timer',
            'default' => 'false',
            'options' => [
              'true'  => 'Yes',
              'false' => 'No',
            ],
          ],
        ),
      ),
    ),
  ),
  'style'   => array(
    'title'    => __( 'Style', 'fl-builder' ),
    'sections' => array(
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'typography' => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
        ],
      ],
      'colors'     => array(
        'title'  => __( 'Colors', 'fl-builder' ),
        'fields' => array(
          'bg_color'         => array(
            'type'        => 'color',
            'label'       => __( 'Background Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
          ),
          'bg_hover_color'   => array(
            'type'        => 'color',
            'label'       => __( 'Background Hover Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => array(
              'type' => 'none',
            ),
          ),
          'text_color'       => array(
            'type'        => 'color',
            'label'       => __( 'Text Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
          ),
          'text_hover_color' => array(
            'type'        => 'color',
            'label'       => __( 'Text Hover Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => array(
              'type' => 'none',
            ),
          ),
        ),
      ),
      'style'      => array(
        'title'  => __( 'Style', 'fl-builder' ),
        'fields' => array(
          'style'             => array(
            'type'    => 'select',
            'label'   => __( 'Style', 'fl-builder' ),
            'default' => 'flat',
            'options' => array(
              'flat'        => __( 'Flat', 'fl-builder' ),
              'gradient'    => __( 'Gradient', 'fl-builder' ),
              'transparent' => __( 'Transparent', 'fl-builder' ),
            ),
            'toggle'  => array(
              'transparent' => array(
                'fields' => array( 'bg_opacity', 'bg_hover_opacity', 'border_size' ),
              ),
            ),
          ),
          'border_size'       => array(
            'type'        => 'text',
            'label'       => __( 'Border Size', 'fl-builder' ),
            'default'     => '2',
            'description' => 'px',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '0',
            'sanitize'    => 'absint',
          ),
          'bg_opacity'        => array(
            'type'        => 'text',
            'label'       => __( 'Background Opacity', 'fl-builder' ),
            'default'     => '0',
            'description' => '%',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '0',
            'sanitize'    => 'absint',
          ),
          'bg_hover_opacity'  => array(
            'type'        => 'text',
            'label'       => __( 'Background Hover Opacity', 'fl-builder' ),
            'default'     => '0',
            'description' => '%',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '0',
            'sanitize'    => 'absint',
          ),
          'button_transition' => array(
            'type'    => 'select',
            'label'   => __( 'Transition', 'fl-builder' ),
            'default' => 'disable',
            'options' => array(
              'disable' => __( 'Disabled', 'fl-builder' ),
              'enable'  => __( 'Enabled', 'fl-builder' ),
            ),
          ),
        ),
      ),
      'formatting' => array(
        'title'  => __( 'Structure', 'fl-builder' ),
        'fields' => array(
          'width'         => array(
            'type'    => 'select',
            'label'   => __( 'Width', 'fl-builder' ),
            'default' => 'auto',
            'options' => array(
              'auto'   => _x( 'Auto', 'Width.', 'fl-builder' ),
              'full'   => __( 'Full Width', 'fl-builder' ),
              'custom' => __( 'Custom', 'fl-builder' ),
            ),
            'toggle'  => array(
              'auto'   => array(
                'fields' => array( 'align' ),
              ),
              'full'   => array(),
              'custom' => array(
                'fields' => array( 'align', 'custom_width' ),
              ),
            ),
          ),
          'custom_width'  => array(
            'type'        => 'text',
            'label'       => __( 'Custom Width', 'fl-builder' ),
            'default'     => '200',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
          'align'         => array(
            'type'    => 'select',
            'label'   => __( 'Alignment', 'fl-builder' ),
            'default' => 'left',
            'options' => array(
              'center' => __( 'Center', 'fl-builder' ),
              'left'   => __( 'Left', 'fl-builder' ),
              'right'  => __( 'Right', 'fl-builder' ),
            ),
          ),
          'font_size'     => array(
            'type'        => 'text',
            'label'       => __( 'Font Size', 'fl-builder' ),
            'default'     => '',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
          'padding'       => array(
            'type'        => 'text',
            'label'       => __( 'Padding', 'fl-builder' ),
            'default'     => '',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
          'border_radius' => array(
            'type'        => 'text',
            'label'       => __( 'Round Corners', 'fl-builder' ),
            'default'     => '',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
        ),
      ),
    ),
  ),
);


if ( bdash\utils\is_ld3( false ) ) {
  // We can't enable video progression and forced timer at the same time anymore
  unset( $fields['general']['sections']['general']['fields']['progress_priority'] );
}

if ( ! bdash\utils\is_ld3() ) {
  unset( $fields['general']['sections']['general']['fields']['button_style'] );
}

FLBuilder::register_module( 'BDash_Button_MarkComplete', $fields );
