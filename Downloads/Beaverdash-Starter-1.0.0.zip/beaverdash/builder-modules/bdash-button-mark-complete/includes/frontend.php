<?php

namespace BeaverDash;

use BetterDash as bdash;

$text = ! empty( $settings->text )
  ? $settings->text
  : \LearnDash_Custom_Label::get_label( 'button_mark_complete' );

ob_start();

if ( isset( $settings->button_style ) && $settings->button_style === 'learndash' ) : ?>
    <div class="<?= $module->get_classname(); ?> learndash-wrapper">
        <button type="submit" class="fl-button learndash_mark_complete_button">
            <span class="fl-button-text"><?= $text ?></span>
        </button>
    </div>
<?php else : ?>

    <div class="<?php echo $module->get_classname(); ?>">

    <button type="submit" class="fl-button<?php
    if ( 'enable' == $settings->icon_animation ) {
      ?> fl-button-icon-animation<?php
    }
    ?>" role="button">

    <?php if ( ! empty( $settings->icon ) && ( 'before' == $settings->icon_position || ! isset( $settings->icon_position ) ) ) : ?>
    <i class="fl-button-icon fl-button-icon-before <?php echo $settings->icon; ?>"></i>
    <?php endif; ?>
    <span class="fl-button-text"><?= $text ?></span>
    <?php if ( ! empty( $settings->icon ) && 'after' == $settings->icon_position ) : ?>
    <i class="fl-button-icon fl-button-icon-after <?php echo $settings->icon; ?>"></i>
    <?php endif; ?>
    </button>
    </div>

  <?php
endif;

$html = ob_get_clean();

echo bdash\mark_complete_button(
utils\module_atts($settings, [
    'redirect',
    'button_style',
  ]) + [
    'append' => $html,
  ]
);
