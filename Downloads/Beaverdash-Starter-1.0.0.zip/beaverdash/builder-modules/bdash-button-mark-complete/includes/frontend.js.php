<?php 

use BetterDash as bdash;
/*

(function($){

  console.log('Button ID', '<?= $id ?>')

	// $('.fl-node-<?= $id ?>')

})(jQuery);
*/
?>

<?php if(!bdash\utils\is_ld3(false)): ?>

(function($){

	let d = document;
	
	/*
	Allow us to define a priority for marking a lesson complete if there is 
	a timer countdown and the video progression enable on the same page 
	 */
	if(d.getElementById('learndash_mark_complete_button')){
		let mark_complete_input = d.getElementById('learndash_mark_complete_button')
		mark_complete_input.setAttribute('data-priority','<?= $settings->progress_priority; ?>');
	}

})(jQuery); 

<?php endif; ?>