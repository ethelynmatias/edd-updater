<?php

use \BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";

// Hide default LearnDash button
// ID for LD version < 3, class for > v3
?>
<?= $prefix ?> input#learndash_mark_complete_button,
<?= $prefix ?> input.learndash_mark_complete_button { 
	display: none !important; 
} <?php

// Apparence when disable by timer countdown or video progresion

// > LD3
?> 
<?= $prefix ?> #sfwd-mark-complete #learndash_mark_complete_button[disabled="disabled"] ~ .fl-button-wrap .fl-button,
<?= $prefix ?> #sfwd-mark-complete #learndash_mark_complete_button[data-access="disabled"] ~ .fl-button-wrap .fl-button {
    pointer-events: none;
    <?php if($settings->disable_apparence === 'disable'): ?>
    	background-color: #ccc;
    	border-color: #ccc;
    <?php elseif($settings->disable_apparence === 'invisible'): ?>
    	display: none;
    <?php endif; ?>
}<?php 

// < LD3 
?><?= $prefix ?> .sfwd-mark-complete .learndash_mark_complete_button[disabled="disabled"] ~ .fl-button-wrap .fl-button{
    pointer-events: none;
	<?php if(!isset($settings->button_style) || $settings->button_style === 'custom'): ?>
	    <?php if($settings->disable_apparence === 'disable'): ?>
	    	background-color: #ccc;
	    	border-color: #ccc;
	    <?php elseif($settings->disable_apparence === 'invisible'): ?>
	    	display: none;
	    <?php endif; ?>
    <?php endif; ?>
} <?php

utils\render_module_css([
  	'prefix' => $prefix,
  	'elements' => [
    [	'el'	=> 'button',
    	'types' => ['typography'] 
    ],
  ],
], $settings, $global_settings);

// Mask the timer
if($settings->show_timer === 'false'): ?> 
	<?= $prefix ?> span.learndash_timer {
		display: none;
	} 
<?php endif;

// Background Color
if ( ! empty( $settings->bg_color ) && empty( $settings->bg_hover_color ) ) {
	$settings->bg_hover_color = $settings->bg_color;
}

// Background Gradient
if ( ! empty( $settings->bg_color ) ) {
	$bg_grad_start = FLBuilderColor::adjust_brightness( $settings->bg_color, 30, 'lighten' );
}
if ( ! empty( $settings->bg_hover_color ) ) {
	$bg_hover_grad_start = FLBuilderColor::adjust_brightness( $settings->bg_hover_color, 30, 'lighten' );
}

// Border Size
if ( 'transparent' == $settings->style ) {
	$border_size = $settings->border_size;
} else {
	$border_size = 1;
}

// Border Color
if ( ! empty( $settings->bg_color ) ) {
	$border_color = FLBuilderColor::adjust_brightness( $settings->bg_color, 12, 'darken' );
}
if ( ! empty( $settings->bg_hover_color ) ) {
	$border_hover_color = FLBuilderColor::adjust_brightness( $settings->bg_hover_color, 12, 'darken' );
}

?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:visited {

	<?php if ( '' !== $settings->font_size ) : ?>
	font-size: <?php echo $settings->font_size; ?>px;
	line-height: <?php echo $settings->font_size + 2; ?>px;
	<?php endif; ?>

	<?php if ( '' !== $settings->padding ) : ?>
	padding: <?php echo $settings->padding . 'px ' . ($settings->padding * 2) . 'px'; ?>;
	<?php endif; ?>

	<?php if ( '' !== $settings->border_radius ) : ?>
	border-radius: <?php echo $settings->border_radius; ?>px;
	-moz-border-radius: <?php echo $settings->border_radius; ?>px;
	-webkit-border-radius: <?php echo $settings->border_radius; ?>px;
	<?php endif; ?>

	<?php if ( 'custom' == $settings->width ) : ?>
	width: <?php echo $settings->custom_width; ?>px;
	<?php endif; ?>

	<?php if ( ! empty( $settings->bg_color ) ) : ?>
	background: #<?php echo $settings->bg_color; ?>;
	border: <?php echo $border_size; ?>px solid #<?php echo $border_color; ?>;

		<?php if ( 'transparent' == $settings->style ) : // Transparent ?>
		background-color: rgba(<?php echo implode( ',', FLBuilderColor::hex_to_rgb( $settings->bg_color ) ) ?>, <?php echo $settings->bg_opacity / 100; ?>);
		<?php endif; ?>

		<?php if ( 'gradient' == $settings->style ) : // Gradient ?>
		background: -moz-linear-gradient(top,  #<?php echo $bg_grad_start; ?> 0%, #<?php echo $settings->bg_color; ?> 100%); /* FF3.6+ */
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#<?php echo $bg_grad_start; ?>), color-stop(100%,#<?php echo $settings->bg_color; ?>)); /* Chrome,Safari4+ */
		background: -webkit-linear-gradient(top,  #<?php echo $bg_grad_start; ?> 0%,#<?php echo $settings->bg_color; ?> 100%); /* Chrome10+,Safari5.1+ */
		background: -o-linear-gradient(top,  #<?php echo $bg_grad_start; ?> 0%,#<?php echo $settings->bg_color; ?> 100%); /* Opera 11.10+ */
		background: -ms-linear-gradient(top,  #<?php echo $bg_grad_start; ?> 0%,#<?php echo $settings->bg_color; ?> 100%); /* IE10+ */
		background: linear-gradient(to bottom,  #<?php echo $bg_grad_start; ?> 0%,#<?php echo $settings->bg_color; ?> 100%); /* W3C */
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#<?php echo $bg_grad_start; ?>', endColorstr='#<?php echo $settings->bg_color; ?>',GradientType=0 ); /* IE6-9 */
		<?php endif; ?>

	<?php endif; ?>
}

<?php if ( ! empty( $settings->text_color ) ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:visited,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button *,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:visited * {
	color: #<?php echo $settings->text_color; ?>;
}
<?php endif; ?>

<?php if ( ! empty( $settings->bg_hover_color ) ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:hover,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:focus {

	background: #<?php echo $settings->bg_hover_color; ?>;
	border: <?php echo $border_size; ?>px solid #<?php echo $border_hover_color; ?>;

	<?php if ( 'transparent' == $settings->style ) : // Transparent ?>
	background-color: rgba(<?php echo implode( ',', FLBuilderColor::hex_to_rgb( $settings->bg_hover_color ) ) ?>, <?php echo $settings->bg_hover_opacity / 100; ?>);
	border-color: #<?php echo $settings->bg_hover_color; ?>
	<?php endif; ?>

	<?php if ( 'gradient' == $settings->style ) : // Gradient ?>
	background: -moz-linear-gradient(top,  #<?php echo $bg_hover_grad_start; ?> 0%, #<?php echo $settings->bg_hover_color; ?> 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#<?php echo $bg_hover_grad_start; ?>), color-stop(100%,#<?php echo $settings->bg_hover_color; ?>)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top,  #<?php echo $bg_hover_grad_start; ?> 0%,#<?php echo $settings->bg_hover_color; ?> 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top,  #<?php echo $bg_hover_grad_start; ?> 0%,#<?php echo $settings->bg_hover_color; ?> 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top,  #<?php echo $bg_hover_grad_start; ?> 0%,#<?php echo $settings->bg_hover_color; ?> 100%); /* IE10+ */
	background: linear-gradient(to bottom,  #<?php echo $bg_hover_grad_start; ?> 0%,#<?php echo $settings->bg_hover_color; ?> 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#<?php echo $bg_hover_grad_start; ?>', endColorstr='#<?php echo $settings->bg_hover_color; ?>',GradientType=0 ); /* IE6-9 */
	<?php endif; ?>
}
<?php endif; ?>

<?php if ( ! empty( $settings->text_hover_color ) ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:hover,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:focus,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:hover *,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button:focus * {
	color: #<?php echo $settings->text_hover_color; ?>;
}
<?php endif; ?>


<?php // Transition
if ( 'enable' == $settings->button_transition ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button,
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button * {
	transition: all 0.2s linear !important;
	-moz-transition: all 0.2s linear !important;
	-webkit-transition: all 0.2s linear !important;
	-o-transition: all 0.2s linear !important;
}
<?php endif; ?>

<?php if ( empty( $settings->text ) ) : ?>
<?php if ( 'after' == $settings->icon_position ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button i.fl-button-icon-after {
	margin-left: 0;
}
<?php endif; ?>
<?php if ( 'before' == $settings->icon_position ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-button i.fl-button-icon-before {
	margin-right: 0;
}
<?php endif; ?>
<?php endif; ?>
