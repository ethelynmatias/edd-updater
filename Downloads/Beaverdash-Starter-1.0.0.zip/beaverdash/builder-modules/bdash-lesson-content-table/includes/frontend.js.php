jQuery(document).ready(function($) {

  var activate = window.BDash && window.BDash.activateContentTable
	var selector = '.fl-node-<?= $id ?> .bdash-lesson-content-table'

  if (activate) activate(selector)

});