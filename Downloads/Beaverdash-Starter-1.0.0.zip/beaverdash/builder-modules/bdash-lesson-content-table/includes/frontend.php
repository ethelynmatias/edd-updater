<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\lesson_content_table(
  utils\module_atts( $settings, $module )
);
