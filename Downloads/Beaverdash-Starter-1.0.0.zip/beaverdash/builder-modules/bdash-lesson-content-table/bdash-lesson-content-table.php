<?php

use BeaverDash\content_table;

class BDash_Lesson_Content_Table extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Lesson Content Table', 'beaverdash' ),
      'description' => __( 'Display lesson content table', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Lesson', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'editor-table.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Lesson_Content_Table', [
  'table'       => [
    'title'    => 'Table',
    'sections' => content_table\create_setting_sections( [ 'type' => 'table' ] ),
  ],
  'list'        => [
    'title'    => 'Topics',
    'sections' => content_table\create_setting_sections([
  'type'   => 'list',
  'custom' => [
      'list'   => [
        'title'  => 'Topic Table',
        'fields' => [
          'main_table_visibility'          => [
            'label' => 'Show topic table',
          ],
          'expand_collapse_all_visibility' => [
            'label' => 'Show toggle to expand/collapse all topic quizzes',
          ],
          'expand_all_by_default'          => [
            'label' => 'Expand all topic quiz list by default',
          ],
          'link_unavailable'               => [
            'label' => 'Link to unavailable topics',
          ],
        ],
      ],
      'header' => [
        'fields' => [
          'main_table_header_visibility'  => [
            'label' => 'Show topic table header',
          ],
          'main_table_header_items_label' => [
            'label'   => 'Topics column label',
            'default' => 'Topics',
          ],
        ],
      ],
    ],
    ]),
  ],
  'child_list'  => [
    'title'    => 'Topic Quizzes',
    'sections' => content_table\create_setting_sections([
  'type'   => 'child_list',
  'custom' => [
      'child_list' => [
        'title'  => 'Topic Quiz List',
        'fields' => [
          'child_list_visibility' => [
            'label' => 'Show topic quiz list',
          ],
        ],
      ],
    ],
    ]),
  ],
  'quiz_table'  => [
    'title'    => 'Lesson Quizzes',
    'sections' => content_table\create_setting_sections( [ 'type' => 'quiz_table' ] ),
  ],
  'limit_items' => [
    'title'    => 'Limit Items',
    'sections' => content_table\create_setting_sections( [ 'type' => 'limit_items' ] ),
  ],
  'style'       => [
    'title'    => 'Style',
    'sections' => content_table\create_setting_sections( [ 'type' => 'style' ] ),
  ],
]);
