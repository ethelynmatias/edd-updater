<?php

use BeaverDash\utils as utils;

class BDash_User_Dropdown extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'User Dropdown', 'beaverdash' ),
      'description' => __( 'Display a user dropdown for menu', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Focus Mode', 'beaverdash' ),
      'icon'        => 'hamburger-menu.svg',
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
    ));

    /*$this->add_js( 'example-lib', $this->url . 'js/example-lib.js', array(), '', true );*/
  }
}

FLBuilder::register_module('BDash_User_Dropdown', [

  // General settings
  'general' => [
    'title'    => 'General',
    'sections' => [
      'text' => [
        'title'  => 'Text',
        'fields' => [
          'text_message_type' => [
            'type'    => 'select',
            'label'   => 'Text message',
            'default' => 'default',
            'options' => [
              'default' => 'Default',
              'custom'  => 'Custom',
              'none'    => 'None',
            ],
            'toggle'  => [
              'custom' => [ 'fields' => [ 'text_message' ] ],
            ],
          ],
          'text_message'      => [
            'type'        => 'text',
            'label'       => 'Custom message',
            'default'     => 'Hello, [username]!',
            'help'        => 'You can use [username] for displaying the name of the user.',
            'maxlength'   => '100',
            'placeholder' => 'Custom message',
          ],
        ],
      ],
    ],
  ],
  // End general

  // Style settings
  'style'   => [
    'title'    => 'Style',
    'sections' => [
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'dropdown_align'            => [
            'type'       => 'align',
            'label'      => 'Align',
            'default'    => 'right',
            'responsive' => true,
          ],
          'typography'                => utils\create_setting_fields( [ 'type' => 'typography' ] ),
          'dropdown_background_color' => [
            'type'        => 'color',
            'label'       => 'Dropdown color',
            'default'     => '81d742',
            'connections' => [ 'color' ],
          ],
        ],
      ],
    ],
  ],
  // End Style

]);
