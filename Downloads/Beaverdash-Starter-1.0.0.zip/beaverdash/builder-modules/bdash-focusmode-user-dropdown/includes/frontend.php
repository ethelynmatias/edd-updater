<?php

namespace BeaverDash;

use BetterDash as bdash;


$layouts = \FLThemeBuilderLayoutData::get_current_page_layouts();

/**
 * This module will only display on a focus sidebar themer layout
 */
if ( ! empty( $layouts ) && array_key_exists( 'part', $layouts ) && ! empty( $layouts['part'] ) ) {
  foreach ( $layouts['part'] as $part ) {
    if ( $part['hook'] === 'bdash_focus_header' ) {

        /**
         * @see sfwd-lms/themes/ld30/templates/focus/masthead.php
         */

        $user_data = get_userdata( get_current_user_id() );
        $course_id = bdash\course_id();

        $dropdown_text = '';

      if ( $settings->text_message_type === 'default' ) {
        $dropdown_text = sprintf( esc_html_x( 'Hello, %s!', 'Focus mode welcome placeholder', 'learndash' ), $user_data->user_nicename );
      } elseif ( $settings->text_message_type === 'custom' ) {
          $dropdown_text = str_replace( '[username]', $user_data->user_nicename, $settings->text_message );
          $dropdown_text = str_replace( '[ username ]', $user_data->user_nicename, $dropdown_text );
      }

      ?>
            <div class="ld-user-menu">
                <span class="ld-text ld-user-welcome-text">
                <?= $dropdown_text ?>       
                </span>

                <span class="ld-profile-avatar">
                <?= get_avatar( $user_data->ID ); ?>
                </span>

                <span class="ld-user-menu-items">
                <?php
                $custom_menu_items = \learndash_30_get_custom_focus_menu_items();

                $menu_items = array(
                    'course-home' => array(
                        'url'   => \get_the_permalink( $course_id ),
                        'label' => sprintf( esc_html_x( '%s Home', 'Placeholder for course home link', 'learndash' ), \LearnDash_Custom_Label::get_label( 'course' )
                    ),
                ),
                );

                if ( $custom_menu_items ) :
                  foreach ( $custom_menu_items as $menu_item ) :

                    $menu_items[ $menu_item->post_name ] = array(
                        'url'   => $menu_item->url,
                        'label' => $menu_item->title,
                    );

                    endforeach;
endif;

                $menu_items['logout'] = array(
                    'url'   => \wp_logout_url( get_the_permalink( $course_id ) ),
                    'label' => __( 'Logout', 'learndash' ),
                );

                if ( $menu_items && ! empty( $menu_items ) ) :
                  foreach ( $menu_items as $slug => $item ) :
                    ?>
                            <a class="<?php echo esc_attr( 'ld-focus-menu-link ld-focus-menu-' . $slug ); ?>" href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a>
                      <?php
                        endforeach;
                    endif;
                ?>
                </span>
            </div><?php

    }
  }
}
