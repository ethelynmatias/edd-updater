<?php

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";

utils\render_module_css([
    'prefix'    => $prefix,
    'elements'  => [
    [ 'types' => ['typography'] ],
  ],
], $settings, $global_settings);


if(isset($settings->dropdown_background_color)) { ?>
	.ld-focus-header <?= $prefix	?> .ld-user-menu .ld-user-menu-items a {
		background-color: #<?= $settings->dropdown_background_color ?> !important;
	} 

	<?= $prefix	?> .ld-user-menu .ld-user-menu-items a {
		background-color: #<?= $settings->dropdown_background_color ?>;
	} 
<?php }

if(isset($settings->dropdown_align)) { ?>
	<?= $prefix	?> {
		display: flex;
		justify-content: <?= $settings->dropdown_align ?>;
	} 
<?php }
