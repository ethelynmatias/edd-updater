<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

set_settings_sections_template('limit_items', [
  'display_settings' => [
    'title'  => 'Display',
    'fields' => [
      'available'   => [
        'type'    => 'select',
        'label'   => 'Limit by availability to current user',
        'default' => '',
        'options' => [
          ''      => 'None',
          'true'  => 'Available',
          'false' => 'Unavailable',
        ],
      ],
      'progression' => [
        'type'    => 'select',
        'label'   => 'Limit by progression',
        'default' => '',
        'options' => [
          ''      => 'None',
          'true'  => 'User can progress to item',
          'false' => 'User cannot progress to item',
        ],
      ],
      'drip'        => [
        'type'    => 'select',
        'label'   => 'Limit by drip date',
        'default' => '',
        'options' => [
          ''       => 'None',
          'past'   => 'Drip: past',
          'future' => 'Drip: future',
        ],
      ],
    ],
  ],
]);
