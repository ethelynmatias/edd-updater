<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

set_settings_sections_template('quiz_table', [
  'quiz_table'            => [
    'title'  => 'Quiz Table',
    'fields' => [
      'quiz_table_visibility' => [
        'type'    => 'select',
        'label'   => 'Show quiz table',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'quiz_table_margin'     => [
        'type'        => 'dimension',
        'label'       => 'Margin',
        'description' => 'px',
        'preview'     => [
          'type'     => 'css',
          'selector' => '.fl-module-content .bdash-content-table--quiz-table',
          'property' => 'margin',
          'unit'     => 'px',
        ],
        'placeholder' => '0',
        'responsive'  => true,
      ],
    ],
  ], // Quizzes: Lesson Table
  'header'                => [
    'title'  => 'Header',
    'fields' => [
      'quiz_table_header_visibility'    => [
        'type'    => 'select',
        'label'   => 'Show quiz table header',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'quiz_table_header_quizzes_label' => [
        'type'    => 'text',
        'label'   => 'Quizzes column label',
        'default' => 'Quizzes',
      ],
      'quiz_table_header_status_label'  => [
        'type'    => 'text',
        'label'   => 'Status column label',
        'default' => 'Status',
      ],
    ],
  ], // Quizzes: Header
  'rows'                  => [
    'title'  => 'Rows',
    'fields' => [
      'quiz_table_rows_order_visibility' => [
        'type'    => 'select',
        'label'   => 'Show row order number',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'quiz_table_rows_order_prefix'     => [
        'type'    => 'text',
        'label'   => 'Row order number prefix',
        'default' => '',
      ],
      'quiz_table_rows_order_suffix'     => [
        'type'    => 'text',
        'label'   => 'Row order number suffix',
        'default' => '',
      ],
    ], // Quizzes: Rows - Fields
  ], // Quizzes: Rows
  'status'                => [
    'title'  => 'Status',
    'fields' => [
      'quiz_table_rows_status_icon_visibility' => [
        'type'    => 'select',
        'label'   => 'Show status icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ],
  ],
  'status_started'        => [
    'title'  => 'Status: Started',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'quiz_table_rows_status_',
      'suffix' => '__started',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Started',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--quiz-table .bdash-status-icon--started',
          ],
        ],
      ],
    ]),
  ],
  'status_completed'      => [
    'title'  => 'Status: Completed',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'quiz_table_rows_status_',
      'suffix' => '__complete',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Completed',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--quiz-table .bdash-status-icon--complete',
          ],
        ],
      ],
    ]),
  ],
  'certificate_indicator' => [
    'title'  => 'Indicator: Certificate',
    'fields' => [
      'quiz_table_rows_certificate_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show certificate indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'quiz_table_rows_certificate_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Certificate',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--quiz-table .bdash-certificate-indicator',
          ],
        ],
      ],
    ]),
  ], // Indicator: Certificate
]);
