<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

set_settings_sections_template('table', [
  'width'  => [
    'title'  => 'Width',
    'fields' => [
      'table_max_width' => [
        'type'        => 'text',
        'label'       => 'Max width - Leave empty for full width',
        'default'     => '660',
        'description' => 'px',
        'maxlength'   => '3',
        'size'        => '5',
        'placeholder' => '0',
        'sanitize'    => 'absint',
      ],
    ],
  ],
  'border' => [
    'title'  => 'Border',
    'fields' => [
      'table_border_width' => [
        'type'        => 'text',
        'label'       => 'Border width',
        'default'     => '1',
        'description' => 'px',
        'maxlength'   => '3',
        'size'        => '5',
        'placeholder' => '1',
        'sanitize'    => 'absint',
      ],
      'table_border_color' => [
        'type'        => 'color',
        'label'       => 'Border color',
        'default'     => 'ddd',
        'connections' => [ 'color' ],
        'show_reset'  => true,
      ],
    ],
  ],
]);
