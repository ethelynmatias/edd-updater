<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

set_settings_sections_template('style', [
  'typography' => [
    'title'  => 'Typography',
    'fields' => [
      'typography'         => utils\create_setting_fields( [ 'type' => 'typography' ] ),
      'current_typography' => [
        'type'       => 'typography',
        'label'      => __( 'Current item text', 'fl-builder' ),
        'responsive' => true,
        'preview'    => [
          'type'      => 'css',
          'selector'  => '{node} .fl-module-content .bdash-content-table--list-item-current .bdash-content-table--list-item-title, {node} .fl-module-content .bdash-content-table--list-item-current.bdash-content-table--child-item a',
          'important' => true,
        ],
      ],
    ],
  ],
]);
