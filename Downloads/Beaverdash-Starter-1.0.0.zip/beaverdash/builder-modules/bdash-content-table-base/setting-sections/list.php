<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

set_settings_sections_template('list', [
  'list'                  => [
    'title'  => 'Lesson Table',
    'fields' => [
      'main_table_visibility'          => [
        'type'    => 'select',
        'label'   => 'Show lesson table',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'expand_collapse_all_visibility' => [
        'type'    => 'select',
        'label'   => 'Show toggle to expand/collapse all lesson topics',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'expand_all_by_default'          => [
        'type'    => 'select',
        'label'   => 'Expand all lesson topic list by default',
        'default' => 'false',
        'options' => [
          'true'  => 'True',
          'false' => 'False',
        ],
      ],
      'link_unavailable'               => [
        'type'    => 'select',
        'label'   => 'Link to unavailable lessons',
        'default' => 'true',
        'options' => [
          'true'  => 'True',
          'false' => 'False',
        ],
      ],
      'main_table_margin'              => [
        'type'        => 'dimension',
        'label'       => 'Margin',
        'description' => 'px',
        'preview'     => [
          'type'     => 'css',
          'selector' => '.fl-module-content .bdash-content-table--main-table',
          'property' => 'margin',
          'unit'     => 'px',
        ],
        'placeholder' => '0',
        'responsive'  => true,
      ],
    ],
  ],
  'sections'              => [
    'title'  => 'Sections',
    'fields' => [
      'show_sections' => [
        'type'    => 'select',
        'label'   => 'Show sections',
        'default' => 'true',
        'options' => [
          'true'  => 'True',
          'false' => 'False',
        ],
      ],
    ],
  ],
  'header'                => [
    'title'  => 'Header',
    'fields' => [
      'main_table_header_visibility'   => [
        'type'    => 'select',
        'label'   => 'Show lesson table header',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'main_table_header_items_label'  => [
        'type'    => 'text',
        'label'   => 'Lessons column label',
        'default' => 'Lessons',
      ],
      'main_table_header_status_label' => [
        'type'    => 'text',
        'label'   => 'Status column label',
        'default' => 'Status',
      ],
    ],
  ], // Lessons: Header
  'rows'                  => [
    'title'  => 'Rows',
    'fields' => [
      'main_table_rows_order_visibility' => [
        'type'    => 'select',
        'label'   => 'Show row order number',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
      'main_table_rows_order_prefix'     => [
        'type'    => 'text',
        'label'   => 'Row order number prefix',
        'default' => '',
      ],
      'main_table_rows_order_suffix'     => [
        'type'    => 'text',
        'label'   => 'Row order number suffix',
        'default' => '',
      ],
    ], // Lessons: Rows - Fields
  ], // Lessons: Rows
  'expand_collapse'       => [
    'title'  => 'Expand/Collapse',
    'fields' => [
      'main_table_rows_toggle_visibility' => [
        'type'    => 'select',
        'label'   => 'Show expand/collapse toggle',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],

    ],
  ], // Lessons: Expand/Collapse

  'status'                => [
    'title'  => 'Status',
    'fields' => [
      'main_table_rows_status_icon_visibility' => [
        'type'    => 'select',
        'label'   => 'Show status icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ],
  ],
  'status_started'        => [
    'title'  => 'Status: Started',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'main_table_rows_status_',
      'suffix' => '__started',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Started',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--main-table .bdash-status-icon--started',
          ],
        ],
      ],
    ]),
  ],
  'status_completed'      => [
    'title'  => 'Status: Completed',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'main_table_rows_status_',
      'suffix' => '__completed',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Completed',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--main-table .bdash-status-icon--completed',
          ],
        ],
      ],
    ]),
  ],
  'status_locked'         => [
    'title'  => 'Status: Locked',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'main_table_rows_status_',
      'suffix' => '__locked',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Locked',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--main-table .bdash-status-icon--locked',
          ],
        ],
      ],
    ]),
  ],
  'video_indicator'       => [
    'title'  => 'Indicator: Video',
    'fields' => [
      'main_table_rows_video_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show video indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'main_table_rows_video_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Video',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--main-table .bdash-video-indicator',
          ],
        ],
      ],
    ]),
  ],
  'quiz_indicator'        => [
    'title'  => 'Indicator: Quiz',
    'fields' => [
      'main_table_rows_quiz_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show quiz indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'main_table_rows_quiz_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Quiz',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--main-table .bdash-quiz-indicator',
          ],
        ],
      ],
    ]),
  ],
  'certificate_indicator' => [
    'title'  => 'Indicator: Certificate',
    'fields' => [
      'main_table_rows_certificate_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show certificate indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'main_table_rows_certificate_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Certificate',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--main-table .bdash-certificate-indicator',
          ],
        ],
      ],
    ]),
  ],
]);
