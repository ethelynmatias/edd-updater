<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

set_settings_sections_template('child_list', [
  'child_list'            => [
    'title'  => 'Topic List',
    'fields' => [
      'child_list_visibility' => [
        'type'    => 'select',
        'label'   => 'Show topic list',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ],
  ],
  'status'                => [
    'title'  => 'Status',
    'fields' => [
      'child_list_status_icon_visibility' => [
        'type'    => 'select',
        'label'   => 'Show status icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ],
  ],
  'status_started'        => [
    'title'  => 'Status: Started',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'child_list_status_',
      'suffix' => '__started',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Started',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--child-list .bdash-status-icon--started',
          ],
        ],
      ],
    ]),
  ],
  'status_completed'      => [
    'title'  => 'Status: Completed',
    'fields' => utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'child_list_status_',
      'suffix' => '__complete',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Completed',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--child-list .bdash-status-icon--complete',
          ],
        ],
      ],
    ]),
  ],
  'video_indicator'       => [
    'title'  => 'Indicator: Video',
    'fields' => [
      'child_list_video_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show video indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'child_list_video_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Video',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--child-list .bdash-video-indicator',
          ],
        ],
      ],
    ]),
  ],
  'quiz_indicator'        => [
    'title'  => 'Indicator: Quiz',
    'fields' => [
      'child_list_quiz_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show quiz indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'child_list_quiz_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Quiz',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--child-list .bdash-quiz-indicator',
          ],
        ],
      ],
    ]),
  ],
  'certificate_indicator' => [
    'title'  => 'Indicator: Certificate',
    'fields' => [
      'child_list_certificate_indicator_visibility' => [
        'type'    => 'select',
        'label'   => 'Show certificate indicator icon',
        'default' => 'true',
        'options' => [
          'true'  => 'Show',
          'false' => 'Hide',
        ],
      ],
    ] + utils\create_setting_fields([
      'type'   => 'icon',
      'prefix' => 'child_list_certificate_indicator_',
      'custom' => [
        'icon_text_on_hover' => [
          'default' => 'Certificate',
        ],
        'icon_padding'       => [
          'preview' => [
            'selector' => '.fl-module-content .bdash-content-table--child-list .bdash-certificate-indicator',
          ],
        ],
      ],
    ]),
  ],
]);
