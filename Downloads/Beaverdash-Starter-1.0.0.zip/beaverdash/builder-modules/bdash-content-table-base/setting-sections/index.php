<?php

namespace BeaverDash\content_table;

use \BeaverDash\utils as utils;

beaverdash()->state['content_table/setting_sections_templates'] = [];

function set_settings_sections_template( $type, $sections ) {
  beaverdash()->state['content_table/setting_sections_templates'][ $type ] = $sections;
}

function get_settings_sections_template( $type ) {
  return beaverdash()->state['content_table/setting_sections_templates'][ $type ];
}

require __DIR__ . '/table.php';
require __DIR__ . '/list.php';
require __DIR__ . '/child-list.php';
require __DIR__ . '/quiz-table.php';
require __DIR__ . '/limit-items.php';
require __DIR__ . '/style.php';

function create_setting_sections( $config, $sections_template = [] ) {

  $type = $config['type'];

  if ( empty( $sections_template ) ) {
    $sections_template = get_settings_sections_template( $type );
  }

  $custom = isset( $config['custom'] ) ? $config['custom'] : [];

  $sections = [];

  foreach ( $sections_template as $section_name => $section_config ) {

    if (isset( $custom[ $section_name ] ) && $custom[ $section_name ] === false) continue;

    $sections[ $section_name ] = [];

    foreach ( $section_config as $key => $value ) {

      if ( ! is_array( $value ) ) {
        $sections[ $section_name ][ $key ] =
          isset( $custom[ $section_name ] )
          && isset( $custom[ $section_name ][ $key ] )
            ? $custom[ $section_name ][ $key ]
            : $value;
        continue;
      }

      // Merge fields

      $sections[ $section_name ][ $key ] = [];

      foreach ( $value as $field_name => $field_config ) {

        $field_custom = isset( $custom[ $section_name ] )
          && isset( $custom[ $section_name ][ $key ] )
          && isset( $custom[ $section_name ][ $key ][ $field_name ] )
            ? $custom[ $section_name ][ $key ][ $field_name ]
            : [];

        if ($key === 'fields' && $field_custom === false) continue;

        $sections[ $section_name ][ $key ][ $field_name ] = array_merge( $field_config, $field_custom );
      }
    }

    // if ($section_name==='list') \BetterDash\see($sections[$section_name]);
  }

  return $sections;
}
