<?php

class BDash_Breadcrumb extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Breadcrumb', 'beaverdash' ),
      'description' => __( 'Display post content of course/lesson/topic/quiz', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Content', 'beaverdash' ),
      'icon'        => 'arrow-right.svg',
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
    ));
  }
}

FLBuilder::register_module('BDash_Breadcrumb', [
  'general' => [
    'title'    => __( 'General', 'fl-builder' ),
    'sections' => [
      'general' => [
        'title'  => 'General',
        'fields' => [
          'is_permalink'           => [
            'type'    => 'select',
            'label'   => __( 'Links', 'beaverdash' ),
            'default' => 'true',
            'options' => [
              'true'  => __( 'Yes', 'beaverdash' ),
              'false' => __( 'No', 'beaverdash' ),
            ],
          ],
          'highlight_current_item' => [
            'type'    => 'select',
            'label'   => __( 'Hightlight current position', 'beaverdash' ),
            'default' => 'true',
            'options' => [
              'true'  => __( 'Yes', 'beaverdash' ),
              'false' => __( 'No', 'beaverdash' ),
            ],
          ],
          'separator'              => [
            'type'    => 'select',
            'label'   => __( 'Separator', 'beaverdash' ),
            'default' => '\3E',
            'options' => [
              'none' => 'none',
              '\3E'  => '>',
              '/'    => '/',
              '-'    => '-',
            ],
          ],
        ],
      ],
    ],
  ],
  'style'   => [
    'title'    => __( 'Style', 'fl-builder' ),
    'sections' => [
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'typography'         => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
          'typography_current' => [
            'type'       => 'typography',
            'label'      => __( 'Current page', 'fl-builder' ),
            'responsive' => true,
            'preview'    => [
              'type'      => 'css',
              'selector'  => '{node} .fl-module-content .bdash-breadcrumbs-current-item',
              'important' => true,
            ],
          ],
        ],
      ],
      'colors'     => [
        'title'  => 'Colors',
        'fields' => [
          'breadcrumb_text_color'         => [
            'type'        => 'color',
            'label'       => 'Text color',
            'default'     => '111111',
            'connections' => [ 'color' ],
          ],
          'breadcrumb_current_text_color' => [
            'type'        => 'color',
            'label'       => 'Current page text color',
            'default'     => '000000',
            'connections' => [ 'color' ],
          ],
          'separator_color'               => [
            'type'        => 'color',
            'label'       => 'Separator color',
            'default'     => '222222',
            'connections' => [ 'color' ],
          ],
        ],
      ],
    ],
  ],
]);
