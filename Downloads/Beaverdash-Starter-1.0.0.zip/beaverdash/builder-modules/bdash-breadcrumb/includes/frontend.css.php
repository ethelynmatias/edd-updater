<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";
$el = "$prefix .bdash-breadcrumbs";

utils\render_module_css([
    'prefix' => $el,
    'elements' => [
    [ 'types' => ['typography'] ],
  ],
], $settings, $global_settings);


\FLBuilderCSS::typography_field_rule( array(
  'settings'     => $settings,
  'setting_name' => 'typography_current',
  'selector'     => $prefix,
) );

if (isset($settings->breadcrumb_text_color)) {
  ?><?= $el ?> .bdash-breadcrumbs-item { color: #<?= $settings->breadcrumb_text_color; ?>; }<?php
}

if (isset($settings->breadcrumb_current_text_color)) {
  ?><?= $el ?> span.bdash-breadcrumbs-current-item { color: #<?= $settings->breadcrumb_current_text_color; ?> !important; }<?php
}

if (isset($settings->separator_color)) {
  ?><?= $el ?> li:after { color: <?= $settings->separator_color; ?>; }<?php
}

if (isset($settings->separator) && $settings->separator !== 'none') {
  ?><?= $el ?> li:after { content: '<?= $settings->separator; ?>'; }<?php
}
