<?php

\BeaverDash\post_list\render_loop( $id, $module, $settings );
