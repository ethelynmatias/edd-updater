<?php

\BeaverDash\post_list\render_css($id, $module, $settings, $global_settings);
