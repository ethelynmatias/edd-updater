<?php

class BDash_Lesson_List extends BDash_Post_List_Base {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Lesson List', 'beaverdash' ),
      'description' => __( 'Display a list of lessons', 'beaverdash' ),
      'category'    => __( 'Lesson', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      'icon'        => 'text.svg',

      // Extended module args
      'module_slug' => 'bdash-lesson-list',
      'post_type'   => 'sfwd-lessons',
    ));
  }
}

\BeaverDash\post_list\register_module( 'BDash_Lesson_List' );
