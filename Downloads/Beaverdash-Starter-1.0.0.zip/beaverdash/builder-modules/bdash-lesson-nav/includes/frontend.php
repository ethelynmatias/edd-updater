<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\lesson_navigation(
  utils\module_atts( $settings, $module )
);
