<?php

class BDash_Quiz_Grid extends BDash_Post_Grid_Base {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Quiz Grid', 'beaverdash' ),
      'description' => __( 'Display a grid of quizzes', 'beaverdash' ),
      'category'    => __( 'Quiz', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      'icon'        => 'schedule.svg',

      // Extended module args
      'module_slug' => 'bdash-quiz-grid',
      'post_type'   => 'sfwd-quiz',
    ));
  }
}

\BeaverDash\post_grid\register_module( 'BDash_Quiz_Grid' );
