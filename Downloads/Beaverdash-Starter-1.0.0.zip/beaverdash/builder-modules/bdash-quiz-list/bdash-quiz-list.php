<?php

class BDash_Quiz_List extends BDash_Post_List_Base {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Quiz List', 'beaverdash' ),
      'description' => __( 'Display a list of quizzes', 'beaverdash' ),
      'category'    => __( 'Quiz', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      'icon'        => 'text.svg',

      // Extended module args
      'module_slug' => 'bdash-quiz-list',
      'post_type'   => 'sfwd-quiz',
    ));
  }
}

\BeaverDash\post_list\register_module( 'BDash_Quiz_List' );
