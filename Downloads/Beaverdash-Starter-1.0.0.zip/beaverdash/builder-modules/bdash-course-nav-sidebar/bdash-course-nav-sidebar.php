<?php

use BeaverDash\utils;

class BDash_Course_Nav_Sidebar extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'            => __( 'Course Navigation Sidebar', 'beaverdash' ),
      'description'     => __( 'Course navigation menu', 'beaverdash' ),
      'group'           => beaverdash()->state['module_group_name'],
      'category'        => __( 'Course', 'beaverdash' ),
      'dir'             => __DIR__,
      'url'             => plugins_url( '', __FILE__ ),
      'partial_refresh' => true,
      'icon'            => 'location.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Course_Nav_Sidebar', [
  'table' => [
    'title'    => 'Style',
    'sections' => [
      'typography'    => [
        'title'  => 'Typography',
        'fields' => [
          'typography' => \BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
        ],
      ],
      'custom_styles' => [
        'title'  => 'Colors',
        'fields' => [
          'course_nav_primary_color'             => [
            'type'        => 'color',
            'label'       => 'Primary color',
            'default'     => '80d642',
            'connections' => [ 'color' ],
          ],
          'course_nav_text_color'                => [
            'type'        => 'color',
            'label'       => 'Text color',
            'default'     => '555555',
            'connections' => [ 'color' ],
          ],
          'course_nav_lesson_content_background' => [
            'type'        => 'color',
            'label'       => 'Lesson content background',
            'default'     => 'f0f3f6',
            'connections' => [ 'color' ],
          ],
        ],
      ],
    ],
  ],
]);
