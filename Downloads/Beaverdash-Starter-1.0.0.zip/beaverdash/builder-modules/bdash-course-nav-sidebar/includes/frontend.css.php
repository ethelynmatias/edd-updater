<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";
$el = "$prefix .bdash-navigation-sidebar";
 
utils\render_module_css([
    'prefix'    => $el,
    'elements'  => [
    [ 'types' => ['typography'] ],
  ],
], $settings, $global_settings);


if (isset($settings->course_nav_primary_color)) {
  ?><?= $el ?>.learndash-wrapper .ld-expand-button.ld-button-alternate .ld-icon { background-color: #<?= $settings->course_nav_primary_color; ?> !important; }<?php

  ?><?= $el ?>.learndash-wrapper .ld-primary-color { color: #<?= $settings->course_nav_primary_color; ?> !important; }<?php

  ?><?= $el ?>.learndash-wrapper .ld-primary-color-hover:hover { color: #<?= $settings->course_nav_primary_color; ?> !important; }<?php

  ?><?= $el ?>.learndash-wrapper .ld-primary-color-hover:hover { color: #<?= $settings->course_nav_primary_color; ?> !important; }<?php
}

if (isset($settings->course_nav_text_color)) {
  ?><?= $el ?>.learndash-wrapper .ld-course-navigation .ld-lesson-item-preview a.ld-lesson-item-preview-heading { color: #<?= $settings->course_nav_text_color; ?>; }<?php

  ?><?= $el ?>.learndash-wrapper .ld-table-list a.ld-table-list-item-preview { color: #<?= $settings->course_nav_text_color; ?>; }<?php
}

if (isset($settings->course_nav_lesson_content_background)) {
  ?><?= $el ?>.learndash-wrapper .ld-course-navigation .ld-lesson-item-expanded { background-color: #<?= $settings->course_nav_lesson_content_background; ?>; }<?php
}
