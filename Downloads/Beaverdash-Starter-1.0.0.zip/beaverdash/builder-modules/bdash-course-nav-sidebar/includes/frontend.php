<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\navigation_sidebar(
  utils\module_atts( $settings, $module )
);
