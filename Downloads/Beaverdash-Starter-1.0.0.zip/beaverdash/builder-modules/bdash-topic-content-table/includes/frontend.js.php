jQuery(document).ready(function($) {

  var activate = window.BDash && window.BDash.activateContentTable
	var selector = '.fl-node-<?= $id ?> .bdash-topic-content-table'

  if (activate) activate(selector)

});