<?php

use BeaverDash\content_table;

class BDash_Topic_Content_Table extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Topic Content Table', 'beaverdash' ),
      'description' => __( 'Display topic content table', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Topic', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'editor-table.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Topic_Content_Table', [
  'table'       => [
    'title'    => 'Table',
    'sections' => content_table\create_setting_sections( [ 'type' => 'table' ] ),
  ],
  'list'        => [
    'title'    => 'Quizzes',
    'sections' => content_table\create_setting_sections([
  'type'   => 'list',
  'custom' => [
      'list'            => [
        'title'  => 'Quiz Table',
        'fields' => [
          'main_table_visibility'          => [
            'label' => 'Show quiz table',
          ],
          'expand_collapse_all_visibility' => false,
          'expand_all_by_default'          => false,
          'link_unavailable'               => [
            'label' => 'Link to unavailable quizzes',
          ],
        ],
      ],
      'header'          => [
        'fields' => [
          'main_table_header_visibility'  => [
            'label' => 'Show quiz table header',
          ],
          'main_table_header_items_label' => [
            'label'   => 'Quizzes column label',
            'default' => 'Quizzes',
          ],
        ],
      ],
      'expand_collapse' => false,
      'indicator_video' => false,
      'indicator_quiz'  => false,
    ],
    ]),
  ],
  'limit_items' => [
    'title'    => 'Limit Items',
    'sections' => content_table\create_setting_sections( [ 'type' => 'limit_items' ] ),
  ],
  'style'       => [
    'title'    => 'Style',
    'sections' => content_table\create_setting_sections( [ 'type' => 'style' ] ),
  ],
]);
