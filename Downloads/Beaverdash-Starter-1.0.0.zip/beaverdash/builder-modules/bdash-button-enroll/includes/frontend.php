<?php

namespace BeaverDash;

use BetterDash as bdash;

// Based on vendor/tangible/betterdash/buttons/enroll

// Display nothing if user is already enrolled in current course
if ( \FLBuilderModel::is_builder_active() || ! empty( bdash\visitor() ) ) {

  global $post;

  $user_id   = get_current_user_id();
  $course_id = (int) learndash_get_course_id( $post );
  $course    = get_post( $course_id );

  // "Take this course"
  $button_text = ! empty( $settings->text )
    ? $settings->text
    : \LearnDash_Custom_Label::get_label( 'button_take_this_course' );

  if ( bdash\utils\is_ld3( false ) ) {

    /**
     * @see sfwd-lms\themes\ld30\templates\modules\infobar\course.php
     */
    $input = \learndash_payment_buttons( $post );

    // If course is closed and user not in course
    if ( empty( $input ) && ! \FLBuilderModel::is_builder_active() && bdash\course_price_type() === 'closed' ) {
      echo isset( $settings->text_closed ) ? "<span class='bdash-enroll-closed'>" . $settings->text_closed . '<span>' : '';
      return;
    }

    // User already enrolled
    if (empty( $input ) && ! \FLBuilderModel::is_builder_active()) return '';

    // If the builder already complete the course in the builder, we simulate a response
    if (empty( $input )) {
      $input = '<form><input type="text" hidden=""/></form>';
    }

    $dom = new \DOMDocument();
    @$dom->loadHTML( $input );

    // We get the form from the ld function output
    $form = $dom->getElementsByTagName( 'form' )[0];

    // By default, the enroll button is a form submit.
    // However, when the course is closed, it's a single link.
    $is_enroll_form = true;

    // If form is null, $input is a single <a> element.
    if ( ! $form ) {

      $link = $dom->getElementsByTagName( 'a' )[0];

      if ( $link ) {

        // Create dummy form

        $is_enroll_form = false;
        $enroll_url = $link->getAttribute('href');

        @$dom->loadHTML(
          '<form><input type="text" hidden=""/></form>'
        );

        $form = $dom->getElementsByTagName( 'form' )[0];

      } else {
        // Not a form or link
        echo $input;
        return;
      }
    }

    $form->setAttribute( 'class', $module->get_classname() );

    // We hide the default input
    $nodes = $dom->getElementsByTagName( 'input' );
    foreach ( $nodes as $node ) {
      $node->setAttribute( 'hidden', '' );
    }

    // Create our button with our settings
    $button = $dom->createElement( 'button' );

    $button->setAttribute( 'type', 'submit' );

    $enable  = 'enable' == $settings->icon_animation ? 'fl-button-icon-animation' : '';
    $classes = 'fl-button ' . $enable;
    $button->setAttribute( 'class', $classes );


    // Icon
    if ( ! empty( $settings->icon ) && (
          'before' == $settings->icon_position || ! isset( $settings->icon_position )
    ) ) {
      $icon_before         = $dom->createElement( 'i' );
      $icon_before_classes = 'fl-button-icon fl-button-icon-before ' . $settings->icon;
      $icon_before->setAttribute( 'class', $icon_before_classes );
      $button->appendChild( $icon_before );
    }

    // Text
    $text = $dom->createElement( 'span', $button_text );
    $text->setAttribute( 'class', 'fl-button-text' );
    $button->appendChild( $text );

    if ( ! empty( $settings->icon ) && 'after' == $settings->icon_position ) {
      $icon_after         = $dom->createElement( 'i' );
      $icon_after_classes = 'fl-button-icon fl-button-icon-after ' . $settings->icon;
      $icon_after->setAttribute( 'class', $icon_after_classes );
      $button->appendChild( $icon_after );
    }

    if ( ! $is_enroll_form ) {

      // Wrap button in a link

      $button->setAttribute( 'type', 'button' );

      $link = $dom->createElement( 'a' );
      $link->setAttribute('href', $enroll_url);
      $link->appendChild( $button );

      $button = $link;
    }

    // Add our button to the form
    $form->appendChild( $button );

    echo $form->c14n();

  } else {

    // LearnDash 3 and above

    ?>
    <form method="post" class="<?= $module->get_classname() ?>">

      <input type="hidden" name="course_id" value="<?= $course_id ?>" />
      <input type="hidden" name="course_join" value="<?=
        wp_create_nonce( 'course_join_' . $user_id . '_' . $course_id )
      ?>" />

      <button type="submit" class="fl-button<?=
      'enable' == $settings->icon_animation ? ' fl-button-icon-animation' : ''
      ?>">
        <?php

        if ( ! empty( $settings->icon ) && (
        'before' == $settings->icon_position || ! isset( $settings->icon_position )
        ) ) {
          ?><i class="fl-button-icon fl-button-icon-before <?= $settings->icon; ?>"></i><?php
        }

        ?><span class="fl-button-text"><?= $button_text ?></span><?php

        if ( ! empty( $settings->icon ) && 'after' == $settings->icon_position ) {
          ?><i class="fl-button-icon fl-button-icon-after <?= $settings->icon ?>"></i><?php
        }

        ?>
      </button>
    </form>
    <?php
  }
}
