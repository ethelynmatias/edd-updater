<?php

namespace BeaverDash;

use BetterDash as bdash;

$direction = @$settings->nav_direction;
$type      = @$settings->content_type;

$link  = '';
$label = '';

if ( $direction === 'parent' ) {
  if ( $type === 'any' ) {
    $link  = bdash\parent_url();
    $label = bdash\parent_label();
  } elseif ( $type === 'course' ) {
    $link  = bdash\parent_course_url();
    $label = bdash\back_to_course_label();
  } elseif ( $type === 'lesson' ) {
    $link  = bdash\parent_lesson_url();
    $label = bdash\back_to_lesson_label();
  } elseif ( $type === 'topic' ) {
    $link  = bdash\parent_topic_url();
    $label = bdash\back_to_topic_label();
  }
} elseif ( $direction === 'prev' ) {
  if ( $type === 'any' ) {
    $link  = bdash\previous_link( [ 'field' => 'url' ] );
    $label = bdash\previous_link( [ 'field' => 'label' ] );
  } elseif ( $type === 'course' ) {
    /*
     TODO: ?
    $link = bdash\previous_course_url();
    $label = bdash\previous_course_label();*/
  } elseif ( $type === 'lesson' ) {
    $link  = bdash\previous_lesson_url();
    $label = bdash\previous_lesson_label();
  } elseif ( $type === 'topic' ) {
    $link  = bdash\previous_topic_url();
    $label = bdash\previous_topic_label();
  } elseif ( $type === 'quiz' ) {
    $link  = bdash\previous_quiz_url();
    $label = bdash\previous_quiz_label();
  }
} elseif ( $direction === 'next' ) {
  if ( $type === 'any' ) {
    $link  = bdash\next_link( [ 'field' => 'url' ] );
    $label = bdash\next_link( [ 'field' => 'label' ] );
  } elseif ( $type === 'course' ) {
    /*
     TODO: ?
    $link = bdash\next_course_url();
    $label = bdash\next_course_label();*/
  } elseif ( $type === 'lesson' ) {
    $link  = bdash\next_lesson_url();
    $label = bdash\next_lesson_label();
  } elseif ( $type === 'topic' ) {
    $link  = bdash\next_topic_url();
    $label = bdash\next_topic_label();
  } elseif ( $type === 'quiz' ) {
    $link  = bdash\next_quiz_url();
    $label = bdash\next_quiz_label();
  }
}

if ( ! empty( $settings->text )) $label = $settings->text;

$notice = '';

if ( empty( $link ) ) {

  // Display nothing if no item found
  $label = '';

  // Notice for editor
  if ( class_exists( '\FLBuilderModel' ) && \FLBuilderModel::is_builder_active() ) {
    $notice = 'Editor note: the button will display only if item is found and accessible by user.';
    $label  =
      ( $direction === 'prev' ? 'Previous' : ucfirst( $direction ) )
      . ' '
      . ( $type === 'any' ? 'Item' : ucfirst( $type ) );
  }
}

if ( ! empty( $label ) ) {

  ?>

  <?php
  if ( isset( $settings->button_style ) && $settings->button_style === 'learndash' ) :
    $link_class = isset( $settings->button_style ) && $settings->button_style === 'learndash' ? 'ld-button' : '';
    ?>
  <div class="learndash-wrapper">
    <div class="ld-content-actions" style="border: none">
      <div class="ld-content-action">
        <a class="<?= $link_class ?>" href="<?php echo $link; ?>" target="_self" class="fl-button" role="button" >
          <?php if ( $direction === 'prev' || $direction === 'parent' ) : ?>
            <span class="ld-icon ld-icon-arrow-left"></span>
          <?php endif; ?>
          <span class="ld-text"><?= $label ?></span>
          <?php if ( $direction === 'next' ) : ?>
            <span class="ld-icon ld-icon-arrow-right"></span>
          <?php endif; ?>
        </a>
      </div>
    </div>
  </div>
  <?php else : ?>  
  <div class="<?php echo $module->get_classname(); ?>">
    <a href="<?php echo $link; ?>" target="_self" class="fl-button<?php
    if ( 'enable' == $settings->icon_animation ) {
      ?> fl-button-icon-animation<?php
    }
    ?>" role="button">
        <?php

        if ( ! empty( $settings->icon ) && (
        'before' == $settings->icon_position || ! isset( $settings->icon_position )
        ) ) {
          ?><i class="fl-button-icon fl-button-icon-before <?= $settings->icon; ?>"></i>&nbsp;<?php
        }

        ?><span class="fl-button-text"><?= $label ?></span><?php

if ( ! empty( $settings->icon ) && 'after' == $settings->icon_position ) {
  ?>&nbsp;<i class="fl-button-icon fl-button-icon-after <?= $settings->icon ?>"></i><?php
}
?>
    </a>
  </div>
    <?php
endif;

}

if ( ! empty( $notice ) ) {

  ?><p><i><?= $notice ?></i></p><?php

}
