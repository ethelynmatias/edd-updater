<?php

use BetterDash as bdash;

class BDash_Button_Nav extends FLBuilderModule {

  /**
   * @method __construct
   */
  public function __construct() {
    parent::__construct(array(
      'name'            => __( 'Navigation', 'beaverdash' ),
      'description'     => __( 'Navigation button', 'beaverdash' ),
      'group'           => beaverdash()->state['module_group_name'],
      'category'        => __( 'Button', 'beaverdash' ),
      'dir'             => __DIR__,
      'url'             => plugins_url( '', __FILE__ ),
      'partial_refresh' => true,
      'icon'            => 'button.svg',
    ));
  }

  public function get_classname() {
    $classname = 'fl-button-wrap bdash-button-wrap';

    if ( ! empty( $this->settings->width ) ) {
      $classname .= ' fl-button-width-' . $this->settings->width;
    }
    if ( ! empty( $this->settings->align ) ) {
      $classname .= ' fl-button-' . $this->settings->align;
    }
    if ( ! empty( $this->settings->icon ) ) {
      $classname .= ' fl-button-has-icon';
    }

    return $classname;
  }
}

$fields = array(
  'general' => array(
    'title'    => __( 'General', 'fl-builder' ),
    'sections' => array(
      'general' => array(
        'title'  => '',
        'fields' => array(

          'nav_direction'  => [
            'type'    => 'select',
            'label'   => __( 'Direction', 'beaverdash' ),
            'default' => 'next',
            'options' => [
              'next'   => __( 'Next', 'beaverdash' ),
              'prev'   => __( 'Previous', 'beaverdash' ),
              'parent' => __( 'Parent', 'beaverdash' ),
            ],
          ],
          'content_type'   => [
            'type'    => 'select',
            'label'   => __( 'Content Type', 'beaverdash' ),
            'default' => 'any',
            'options' => [
              'any'    => __( 'Any', 'beaverdash' ),
              'course' => __( 'Course', 'beaverdash' ),
              'lesson' => __( 'Lesson', 'beaverdash' ),
              'topic'  => __( 'Topic', 'beaverdash' ),
              'quiz'   => __( 'Quiz', 'beaverdash' ),
            ],
          ],

          'text'           => array(
            'type'    => 'text',
            'label'   => __( 'Text', 'fl-builder' ),
            'default' => __( '', 'fl-builder' ),
            'help'    => 'Leave empty to use default label',
            'preview' => array(
              'type'     => 'text',
              'selector' => '.fl-button-text',
            ),
            // 'connections'         => array( 'string' ),
          ),
          'button_style'   => [
            'type'    => 'select',
            'label'   => __( 'Style of the button', 'beaverdash' ),
            'default' => 'custom',
            'options' => [
              'custom'    => __( 'Custom', 'beaverdash' ),
              'learndash' => __( 'Learndash', 'beaverdash' ),
            ],
            'toggle'  => [
              'custom' => [
                'fields' => [
                  'icon',
                  'icon_position',
                  'icon_animation',
                ],
              ],
            ],
          ],
          'icon'           => array(
            'type'        => 'icon',
            'label'       => __( 'Icon', 'fl-builder' ),
            'show_remove' => true,
          ),
          'icon_position'  => array(
            'type'    => 'select',
            'label'   => __( 'Icon Position', 'fl-builder' ),
            'default' => 'before',
            'options' => array(
              'before' => __( 'Before Text', 'fl-builder' ),
              'after'  => __( 'After Text', 'fl-builder' ),
            ),
          ),
          'icon_animation' => array(
            'type'    => 'select',
            'label'   => __( 'Icon Visibility', 'fl-builder' ),
            'default' => 'disable',
            'options' => array(
              'disable' => __( 'Always Visible', 'fl-builder' ),
              'enable'  => __( 'Fade In On Hover', 'fl-builder' ),
            ),
          ),
        ),
      ),
    ),
  ),
  'style'   => array(
    'title'    => __( 'Style', 'fl-builder' ),
    'sections' => array(
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'typography' => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
        ],
      ],
      'colors'     => array(
        'title'  => __( 'Colors', 'fl-builder' ),
        'fields' => array(
          'bg_color'         => array(
            'type'        => 'color',
            'label'       => __( 'Background Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
          ),
          'bg_hover_color'   => array(
            'type'        => 'color',
            'label'       => __( 'Background Hover Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => array(
              'type' => 'none',
            ),
          ),
          'text_color'       => array(
            'type'        => 'color',
            'label'       => __( 'Text Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
          ),
          'text_hover_color' => array(
            'type'        => 'color',
            'label'       => __( 'Text Hover Color', 'fl-builder' ),
            'default'     => '',
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => array(
              'type' => 'none',
            ),
          ),
        ),
      ),
      'style'      => array(
        'title'  => __( 'Style', 'fl-builder' ),
        'fields' => array(
          'style'             => array(
            'type'    => 'select',
            'label'   => __( 'Style', 'fl-builder' ),
            'default' => 'flat',
            'options' => array(
              'flat'        => __( 'Flat', 'fl-builder' ),
              'gradient'    => __( 'Gradient', 'fl-builder' ),
              'transparent' => __( 'Transparent', 'fl-builder' ),
            ),
            'toggle'  => array(
              'transparent' => array(
                'fields' => array( 'bg_opacity', 'bg_hover_opacity', 'border_size' ),
              ),
            ),
          ),
          'border_size'       => array(
            'type'        => 'text',
            'label'       => __( 'Border Size', 'fl-builder' ),
            'default'     => '2',
            'description' => 'px',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '0',
            'sanitize'    => 'absint',
          ),
          'bg_opacity'        => array(
            'type'        => 'text',
            'label'       => __( 'Background Opacity', 'fl-builder' ),
            'default'     => '0',
            'description' => '%',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '0',
            'sanitize'    => 'absint',
          ),
          'bg_hover_opacity'  => array(
            'type'        => 'text',
            'label'       => __( 'Background Hover Opacity', 'fl-builder' ),
            'default'     => '0',
            'description' => '%',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '0',
            'sanitize'    => 'absint',
          ),
          'button_transition' => array(
            'type'    => 'select',
            'label'   => __( 'Transition', 'fl-builder' ),
            'default' => 'disable',
            'options' => array(
              'disable' => __( 'Disabled', 'fl-builder' ),
              'enable'  => __( 'Enabled', 'fl-builder' ),
            ),
          ),
        ),
      ),
      'formatting' => array(
        'title'  => __( 'Structure', 'fl-builder' ),
        'fields' => array(
          'width'         => array(
            'type'    => 'select',
            'label'   => __( 'Width', 'fl-builder' ),
            'default' => 'auto',
            'options' => array(
              'auto'   => _x( 'Auto', 'Width.', 'fl-builder' ),
              'full'   => __( 'Full Width', 'fl-builder' ),
              'custom' => __( 'Custom', 'fl-builder' ),
            ),
            'toggle'  => array(
              'auto'   => array(
                'fields' => array( 'align' ),
              ),
              'full'   => array(),
              'custom' => array(
                'fields' => array( 'align', 'custom_width' ),
              ),
            ),
          ),
          'custom_width'  => array(
            'type'        => 'text',
            'label'       => __( 'Custom Width', 'fl-builder' ),
            'default'     => '200',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
          'align'         => array(
            'type'    => 'select',
            'label'   => __( 'Alignment', 'fl-builder' ),
            'default' => 'left',
            'options' => array(
              'center' => __( 'Center', 'fl-builder' ),
              'left'   => __( 'Left', 'fl-builder' ),
              'right'  => __( 'Right', 'fl-builder' ),
            ),
          ),
          'font_size'     => array(
            'type'        => 'text',
            'label'       => __( 'Font Size', 'fl-builder' ),
            'default'     => '',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
          'padding'       => array(
            'type'        => 'text',
            'label'       => __( 'Padding', 'fl-builder' ),
            'default'     => '',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
          'border_radius' => array(
            'type'        => 'text',
            'label'       => __( 'Round Corners', 'fl-builder' ),
            'default'     => '',
            'maxlength'   => '3',
            'size'        => '4',
            'description' => 'px',
          ),
        ),
      ),
    ),
  ),
);

if ( ! bdash\utils\is_ld3() ) {
  unset( $fields['general']['sections']['general']['fields']['button_style'] );
}

FLBuilder::register_module( 'BDash_Button_Nav', $fields );
