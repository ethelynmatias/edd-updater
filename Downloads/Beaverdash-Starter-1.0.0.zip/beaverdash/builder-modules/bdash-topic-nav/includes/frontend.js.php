jQuery(document).ready(function($) {

  var activate = window.BDash && window.BDash.activateNavigation
	var selector = '.fl-node-<?= $id ?> .bdash-topic-navigation'

  if (activate) activate(selector)

});