<?php

use BeaverDash\utils as utils;

utils\render_module_css([
  'prefix' => ".fl-node-$id .fl-module-content",
  'elements' => [

    [ 'el' => '.bdash-topic-list .bdash-topic',
      'setting_prefix' => 'topic_',
      'types' => ['text', 'link', 'spacing'],
    ],
    [ 'el' => '.bdash-topic-list .bdash-topic.learndash-current-menu-item',
      'setting_prefix' => 'topic_current_',
      'types' => ['link'],
    ],
    [ 'el' => '.bdash-quiz',
      'setting_prefix' => 'quiz_',
      'types' => ['text', 'link'],
    ],
    [ 'el' => '.bdash-quiz-list .bdash-quiz.learndash-current-menu-item',
      'setting_prefix' => 'quiz_current_',
      'types' => ['link'],
    ],

    [ 'el' => '.bdash-topic-quiz',
      'setting_prefix' => 'topic_quiz_',
      'types' => ['spacing'],
    ],

    [ 'el' => '.bdash-content-table .bdash-navigation .bdash-status-icon--started',
      'setting_prefix' => 'main_list_status_',
      'setting_suffix' => '__started',
      'types' => ['icon'],
    ],
    [ 'el' => '.bdash-content-table .bdash-navigation .bdash-status-icon--completed',
      'setting_prefix' => 'main_list_status_',
      'setting_suffix' => '__completed',
      'types' => ['icon'],
    ],
    [ 'el' => '.bdash-content-table .bdash-navigation .bdash-status-icon--locked',
      'setting_prefix' => 'main_list_status_',
      'setting_suffix' => '__locked',
      'types' => ['icon'],
    ],
    [ 'el' => '.bdash-content-table .bdash-navigation .bdash-video-indicator',
      'setting_prefix' => 'main_list_video_indicator_',
      'types' => ['icon'],
    ],
    [ 'el' => '.bdash-content-table .bdash-navigation .bdash-quiz-indicator',
      'setting_prefix' => 'main_list_quiz_indicator_',
      'types' => ['icon'],
    ],
    [ 'el' => '.bdash-content-table .bdash-navigation .bdash-certificate-indicator',
      'setting_prefix' => 'main_list_certificate_indicator_',
      'types' => ['icon'],
    ],
  ],
], $settings, $global_settings);

?>