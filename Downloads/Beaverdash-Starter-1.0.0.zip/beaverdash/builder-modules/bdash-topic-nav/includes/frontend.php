<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\topic_navigation(
  utils\module_atts( $settings, $module )
);
