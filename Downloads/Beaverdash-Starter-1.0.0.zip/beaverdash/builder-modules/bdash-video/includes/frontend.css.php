<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;
use BetterDash as bdash;

$prefix = ".fl-node-$id .fl-module-content";

utils\render_module_css([
  'prefix' => $prefix,
  'elements' => [
    [ 'el' => '.bdash-video',
      'setting_prefix' => 'video_',
      'types' => ['border', 'box-shadow'],
    ],
    [ 'el' => '.bdash-image',
      'setting_prefix' => 'image_',
      'types' => ['border', 'box-shadow'],
    ],
  ]
], $settings, $global_settings);

// Border
\FLBuilderCSS::border_field_rule( array(
  'settings'     => $settings,
  'setting_name' => 'video_border',
  'selector'     => $prefix . ' .bdash-video',
) );

// Controls (if not youtube)
if(isset($settings->video_hide_control) && $settings->video_hide_control === 'true') {?>
  <?= $prefix ?> .bdash-video .ld-video .mejs-controls{ 
    display: none;
  } <?php
}

// For aligement
if(isset($settings->video_align)) {?>

  <?= $prefix ?>  { 
    display: block;
    <?php if(in_array($settings->video_align, ['left','right'])): ?>
      float:<?= $settings->video_align ?>;
    <?php else: ?>
      margin: auto;
    <?php endif; ?>
  } 

  <?= $prefix ?> .bdash-image { 
    <?php if(!in_array($settings->video_align, ['left','right'])): ?>
      display: block;
      margin: auto;
    <?php endif; ?>
  } <?php

}

// Aspect ratio
if (isset($settings->video_aspect_ratio) && !empty(bdash\shortcode\video_content())) {

  $width_ratio = '16';
  $height_ratio = '9';

  $width = isset($settings->video_width) ? $settings->video_width : '100';
  $width_unit = isset($settings->video_width_unit) ? $settings->video_width_unit : '%';

  if ($settings->video_aspect_ratio==='custom') {
    $width_ratio = @$settings->video_custom_aspect_ratio_width;
    $height_ratio = @$settings->video_custom_aspect_ratio_height;
  } else {
    $ratio = explode(':', $settings->video_aspect_ratio);
    $width_ratio = @$ratio[0];
    $height_ratio = @$ratio[1];
  }

  if (!empty($width_ratio) && !empty($height_ratio)) {

    $ratio = ((float) $height_ratio / (float) $width_ratio);

    if($width_unit === "%")
      $height = $ratio * 100;
    else
      $height = (float) $width * ( $ratio);

    ?><?= $prefix ?> { width: <?= $width . $width_unit ?> }<?php
    ?><?= "$prefix .bdash-video" ?> { padding-bottom: <?= $height . $width_unit ?>; }<?php
  }
}


// Image fallback section

if(isset($settings->featured_image) && $settings->featured_image === 'true' && !bdash\shortcode\video_content()) {

  /**
   * Aspect ratio (Image crop for fallback image)
   * 
   * BeaverBuilder create cropped image and store them into
   * the wp-content/uploads/bb-plugin/ folder
   *
   * TODO: 
   * Look if it's easier than the css method (apparently it's just adding
   * a suffix (ex: {imagename-}landsape.png), but they are not created by default)
   * However, I'm not sure it's necessary CSS seems to do the job 
   */
  if (isset($settings->image_crop) && $settings->image_crop !== '') {

    $width = isset($settings->image_width) ? (float) $settings->image_width : (float) 100;
    $unit = isset($settings->image_width_unit) ? $settings->image_width_unit : '%';

    // Same ratio than the ones in the image module from bb
    switch ($settings->image_crop) {

      case 'landscape':
        $height = (float) $width / 1.42;
        break;
      
      case 'panorama':
        $height = (float) $width / 2;
        break;

      case 'portrait':
        $height = (float) $width / 0.7;
        break;

      case 'square':
        $height = (float) $width;
        break;

      case 'circle':
        $height = (float) $width;
        $circle = true;
        break; 
      
      default:
        $height = '';
        break;
    }

    ?><?= "$prefix .bdash-image" ?> {
      display: block;
      height: 0; 
      padding-bottom: <?= (string) $height . $unit ?>; 
      position: relative;
    }<?php

    ?><?= "$prefix .bdash-image img" ?> {
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      object-fit: cover;
      <?php if(isset($circle) && $circle === true): ?> 
        border-radius: 50% 
      <?php endif; ?>
    }<?php
  }

  // For aligement
  /*if(isset($settings->image_align)) {?>
    <?= $prefix ?> { 
      display: flex;
      justify-content: <?= $settings->image_align ?>;
    } <?php
  }*/

  // Width
  if(isset($settings->image_width)) {?>
    <?= $prefix ?> .bdash-image {
      width: <?= $settings->image_width . $settings->image_width_unit ?>;
    }<?php
  }

  // Border
  \FLBuilderCSS::border_field_rule( array(
    'settings'     => $settings,
    'setting_name' => 'image_border',
    'selector'     => $prefix . ' .bdash-image',
  ) );

}

// End image fallback section
 