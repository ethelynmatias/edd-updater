<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\video(
utils\module_atts($settings, [
    'featured_image',
    'show_message_if_progression_incomplete',
    'message_progression_incomplete',
    'type_message_progression_incomplete',
    'video_hide_control',
  ])
);
