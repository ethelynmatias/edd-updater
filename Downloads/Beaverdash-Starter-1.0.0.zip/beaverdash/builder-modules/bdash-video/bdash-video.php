<?php

use BeaverDash\utils as utils;

class BDash_Video extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Video', 'beaverdash' ),
      'description' => __( 'Display lesson/topic video', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Content', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'format-video.svg',
    ));
  }
}

/**
 * For the multiple toggle explanation
 *
 * @see https://community.wpbeaverbuilder.com/t/problem-in-multiple-dependecy/7803/3
 */
FLBuilder::register_module('BDash_Video', [

  // General
  'general'  => [
    'title'    => 'General',
    'sections' => [
      'general' => [
        'title'  => 'General',
        'fields' => [
          'show_message_if_progression_incomplete' => [
            'type'    => 'button-group',
            'label'   => 'Show message if progression is incomplete?',
            'default' => 'false',
            'options' => [
              'true'  => 'Yes',
              'false' => 'No',
            ],
            'toggle'  => [
              'true' => [ 'fields' => [ 'type_message_progression_incomplete' ] ],
            ],
            'trigger' => [
              'true' => [ 'fields' => [ 'type_message_progression_incomplete' ] ],
            ],
            'hide'    => [
              'false' => [ 'fields' => [ 'message_progression_incomplete' ] ],
              ''      => [ 'fields' => [ 'message_progression_incomplete' ] ],
            ],
          ],
          'type_message_progression_incomplete'    => [
            'type'    => 'button-group',
            'label'   => 'Type of message',
            'default' => 'custom',
            'options' => [
              'custom'  => 'Custom',
              'default' => 'Default',
            ],
            'toggle'  => [
              'custom' => [ 'fields' => [ 'message_progression_incomplete' ] ],
            ],
            'hide'    => [
              'default' => [ 'fields' => [ 'message_progression_incomplete' ] ],
            ],
          ],
          'message_progression_incomplete'         => [
            'type'        => 'text',
            'label'       => 'Custom message',
            'default'     => '',
            'preview'     => [ 'type' => 'none' ],
            'connections' => [ 'string' ],
          ],
          'video_aspect_ratio'                     => [
            'type'        => 'select',
            'label'       => 'Aspect ratio',
            'help'        => 'Aspect ratio = width:height',
            'description' => '',
            'default'     => '16:9',
            'options'     => [
              '16:9'   => '16:9 (standard)',
              '1:1'    => '1:1',
              '4:3'    => '4:3',
              '3:2'    => '3:2',
              '8:5'    => '8:5',
              'custom' => 'custom',
            ],
            'toggle'      => [
              'custom' => [
            'fields' => [
                'video_custom_aspect_ratio_width',
            'video_custom_aspect_ratio_height',
              ],
              ],
            ],
          ],
          'video_custom_aspect_ratio_width'        => [
            'type'        => 'text',
            'label'       => 'Aspect ratio - Width',
            'default'     => '16',
            'description' => '',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '16',
            'sanitize'    => 'absint',
          ],
          'video_custom_aspect_ratio_height'       => [
            'type'        => 'text',
            'label'       => 'Aspect ratio: Height',
            'default'     => '9',
            'description' => '',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '9',
            'sanitize'    => 'absint',
          ],
          'featured_image'                         => [
            'type'    => 'button-group',
            'label'   => 'Fallback to featured image?',
            'default' => 'false',
            'options' => [
              'true'  => 'Yes',
              'false' => 'No',
            ],
            'toggle'  => [
              'true' => [ 'tabs' => [ 'fallback' ] ],
            ],
          ],
          'video_hide_control'                     => [
            'type'    => 'button-group',
            'label'   => 'Hide controls?',
            'default' => 'false',
            'options' => [
              'true'  => 'Yes',
              'false' => 'No',
            ],
          ],
        ],
      ],
    ],
  ],
  // End general

  // Style
  'style'    => [
    'title'    => 'Style',
    'sections' => [
      'border' => [
        'title'  => 'Style',
        /*
        'fields' => utils\create_setting_fields([
          'type' => 'border',
          'prefix' => 'video_',
        ])+utils\create_setting_fields([
          'type' => 'border-radius',
          'prefix' => 'video_',
        ]),*/
        /*
        'fields' => utils\create_setting_fields([
          'type' => 'box-shadow',
          'prefix' => 'video_',
        ])*/
        'fields' => [
          'video_align'  => [
            'type'       => 'align',
            'label'      => 'Align',
            'default'    => 'left',
            'responsive' => true,
            /*
            'preview'     => [
              'type'        => 'css',
              'selector'    => '{node} .fl-module-content',
              'property'    => 'margin',
              'values'      => [
                  'center'    => 'auto',
                ],
            ],*/
          ],
          'video_width'  => [
            'type'         => 'unit',
            'label'        => 'Width',
            'default'      => '100',
            'default_unit' => '%', // Optional
            'units'        => [ 'px', 'vw', '%' ],
          ],
          'video_border' => [
            'type'       => 'border',
            'label'      => __( 'Border', 'fl-builder' ),
            'responsive' => true,
            'default'    => [
              'style' => 'solid',
              'color' => 'e5e5e5',
              'width' => [
                'top'    => '0',
                'right'  => '0',
                'bottom' => '0',
                'left'   => '0',
              ],
            ],
            'preview'    => [
              'type'     => 'css',
              'selector' => '{{ node }} .fl-module-content .wp-video',
            ],
          ],
        ],
      ],
    ],
  ],
  // End style

  // Image
  'fallback' => [
    'title'    => 'Image',
    'sections' => [
      'image_style' => [
        'title'  => 'Style',
        'fields' => [
          'image_crop'   => [
            'type'    => 'select',
            'label'   => 'Crop',
            'default' => 'none',
            'options' => [
              ''          => 'None',
              'landscape' => 'Landscape',
              'panorama'  => 'Panorama',
              'portrait'  => 'Portrait',
              'square'    => 'Square',
              'circle'    => 'Circle',
            ],
          ],
          /*
          'image_align'  => [
            'type'        => 'align',
            'label'       => 'Align',
            'default'     => 'left',
            'responsive'  => true,
            'preview'     => [
              'type'        => 'css',
              'selector'    => '{node} .fl-module-content',
              'property'    => 'justify-content',
              'values'      => [
                  'left'      => 'left',
                  'center'    => 'center',
                  'right'     => 'right',
                ],
            ],
          ],*/
          'image_width'  => [
            'type'         => 'unit',
            'label'        => 'Width',
            'default'      => '100',
            'default_unit' => '%', // Optional
            'units'        => [ 'px', 'vw', '%' ],
          ],
          'image_border' => [
            'type'       => 'border',
            'label'      => __( 'Border', 'fl-builder' ),
            'responsive' => true,
            'default'    => [
              'style' => 'solid',
              'color' => 'e5e5e5',
              'width' => [
                'top'    => '0',
                'right'  => '0',
                'bottom' => '0',
                'left'   => '0',
              ],
            ],
            'preview'    => [
              'type'     => 'css',
              'selector' => '{{ node }} .fl-module-content .bdash-image',
            ],
          ],
        ],
      ],
    ],
  ],
  // End image
]);
