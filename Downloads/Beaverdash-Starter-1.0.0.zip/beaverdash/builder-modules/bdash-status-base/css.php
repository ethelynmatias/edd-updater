<?php

namespace BeaverDash\status;
use \BeaverDash\utils as utils;

function render_css($id, $module, $settings, $global_settings, $class = 'bdash-status') {

	$prefix = ".fl-node-$id .fl-module-content";

  	utils\render_module_css([
    	'prefix' => $prefix,
    	'elements' => [
      		[ 'types' => ['typography'] ],
    	],
  	], $settings, $global_settings);
  
  	// Item Border
	\FLBuilderCSS::border_field_rule( array(
		'settings'     => $settings,
		'setting_name' => 'item_border',
		'selector'     => $prefix,
	) );

	// Align
  	if (isset($settings->text_align)) {
	  	?><?= $prefix ?> { text-align: <?= $settings->text_align; ?>; }<?php
	}

	// Global font color
  	if (isset($settings->default_color)) {
	  	?><?= $prefix ?> { color: #<?= $settings->default_color; ?>; }<?php
	}
	
	// Backgroud if gradient
	if (isset($settings->item_gradient) && isset($settings->background_type) && $settings->background_type === 'gradient') {
	  	?><?= $prefix ?> { background-image: <?= \FLBuilderColor::gradient( $settings->item_gradient ) ?>; }<?php
	}

	// Backgroud if color
	if (isset($settings->background_color) && isset($settings->background_type) && $settings->background_type === 'solid') {
	  	?><?= $prefix ?> { background-color: #<?= $settings->background_color ?>; }<?php
	}
	
	// Specific styles according to the status
	foreach(['open','locked','started','completed'] as $status) {
		
		if (isset($settings->{'status_'. $status . '_text_type'}) && in_array($settings->{'status_'. $status . '_text_type'}, ['text','texticon'])) {

			if (isset($settings->{'status_text_color_' . $status})) {
			  	?><?= $prefix ?> .<?= $class ?>-<?= $status ?> { color: #<?= $settings->{'status_text_color_' . $status}; ?>; }<?php
			}		
		}

		if (isset($settings->{'status_'. $status . '_text_type'}) && in_array($settings->{'status_'. $status . '_text_type'}, ['icon','texticon'])) {

			if (isset($settings->{'status_icon_color_' . $status})) {
			  	?><?= $prefix ?> .<?= $class ?>-<?= $status ?>::before { color: #<?= $settings->{'status_icon_color_' . $status}; ?>; }<?php
			}		
		}

		if (isset($settings->{'status_'. $status . '_text_type'}) && $settings->{'status_'. $status . '_text_type'} === 'texticon') {
			?><?= $prefix ?> .<?= $class ?>-<?= $status ?>::before { padding-right: 10px; }<?php
		}
	}
}
