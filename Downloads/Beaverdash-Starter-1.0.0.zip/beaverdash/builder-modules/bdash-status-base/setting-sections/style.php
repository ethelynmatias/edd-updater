<?php

namespace BeaverDash\status;

use \BeaverDash\utils as utils;

set_settings_sections_template('style', [
    'alignement' => [
        'title'  => 'Alignement',
        'fields' => [
            'text_align' => [
                'type'       => 'align',
                'label'      => 'Align',
                'default'    => 'left',
                'responsive' => true,
                'preview'    => [
                    'type'     => 'css',
                    'selector' => '{node} .fl-module-content',
                    'property' => 'text-align',
                ],
            ],
        ],
    ],
    'typography' => [
    'title'  => 'Typography',
    'fields' => [
      'typography'    => utils\create_setting_fields( [ 'type' => 'typography' ] ),
      'default_color' => [
        'type'        => 'color',
        'label'       => 'Default Color',
        'default'     => '0086b0',
        'connections' => [ 'color' ],
      ],
    ],
    ],
    'background' => [
    'title'  => 'Background',
    'fields' => [
        'background_type'  => [
            'type'    => 'button-group',
            'label'   => 'Fill',
            'default' => 'two',
            'options' => [
                'solid'    => 'Solid',
                'gradient' => 'Gradient',
            ],
            'toggle'  => [
                'solid'    => [ 'fields' => [ 'background_color' ] ],
                'gradient' => [ 'fields' => [ 'item_gradient' ] ],
            ],
        ],
        'item_gradient'    => [
            'type'    => 'gradient',
            'label'   => 'Gradient',
            'preview' => [
                'type'     => 'css',
                'selector' => '{node} .fl-module-content',
                'property' => 'background-image',
            ],
        ],
        'background_color' => [
            'type'        => 'color',
            'label'       => 'Background Color',
            'default'     => 'FFFFFF',
            'connections' => [ 'color' ],
        ],
    ],
    ],
    'border'     => [
    'title'  => 'Border',
    'fields' => [
      'item_border' => [
        'type'       => 'border',
        'label'      => __( 'Item Border', 'fl-builder' ),
        'responsive' => true,
        'default'    => [
            'style' => 'solid',
            'color' => 'e5e5e5',
            'width' => [
                'top'    => '1',
                'right'  => '1',
                'bottom' => '1',
                'left'   => '1',
            ],
        ],
        'preview'    => [
            'type'     => 'css',
            'selector' => '{{ node }} .fl-module-content',
        ],
      ],
    ],
    ],
]);
