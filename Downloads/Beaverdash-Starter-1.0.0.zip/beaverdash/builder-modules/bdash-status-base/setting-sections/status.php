<?php

namespace BeaverDash\status;

use \BeaverDash\utils as utils;

set_settings_sections_template('status', [
  'status__suffix__' => [
    'title'  => '__title__',
    'fields' => [
      'status__suffix___text_type'  => [
        'type'    => 'select',
        'label'   => 'Layout',
        'default' => 'text',
        'options' => [
          'none'     => 'None',
          'text'     => 'Text',
          'icon'     => 'Icon',
          'texticon' => 'Icon and text',
          'html'     => 'HTML',
        ],
        'preview' => [ 'type' => 'none' ],
        'toggle'  => [
          'text'     => [ 'fields' => [ 'status__suffix___text', 'status_text_color__suffix__' ] ],
          'icon'     => [ 'fields' => [ 'status__suffix___icon', 'status_icon_color__suffix__' ] ],
          'html'     => [ 'fields' => [ 'status__suffix___html' ] ],
          'texticon' => [ 'fields' => [ 'status__suffix___text', 'status_text_color__suffix__', 'status__suffix___icon', 'status_icon_color__suffix__' ] ],
        ],
      ],
      'status__suffix___text'       => [
        'type'        => 'text',
        'label'       => 'Text',
        'default'     => 'Open',
        'preview'     => [ 'type' => 'none' ],
        'connections' => [ 'string' ],
      ],
      'status__suffix___html'       => [
        'type'        => 'code',
        'editor'      => 'html',
        'label'       => 'HTML',
        'default'     => '__title__',
        'rows'        => '9',
        'preview'     => [ 'type' => 'none' ],
        'connections' => [ 'html', 'string' ],
      ],
      'status_text_color__suffix__' => [
        'type'        => 'color',
        'label'       => 'Text color',
        'default'     => '0086b0',
        'connections' => [ 'color' ],
      ],
      'status__suffix___icon'       => [
        'type'        => 'icon',
        'label'       => 'Icon',
        'show_remove' => true,
      ],
      'status_icon_color__suffix__' => [
        'type'        => 'color',
        'label'       => 'Icon color',
        'default'     => '0086b0',
        'connections' => [ 'color' ],
      ],
    ],
  ],
]);
