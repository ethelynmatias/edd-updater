<?php

namespace BeaverDash\status;

use \BeaverDash\utils as utils;

beaverdash()->state['status/setting_sections_templates'] = [];

function set_settings_sections_template( $type, $sections ) {
  beaverdash()->state['status/setting_sections_templates'][ $type ] = $sections;
}

function get_settings_sections_template( $type ) {
  return beaverdash()->state['status/setting_sections_templates'][ $type ];
}

require __DIR__ . '/source.php';
require __DIR__ . '/status.php';
require __DIR__ . '/style.php';
require __DIR__ . '/text.php';

function create_setting_sections( $config, $sections_template = [] ) {

  $type = $config['type'];

  if ( empty( $sections_template ) ) {
    $sections_template = get_settings_sections_template( $type );
  }

  // In the builder remplace custom parts
  foreach ( [ 'suffix', 'prefix', 'title' ] as $search ) {
    if ( isset( $config[ $search ] ) ) {
      $sections_template = str_replace( "__{$search}__", $config[ $search ], json_encode( $sections_template ) );
      $sections_template = json_decode( $sections_template, true );
    }
  }

  $custom = isset( $config['custom'] ) ? $config['custom'] : [];

  $sections = [];

  foreach ( $sections_template as $section_name => $section_config ) {

    if (isset( $custom[ $section_name ] ) && $custom[ $section_name ] === false) continue;

    $sections[ $section_name ] = [];

    foreach ( $section_config as $key => $value ) {

      if ( ! is_array( $value ) ) {
        $sections[ $section_name ][ $key ] =
          isset( $custom[ $section_name ] )
          && isset( $custom[ $section_name ][ $key ] )
            ? $custom[ $section_name ][ $key ]
            : $value;
        continue;
      }

      // Merge fields

      $sections[ $section_name ][ $key ] = [];

      foreach ( $value as $field_name => $field_config ) {

        $field_custom = isset( $custom[ $section_name ] )
          && isset( $custom[ $section_name ][ $key ] )
          && isset( $custom[ $section_name ][ $key ][ $field_name ] )
            ? $custom[ $section_name ][ $key ][ $field_name ]
            : [];

        if ($key === 'fields' && $field_custom === false) continue;

        $sections[ $section_name ][ $key ][ $field_name ] = array_merge( $field_config, $field_custom );
      }
    }

    // if ($section_name==='list') \BetterDash\see($sections[$section_name]);
  }

  return $sections;
}
