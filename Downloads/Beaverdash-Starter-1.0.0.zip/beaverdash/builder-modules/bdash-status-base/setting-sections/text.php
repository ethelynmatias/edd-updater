<?php

namespace BeaverDash\status;

use \BeaverDash\utils as utils;

set_settings_sections_template('text', [
  'prefix_suffix_status' => [
    'title'  => 'Prefix/Suffix',
    'fields' => [
      'before_status_text_type' => [
        'type'    => 'select',
        'label'   => 'Prefix Layout',
        'default' => 'text',
        'options' => [
          'text' => 'Text',
          'html' => 'HTML',
        ],
        'preview' => [ 'type' => 'none' ],
        'toggle'  => [
          'text' => [ 'fields' => [ 'before_status_text' ] ],
          'html' => [ 'fields' => [ 'before_status_html' ] ],
        ],
      ],
      'before_status_text'      => [
        'type'        => 'text',
        'label'       => '',
        'default'     => '',
        'preview'     => [ 'type' => 'none' ],
        'connections' => [ 'string' ],
      ],
      'before_status_html'      => [
        'type'        => 'code',
        'editor'      => 'html',
        'label'       => '',
        'default'     => '',
        'rows'        => '9',
        'preview'     => [ 'type' => 'none' ],
        'connections' => [ 'html', 'string' ],
      ],
      'after_status_text_type'  => [
        'type'    => 'select',
        'label'   => 'Suffix Layout',
        'default' => 'text',
        'options' => [
          'text' => 'Text',
          'html' => 'HTML',
        ],
        'preview' => [ 'type' => 'none' ],
        'toggle'  => [
          'text' => [ 'fields' => [ 'after_status_text' ] ],
          'html' => [ 'fields' => [ 'after_status_html' ] ],
        ],
      ],
      'after_status_text'       => [
        'type'        => 'text',
        'label'       => '',
        'default'     => '',
        'preview'     => [ 'type' => 'none' ],
        'connections' => [ 'string' ],
      ],
      'after_status_html'       => [
        'type'        => 'code',
        'editor'      => 'html',
        'label'       => '',
        'default'     => '',
        'rows'        => '9',
        'preview'     => [ 'type' => 'none' ],
        'connections' => [ 'html', 'string' ],
      ],
    ],
  ],
]);
