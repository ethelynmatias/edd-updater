<?php

namespace BeaverDash\status;

use \BeaverDash\utils as utils;
use \BetterDash as bdash;

set_settings_sections_template('source', [
 	'source' => [
	'title' => 'Source',
	  'fields' => [
	    'source' => [
	      'type'	=> 'select',
	      'label'	=> 'Source',
	      'default'	=> 'current',
	      'options'	=> [
	        'current'	=> 'Current',
	        'parent'	=> 'Parent',
	        'course'	=> 'Course',
	        'lesson'	=> 'Lesson',
	        'topic'		=> 'Topic',
	        'quiz'		=> 'Quiz',
	      ],
	      'toggle' => [
              'parent' 	=> ['fields' => ['parent']],
              'course' 	=> ['fields' => ['course_id']],
              'lesson' 	=> ['fields' => ['lesson_id']],
              'topic' 	=> ['fields' => ['topic_id']],
              'quiz' 	=> ['fields' => ['quiz_id']],
           ],
	    ],
	    'parent' => [
	        'type' 		=> 'select',
	        'label' 	=> 'Parent',
	        'default' 	=> '',
	        'options' 	=> [
	        	'course_parent' => 'Course',
	        	'lesson_parent' => 'Lesson',
	        ],
	    ],
      'course_id' => [
	        'type' 		=> 'select',
	        'label' 	=> 'Course',
	        'default' 	=> '',
	        'options' 	=> array_reduce(bdash\courses([ 'fields' => 'id' ]), function($options, $course) {
	          	$options[ $course->ID ] = get_post_field('post_title', $course->ID);
	          	return $options;
	        }, []),
	    ],
	    'lesson_id' => [
	        'type' 		=> 'select',
	        'label' 	=> 'Lesson',
	        'default' 	=> '',
	        'options' 	=> array_reduce(bdash\all_posts('lesson', [ 'fields' => 'id' ]), function($options, $lesson) {
	          	$options[ $lesson->ID ] = get_post_field('post_title', $lesson->ID);
	          	return $options;
	        }, []),
	    ],
	    'topic_id' => [
	        'type' 		=> 'select',
	        'label' 	=> 'Topic',
	        'default' 	=> '',
	        'options' 	=> array_reduce(bdash\all_posts('topic', [ 'fields' => 'id' ]), function($options, $topic) {
	          	$options[ $topic->ID ] = get_post_field('post_title', $topic->ID);
	          	return $options;
	        }, []),
	    ],
	    'quiz_id' => [
	        'type' 		=> 'select',
	        'label' 	=> 'Quiz',
	        'default' 	=> '',
	        'options' 	=> array_reduce(bdash\all_posts('quiz', [ 'fields' => 'id' ]), function($options, $quiz) {
	          	$options[ $quiz->ID ] = get_post_field('post_title', $quiz->ID);
	          	return $options;
	        }, []),
	    ],
	  ],
	],
]);