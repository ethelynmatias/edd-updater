<?php

namespace BeaverDash\status;

use BetterDash as bdash;

function register_module( $classname ) {

  \FLBuilder::register_module($classname, [
    'general' => [
        'title'    => 'General',
        'sections' => array_merge(
            create_setting_sections( [ 'type' => 'source' ] ),
            create_setting_sections( [ 'type' => 'text' ] ),
            create_setting_sections( [
  'type'   => 'status',
  'title'  => 'Open',
  'suffix' => '_open',
            ] ),
            create_setting_sections( [
        'type'   => 'status',
        'title'  => 'Started',
        'suffix' => '_started',
            ] ),
            create_setting_sections( [
        'type'   => 'status',
        'title'  => 'Completed',
        'suffix' => '_completed',
            ] ),
            create_setting_sections( [
        'type'   => 'status',
        'title'  => 'Locked',
        'suffix' => '_locked',
            ] )
        ),
    ],
    'style'   => [
        'title'    => 'Style',
        'sections' => create_setting_sections( [ 'type' => 'style' ] ),
    ],
  ]);

}
