<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\content(
utils\module_atts( $settings, [] )
);
