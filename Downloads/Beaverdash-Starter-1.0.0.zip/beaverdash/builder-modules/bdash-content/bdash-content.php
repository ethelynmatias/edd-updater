<?php

class BDash_Content extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Content', 'beaverdash' ),
      'description' => __( 'Display post content of course/lesson/topic/quiz', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Content', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      // 'icon'        => 'format-video.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Content', [
  'style' => [
    'title'    => __( 'Style', 'fl-builder' ),
    'sections' => [
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'typography'       => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
          'typography_title' => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography_title' ] ),
        ],
      ],
    ],
  ],
]);
