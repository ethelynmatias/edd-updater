<?php

\BeaverDash\post_grid\render_js($id, $module, $settings);
