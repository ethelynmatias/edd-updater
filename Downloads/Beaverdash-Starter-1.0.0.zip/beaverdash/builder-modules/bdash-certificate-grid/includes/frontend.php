<?php

\BeaverDash\post_grid\render_loop( $id, $module, $settings );
