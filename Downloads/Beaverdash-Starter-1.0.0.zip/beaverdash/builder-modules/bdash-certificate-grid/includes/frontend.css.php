<?php

\BeaverDash\post_grid\render_css($id, $module, $settings, $global_settings);
