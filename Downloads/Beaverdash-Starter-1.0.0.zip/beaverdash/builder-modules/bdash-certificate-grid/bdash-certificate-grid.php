<?php

class BDash_Certificate_Grid extends BDash_Post_Grid_Base {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Certificate Grid', 'beaverdash' ),
      'description' => __( 'Display a grid of certificates', 'beaverdash' ),
      'category'    => __( 'Certificate', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      'icon'        => 'schedule.svg',

      // Extended module args
      'module_slug' => 'bdash-certificate-grid',
      'post_type'   => 'sfwd-certificates',
    ));
  }
}

\BeaverDash\post_grid\register_module( 'BDash_Certificate_Grid' );
