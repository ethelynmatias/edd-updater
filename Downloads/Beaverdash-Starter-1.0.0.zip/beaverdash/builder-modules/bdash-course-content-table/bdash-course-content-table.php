<?php

use BeaverDash\content_table;

class BDash_Course_Content_Table extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Course Content Table', 'beaverdash' ),
      'description' => __( 'Display course content table', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Course', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'editor-table.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Course_Content_Table', [
  'table'       => [
    'title'    => 'Table',
    'sections' => content_table\create_setting_sections( [ 'type' => 'table' ] ) + [
      'pagination_settings' => [
        'title'  => 'Pagination',
        'fields' => [
          'items_per_page'          => [
            'type'        => 'text',
            'label'       => 'Items per page',
            'help'        => 'Leave empty to use course settings. Set to 0 for no pagination.',
            'default'     => '',
            'description' => '',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '',
            // 'sanitize'    => 'absint',
          ],
          'pagination_label_before' => [
            'type'        => 'text',
            'label'       => 'Label (before)',
            'default'     => 'Page',
            'placeholder' => '',
          ],
          'pagination_separator'    => [
            'type'        => 'text',
            'label'       => 'Separator between page numbers',
            'default'     => '/',
            'placeholder' => '/',
          ],
          'pagination_label_after'  => [
            'type'        => 'text',
            'label'       => 'Label (after)',
            'default'     => '',
            'placeholder' => '',
          ],
        ],
      ],
    ],
  ],
  'list'        => [
    'title'    => 'Lessons',
    'sections' => content_table\create_setting_sections( [ 'type' => 'list' ] ),
  ],
  'child_list'  => [
    'title'    => 'Topics',
    'sections' => content_table\create_setting_sections( [ 'type' => 'child_list' ] ),
  ],
  'quiz_table'  => [
    'title'    => 'Course Quizzes',
    'sections' => content_table\create_setting_sections( [ 'type' => 'quiz_table' ] ),
  ],
  'limit_items' => [
    'title'    => 'Limit Items',
    'sections' => content_table\create_setting_sections( [ 'type' => 'limit_items' ] ),
  ],
  'style'       => [
    'title'    => 'Style',
    'sections' => content_table\create_setting_sections( [ 'type' => 'style' ] ),
  ],
]);
