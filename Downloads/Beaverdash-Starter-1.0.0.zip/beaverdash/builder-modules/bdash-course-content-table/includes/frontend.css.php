<?php

\BeaverDash\content_table\render_css($id, $module, $settings, $global_settings);
