<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\course_content_table(
  utils\module_atts( $settings, $module )
);
