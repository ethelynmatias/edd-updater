<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";

utils\render_module_css([
  'prefix' => $prefix,
  'elements' => [
    [ 'el' => '.bdash-progress-bar',
      'setting_prefix' => 'progress_bar_',
      'types' => ['border'],
    ],
    // [ 'el' => '.bdash-progress-bar-text',
    //   'setting_prefix' => 'text_',
    //   'types' => ['text'],
    // ],
    [ 'types' => ['typography'] ]
  ]
], $settings, $global_settings);

$el = $prefix;


// Gloabl settings
$userInputColor = isset($settings->text_color) ? "#$settings->text_color" : "#000"; 

?>
.fl-builder-content <?= $el ?>.fl-node-content {
  color: <?= $userInputColor ?>;
} <?php

if (empty($settings->shape)) {

  // Default LearnDash progress bar dynamic

} elseif ($settings->shape==='text') {
  // Text
} elseif ($settings->shape==='raw') {
  // Raw
} else {

// User input from the widget options
$userInputHeight = isset($settings->progress_bar_height) && $settings->progress_bar_height != 0 ? $settings->progress_bar_height : 20;
$userInputBackgroundColor = isset($settings->progress_bar_bg_color) ? "#$settings->progress_bar_bg_color" : "#f1f1f1";
$userInputBackgroundGradient = isset($settings->progress_bar_bg_gradient) ? \FLBuilderColor::gradient($settings->progress_bar_bg_gradient) : '';
$userInputBackgroundType = isset($settings->progress_bar_bg_type) ? $settings->progress_bar_bg_type : 'color';
$userInputProgressColor = isset($settings->progress_bar_color) ? "#$settings->progress_bar_color" : "#0085ba"; // Color or gradient
$userInputProgressGradient = isset($settings->progress_bar_gradient) ? \FLBuilderColor::gradient($settings->progress_bar_gradient) : ''; // Color or gradient
$userInputColorType = isset($settings->progress_bar_color_type) ? $settings->progress_bar_color_type : 'color';
$userInputWidth = isset($settings->progress_bar_width) ? $settings->progress_bar_width : 100;
$userInputWidthUnit = isset($settings->progress_bar_width_unit) ? $settings->progress_bar_width_unit : '%';
$userInputFontSize = isset($settings->text_font_size) && $settings->text_font_size != "" ? $settings->text_font_size : 16;
$userInputMetaFontSize = isset($settings->text_font_size) && $settings->text_font_size != "" ? $settings->text_font_size : 18; //
$userInputLineHeight = isset($settings->typography->line_height->length) ? $settings->typography->line_height->length . $settings->typography->line_height->unit : 1.2;
$userInputMetaLineHeight = isset($settings->typography->line_height->length) ? $settings->typography->line_height->length . $settings->typography->line_height->unit : 1.4; //
$userInputTextAlign = strtolower($settings->shape) == 'line' && isset($settings->text_align) ? $settings->text_align : "center";
$userInputMetaTextAlign = isset($settings->meta_align) ? $settings->meta_align : "left";
$userInputMetaColor = isset($settings->text_color) ? "#$settings->text_color" : "#000"; //
$userInputNumberSpacing = isset($settings->variable) ? $settings->variable : "0.6em"; //
$userInputMetaSpacing = isset($settings->variable) ? $settings->variable : "0.6em"; //
$userInputTextShadow = isset($settings->typography->text_shadow) ? $settings->typography->text_shadow->horizontal . " " . $settings->typography->text_shadow->vertical . " " . $settings->typography->text_shadow->blur . $settings->typography->text_shadow->color : "0 -1px 1px #fff"; //
$userInputCircleSize = isset($settings->variable) ? $settings->variable : 120; //
$userInputAlign = isset($settings->align) ? $settings->align : 'center';

if (empty($settings->shape)) {

  // Default LearnDash progress bar dynamic

} elseif ($settings->shape==='text') {
  // Text
} elseif ($settings->shape==='raw') {
  // Raw
} else {
  ?>

  <?php FLBuilderCSS::border_field_rule( array(
    'settings'  => $settings,
    'setting_name'  => 'my_border',
    'selector'  => ".fl-node-$id .bdash-progress-bar .bdash-progress-value, .fl-node-$id .bdash-progress-inner",
  ) ); ?>

  <?= $settings->shape!=='line' ? $el : $el . ' .bdash-course-progress-wrapper' ?> {
    display: flex;
    justify-content: <?= $userInputAlign ?>; 
  }

  <?= $el ?> .bdash-progress, 
  <?= $el ?> .bdash-progress-meta-wrap {
    display: flex;
    position: relative;
    align-items: center;
  }

  <?= $el ?> .bdash-course-progress-align-left .bdash-progress, <?= $el ?> .bdash-course-progress-align-left .bdash-progress-meta-wrap {
    margin-left: 0;
  }

  <?= $el ?> .bdash-course-progress-align-right .bdash-progress, 
  <?= $el ?> .bdash-course-progress-align-right .bdash-progress-meta-wrap {
    margin-right: 0;
  }

  <?= $el ?> .bdash-course-progress-number-inline .bdash-progress {
    flex-direction: row;
  }

  <?= $el ?> .bdash-course-progress-full .bdash-progress {
    width: 100%;
  }

  <?= $el ?> .bdash-course-progress-custom .bdash-progress, <?= $el ?> .bdash-course-progress-custom .bdash-progress-meta-wrap {
    max-width: <?= $userInputWidth . $userInputWidthUnit ?>;
    width: 100%;
    height: <?= $userInputHeight ?>;
  }

  <?= $el ?> .bdash-progress-inner {
    display: block;
    flex: 1 1 auto;
    height: <?= $userInputHeight ?>px;
    <?php if($userInputBackgroundType === 'color' || $settings->shape !== 'line'): ?>
      background-color: <?= $userInputBackgroundColor ?>;
    <?php else: ?>
      background-image: <?= $userInputBackgroundGradient ?>;
    <?php endif; ?>
    border-style: none;
    overflow: hidden;
    max-width: 100%;
    order: 2; 
    width: 100%;
  }

  <?= $el ?> .bdash-progress-bar .bdash-progress-value {
    display: block;
    height: 100%;
    <?php if($userInputColorType === 'color' || $settings->shape !== 'line'): ?>
      background-color: <?= $userInputProgressColor ?>;
    <?php else: ?>
      background-image: <?= $userInputProgressGradient ?>;
    <?php endif; ?>
  }

  <?= $el ?> .bdash-progress-number {
    display: block;
    text-align: <?= $userInputTextAlign ?>;
    font-size: <?= $userInputFontSize ?>px;
    line-height: <?= $userInputLineHeight ?>;
    color: <?= $userInputColor ?>;
    text-shadow: <?= $userInputTextShadow ?>;
  }

  <?= $el ?> .bdash-course-progress-number-overlay .bdash-progress-number,
  <?= $el ?> .bdash-course-progress-number-progress .bdash-progress-number {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    padding-left: <?= $userInputNumberSpacing ?>;
    padding-right: <?= $userInputNumberSpacing ?>;
    line-height: <?= $userInputHeight ?>px; /* Here we will always match the user input for the bar's height rather than their choice of line height in the typography options so that the number remains aligned regardless of font size; */
  }

  <?= $el ?> .bdash-course-progress-number-progress .bdash-progress-value {
    position: relative;
  }

  <?= $el ?> .bdash-course-progress-number-progress .bdash-progress-number {
    text-align: right;
  }

  <?= $el ?> .bdash-progress-meta-wrap {
    text-align: <?= $userInputMetaTextAlign ?>;
    color: <?= $userInputMetaColor ?>;
    font-size: <?= $userInputMetaFontSize ?>px;
    line-height: <?= $userInputMetaLineHeight ?>;
  }

  <?= $el ?> .bdash-progress-meta {
    flex: 1 1 auto;
  }


  <?= $el ?> .bdash-progress-meta-above {
    margin-bottom: <?= $userInputMetaSpacing ?>;
  }

  <?= $el ?> .bdash-progress-meta-below {
    margin-top: <?= $userInputMetaSpacing ?>;
  }

  <?= $el ?> .bdash-progress-number-left {
    text-align: left;
  }

  <?= $el ?> .bdash-course-progress-number-inline .bdash-progress-number-left {
    margin-right: <?= $userInputNumberSpacing ?>;
    order: 1;
    flex: 1 0 auto;
    max-width: 40%;
  }

  <?= $el ?> .bdash-progress-meta-has-two .bdash-progress-meta {
    flex: 1 1 50%;
    text-align: left;
  }

  <?= $el ?> .bdash-progress-meta-has-two .bdash-progress-meta:last-child {
    text-align: right;
  }

  <?= $el ?> .bdash-progress-number-right {
    text-align: right;
  }

  <?= $el ?> .bdash-course-progress-number-inline .bdash-progress-number-right {
    margin-left: <?= $userInputNumberSpacing ?>;
    order: 3;
    flex: 1 0 auto;
    max-width: 40%;
  }

  <?= $el ?> .bdash-progress-number-center {
    text-align: center;
  }

  <?= $el ?> .bdash-course-progress-number-progress .bdash-progress-number {
      white-space: nowrap;
  }

  <?= $el ?> .bdash-progress-circle {
    position: relative;
    width: <?= $userInputCircleSize ?>;
  }
  <?= $el ?> .bdash-progress-circle .bdash-progress-inner {
    background-color: <?= $userInputBackgroundColor ?>;
    border-radius: 50%;
    background-image: conic-gradient(<?= $userInputProgressColor ?> 0, <?= $userInputProgressColor ?> 42%, rgba(0, 0, 0, 0) 0);
    background-size: 100%;
    background-position: center;
    height: <?= $userInputCircleSize ?>;
    margin-bottom: 10px;
    width: <?= $userInputCircleSize ?>;
  }

  <?= $el ?> .bdash-progress-circle .bdash-progress-number {
    position: absolute;
    top: <?= $userInputCircleSize  * 0.15 ?>px;
    left: <?= $userInputCircleSize  * 0.15 ?>px;
    width: <?= $userInputCircleSize * 0.7 ?>px;
    height: <?= $userInputCircleSize * 0.7 ?>px;
    line-height: <?= $userInputCircleSize * 0.7 ?>px;
    border-radius: 50%;
    background-color: white;
    box-sizing: border-box;
  }


  <?= $el ?> .bdash-progress-semicircle {
    position: relative;
    width: <?= $userInputCircleSize ?>;
    height: <?= $userInputCircleSize / 2 ?>px;
    overflow: hidden;
  }

  <?= $el ?> .bdash-progress-semicircle .bdash-progress-inner {
    background-color: <?= $userInputBackgroundColor ?>;
    border-radius: 50%;
    transform: rotate(-90deg);
    background-size: 100%;
    background-position: center top;
    position: absolute;
    top: 0;
    height: <?= $userInputCircleSize ?>;
    margin-bottom: 10px;
    width: <?= $userInputCircleSize ?>;
  }

  <?php
  }
}
