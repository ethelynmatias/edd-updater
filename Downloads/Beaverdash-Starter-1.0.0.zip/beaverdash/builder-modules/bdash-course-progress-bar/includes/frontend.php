<?php

namespace BeaverDash;

use BetterDash as bdash;

$atts = utils\module_atts( $settings, $module );

// if (\FLBuilderModel::is_builder_active()) {}

echo bdash\shortcode\course_progress( $atts );
