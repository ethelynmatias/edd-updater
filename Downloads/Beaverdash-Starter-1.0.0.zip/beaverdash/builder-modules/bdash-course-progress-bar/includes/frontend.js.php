jQuery(document).ready(function($) {

  var animate = window.BDash && window.BDash.animateProgressBar
	var selector = '.fl-node-<?= $id ?> [id^=bdash-progress-bar-]'

  if (animate) animate(selector)

});