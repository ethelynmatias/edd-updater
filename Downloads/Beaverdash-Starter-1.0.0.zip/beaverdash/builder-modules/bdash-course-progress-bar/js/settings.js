/**
 * @see https://community.wpbeaverbuilder.com/t/problem-in-multiple-dependecy/7803/3
 */

;(function($) {
  var triggerChange = function() {
    var form = document.getElementsByClassName('fl-builder-settings')[0]
    if (typeof form === 'undefined') {
      setTimeout(function() {
        triggerChange()
      }, 10)
      return
    }

    var selects = form.getElementsByTagName('select')

    for (var i = 0; i < selects.length; i++) {
      var name = selects[i].getAttribute('name')
      switch (name) {
        case 'shape':
          var type = selects[i]
          break
        case 'progress_bar_color_type':
          var colorType = selects[i]
          break
        case 'progress_bar_color':
          var color = selects[i]
          break
        case 'progress_bar_gradient':
          var gradient = selects[i]
          break
        case 'progress_bar_bg_type':
          var bgColorType = selects[i]
          break
        case 'progress_bar_bg_color':
          var bgColor = selects[i]
          break
        case 'progress_bar_bg_gradient':
          var bgGradient = selects[i]
          break
      }
    }

    if (type.value === 'undefined') return

    // Progress color
    if (type.value === 'line' && colorType.value === 'gradient') {
      $('#fl-field-progress_bar_color').hide()
      $('#fl-field-progress_bar_gradient').show()
    } else {
      $('#fl-field-progress_bar_color').show()
      $('#fl-field-progress_bar_gradient').hide()
    }

    // Background color
    if (type.value === 'line' && bgColorType.value === 'gradient') {
      $('#fl-field-progress_bar_bg_color').hide()
      $('#fl-field-progress_bar_bg_gradient').show()
    } else {
      $('#fl-field-progress_bar_bg_color').show()
      $('#fl-field-progress_bar_bg_gradient').hide()
    }

    if (type.value === 'line') {
      $('#fl-field-progress_bar_color_type').show()
      $('#fl-field-progress_bar_bg_type').show()
    } else {
      $('#fl-field-progress_bar_color_type').hide()
      $('#fl-field-progress_bar_bg_type').hide()
    }
  }

  triggerChange()
  $(document).on('change', 'select[name=progress_bar_color_type]', function() {
    triggerChange()
  })
  $(document).on('change', 'select[name=progress_bar_bg_type]', function() {
    triggerChange()
  })
  $(document).on('change', 'select[name=shape]', function() {
    triggerChange()
  })
})(jQuery)
