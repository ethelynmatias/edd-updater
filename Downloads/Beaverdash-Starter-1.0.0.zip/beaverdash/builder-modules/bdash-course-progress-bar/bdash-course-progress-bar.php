<?php

use BetterDash as bdash;
use \BeaverDash\utils as utils;

class BDash_Course_Progress_Bar extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Course Progress', 'beaverdash' ),
      'description' => __( 'Display course progress bar', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Course', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'chart-bar.svg',
    ));
  }
}

/**
 * For complex toggle, it's easier to settings.js instead of the toggle key
 *
 * @see https://community.wpbeaverbuilder.com/t/problem-in-multiple-dependecy/7803/3
 */

FLBuilder::register_module('BDash_Course_Progress_Bar', [

  'settings' => [
    'title'    => 'Settings',
    'sections' => [
      'general_settings' => [
        'title'  => 'General',
        'fields' => [
          'current_course' => [
            'type'    => 'select',
            'label'   => 'Select Course',
            'default' => 'true',
            'options' => [
              'true'  => 'Current course',
              'false' => 'Other course',
            ],
            'toggle'  => [
              'false' => [ 'fields' => [ 'course_id' ] ],
            ],
          ],
          'course_id'      => [
            'type'    => 'select',
            'label'   => 'Course',
            'default' => '',
            'options' => array_reduce(bdash\courses(), function( $options, $course ) {
              $options[ $course->ID ] = $course->post_title;
              return $options;
            }, []),
          ],
          'shape'          => [
            'type'    => 'select',
            'label'   => 'Shape',
            'default' => 'line',
            'options' => [
              ''           => 'Default LearnDash progress bar',
              'line'       => 'Line',
              'circle'     => 'Circle',
              'semicircle' => 'Semi-Circle',
              'text'       => 'Text',
              'raw'        => 'Raw',
            ],
            'toggle'  => [
              'line'       => [
                'sections' => [ 'custom_styles', 'text_positioning', 'meta' ],
                'fields'   => [ 'progress_bar_border' ],
              ],
              'circle'     => [ 'sections' => [ 'custom_styles', 'circular_settings' ] ],
              'semicircle' => [ 'sections' => [ 'custom_styles', 'circular_settings' ] ],
              'text'       => [ 'sections' => [ 'text_styles' ] ],
            ],
          ],
          'animation'      => [
            'type'    => 'select',
            'label'   => 'Animation',
            'default' => 'true',
            'options' => [
              'true'  => 'Yes',
              'false' => 'No',
            ],
          ],
        ], // Section: Display - Fields
      ], // Section: Display
      'progress'         => [
        'title'  => 'Progress',
        'fields' => [
          'progress_type' => [
            'type'    => 'select',
            'label'   => 'Progress Indicator Type',
            'default' => 'percent',
            'options' => [
              'percent'  => 'Percentage',
              'fraction' => 'Fraction',
              'disabled' => 'Disabled',
            ],
            'toggle'  => [
              'percent'  => [ 'fields' => [ 'text_positioning' ] ],
              'fraction' => [ 'fields' => [ 'text_positioning' ] ],
            ],
          ],
        ],
      ],
      'text_positioning' => [
        'title'  => 'Text positioning',
        'fields' => [
          'progress_position'      => [
            'type'    => 'select',
            'label'   => 'Progress number position',
            'default' => 'overlay',
            'options' => [
              'inline'  => 'Inline',
              'overlay' => 'Overlay',
              'follow'  => 'Follow Progress',
            ],
            'toggle'  => [
              'inline'  => [ 'fields' => [ 'progress_inline_align' ] ],
              'overlay' => [ 'fields' => [ 'progress_overlay_align' ] ],
            ],
          ],
          'progress_inline_align'  => [
            'type'    => 'select',
            'label'   => 'Align progress number',
            'default' => 'left',
            'options' => [
              'left'  => 'Left',
              'right' => 'Right',
            ],
          ],
          'progress_overlay_align' => [
            'type'    => 'select',
            'label'   => 'Align progress number',
            'default' => 'center',
            'options' => [
              'left'   => 'Left',
              'center' => 'Center',
              'right'  => 'Right',
            ],
          ],
        ],
      ],
      'meta'             => [
        'title'  => 'Meta',
        'fields' => [
          'meta_text'  => [
            'type'    => 'select',
            'label'   => 'Show Meta Text?',
            'default' => 'none',
            'options' => [
              'none'   => 'None',
              'top'    => 'Top',
              'both'   => 'Both',
              'bottom' => 'Bottom',
            ],
            'toggle'  => [
              'top'    => [ 'fields' => [ 'meta_1', 'meta_2', 'meta_align' ] ],
              'bottom' => [ 'fields' => [ 'meta_3', 'meta_4', 'meta_align' ] ],
              'both'   => [ 'fields' => [ 'meta_1', 'meta_2', 'meta_3', 'meta_4', 'meta_align' ] ],
            ],
          ],
          'meta_align' => [
            'type'    => 'select',
            'label'   => 'Align meta text',
            'default' => 'left',
            'options' => [
              'left'   => 'Left',
              'center' => 'Center',
              'right'  => 'Right',
            ],
          ],
          'meta_1'     => [
            'type'        => 'text',
            'label'       => 'Text',
            'default'     => '',
            'connections' => [ 'string' ],
          ],
          'meta_2'     => [
            'type'        => 'text',
            'label'       => 'Text',
            'default'     => '',
            'connections' => [ 'string' ],
          ],
          'meta_3'     => [
            'type'        => 'text',
            'label'       => 'Text',
            'default'     => '',
            'connections' => [ 'string' ],
          ],
          'meta_4'     => [
            'type'        => 'text',
            'label'       => 'Text',
            'default'     => '',
            'connections' => [ 'string' ],
          ],
        ],
      ],
    ], // Sections
  ], // Group: Settings
  'style'    => [
    'title'    => 'Style',
    'sections' => [
      'typography'        => [
        'title'  => 'Typography',
        'fields' => [
          'typography' => utils\create_setting_fields( [ 'type' => 'typography' ] ),
          'text_color' => [
            'type'        => 'color',
            'label'       => 'Text color',
            'default'     => '555555',
            'connections' => [ 'color' ],
          ],
        ],
      ],
      'custom_styles'     => [
        'title'  => 'Styles',
        'fields' => [
          'align'                    => [
            'type'    => 'align',
            'label'   => 'Text Align',
            'default' => 'center',
            'preview' => array(
              'type'     => 'css',
              'selector' => '.fl-module-content, .fl-module-content .bdash-course-progress-custom',
              'property' => 'justify-content',
            ),
          ],
          'progress_bar_color_type'  => [
            'type'    => 'select',
            'label'   => 'Color type',
            'default' => 'color',
            'options' => [
              'color'    => 'Color',
              'gradient' => 'Gradient',
            ],
          ],
          'progress_bar_color'       => [
            'type'        => 'color',
            'label'       => 'Color',
            'default'     => '50be7c',
            'connections' => [ 'color' ],
          ],
          'progress_bar_gradient'    => array(
            'type'  => 'gradient',
            'label' => 'Color gradient',
          ),
          'progress_bar_bg_type'     => [
            'type'    => 'select',
            'label'   => 'Background type',
            'default' => 'color',
            'options' => [
              'color'    => 'Color',
              'gradient' => 'Gradient',
            ],
          ],
          'progress_bar_bg_color'    => [
            'type'        => 'color',
            'label'       => 'Background color',
            'default'     => 'eeeeee',
            'connections' => [ 'color' ],
          ],
          'progress_bar_bg_gradient' => array(
            'type'    => 'gradient',
            'label'   => 'Background gradient',
            'preview' => array(
              'type'     => 'css',
              'selector' => '.bdash-progress-inner',
              'property' => 'background-image',
            ),
          ),
          'progress_bar_width'       => [
            'type'         => 'unit',
            'responsive'   => true,
            'label'        => 'Width',
            'default'      => '100',
            'default_unit' => '%',
            'units'        => [ 'px', 'vw', '%' ],
            'maxlength'    => '3',
            'size'         => '5',
            'placeholder'  => '',
            'sanitize'     => 'absint',
          ],
          'progress_bar_height'      => [
            'type'        => 'text',
            'label'       => 'Height',
            'default'     => '20',
            'description' => 'px',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '',
            'sanitize'    => 'absint',
          ],
          'progress_bar_border'      => [
            'type'       => 'border',
            'label'      => 'Border',
            'responsive' => true,
            'preview'    => [
              'type'     => 'css',
              'selector' => '.bdash-progress-bar .bdash-progress-value, .bdash-progress-inner',
            ],
          ],
        ],
      ],
      'circular_settings' => [
        'title'  => 'Settings',
        'fields' => [
          'ie' => [
            'type'    => 'select',
            'label'   => 'IE/Edge compatible mode',
            'help'    => 'Applies a workaround solution for a browser bug that breaks circle/semi-circle if stroke width is larger than 7',
            'default' => 'false',
            'options' => [
              'false' => 'Disabled',
              'true'  => 'Enabled',
            ],
          ],
        ],
      ],
    ],
  ],
]);
