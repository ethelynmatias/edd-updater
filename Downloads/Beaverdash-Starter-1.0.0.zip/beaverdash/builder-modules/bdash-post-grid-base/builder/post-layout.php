<?php

namespace BeaverDash\post_grid;

function add_post_layout_fields( $module_slug = '' ) {

  // See: bb-theme-builder/classes/class-fl-theme-builder-post-modules.php
  add_filter('fl_builder_register_settings_form', function( $form, $slug ) use ( $module_slug ) {

    if ($module_slug !== $slug ) return $form;

    $modules_folder = beaverdash()->state['dir'] . 'builder-modules';
    $includes_path  = \BDash_Post_Grid_Base::$includes_path;

    // Templates for grid item

    // Original HTML: FL_THEME_BUILDER_DIR . 'includes/post-grid-default-html.php'
    // Original CSS: FL_THEME_BUILDER_DIR . 'includes/post-grid-default-css.php'

    $template_html = "$modules_folder/$slug/includes/item-template-html.php";
    $template_css  = "$includes_path/item-template-css.php";

    $form['layout']['sections']['general']['fields']['post_layout'] = array(
      'type'    => 'select',
      'label'   => __( 'Post Layout', 'fl-theme-builder' ),
      'default' => 'default',
      'options' => array(
        'default' => __( 'Default', 'fl-theme-builder' ),
        'custom'  => __( 'Custom', 'fl-theme-builder' ),
      ),
      'toggle'  => array(
        'custom' => array(
          'fields' => array( 'custom_post_layout' ),
        ),
      ),
    );

    $form['layout']['sections']['general']['fields']['custom_post_layout'] = array(
      'type'         => 'form',
      'label'        => __( 'Custom Post Layout', 'fl-theme-builder' ),
      'form'         => 'custom_post_layout',
      'preview_text' => null,
      'multiple'     => false,
    );

    \FLBuilder::register_settings_form( 'custom_post_layout', array(
      'title' => __( 'Custom Post Layout', 'fl-theme-builder' ),
      'tabs'  => array(
        'html' => array(
          'title'    => __( 'HTML', 'fl-theme-builder' ),
          'sections' => array(
            'html' => array(
              'title'  => '',
              'fields' => array(
                'html' => array(
                  'type'        => 'code',
                  'editor'      => 'html',
                  'label'       => '',
                  'rows'        => '18',
                  'default'     => file_get_contents( $template_html ),
                  'preview'     => array(
                    'type' => 'none',
                  ),
                  'connections' => array( 'html', 'string', 'url' ),
                ),
              ),
            ),
          ),
        ),
        'css'  => array(
          'title'    => __( 'CSS', 'fl-theme-builder' ),
          'sections' => array(
            'css' => array(
              'title'  => '',
              'fields' => array(
                'css' => array(
                  'type'    => 'code',
                  'editor'  => 'css',
                  'label'   => '',
                  'rows'    => '18',
                  'default' => file_get_contents( $template_css ),
                  'preview' => array(
                    'type' => 'none',
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ));

    return $form;

  }, 99, 2 );
}
