<?php

namespace BeaverDash\post_grid;

function register_module( $classname ) {

  $loop_settings_path = __DIR__ . '/loop-settings.php';

  \FLBuilder::register_module($classname, array(
    'layout'     => array(
      'title'    => __( 'Layout', 'fl-builder' ),
      'sections' => array(
        'general' => array(
          'title'  => '',
          'fields' => array(
            'layout' => array(
              'type'    => 'select',
              'label'   => __( 'Layout', 'fl-builder' ),
              'default' => 'grid',
              'options' => array(
                'columns' => __( 'Columns', 'fl-builder' ),
                'grid'    => __( 'Masonry', 'fl-builder' ),
                'gallery' => __( 'Gallery', 'fl-builder' ),
                'feed'    => __( 'List', 'fl-builder' ),
              ),
              'toggle'  => array(
                'columns' => array(
                  'sections' => array( 'posts', 'image', 'content', 'post_style', 'text_style' ),
                  'fields'   => array( 'match_height', 'post_columns', 'post_spacing', 'post_padding', 'grid_image_position', 'grid_image_spacing', 'show_author', 'show_comments_grid', 'info_separator', 'show_terms' ),
                ),
                'grid'    => array(
                  'sections' => array( 'posts', 'image', 'content', 'post_style', 'text_style' ),
                  'fields'   => array( 'match_height', 'post_width', 'post_spacing', 'post_padding', 'grid_image_position', 'grid_image_spacing', 'show_author', 'show_comments_grid', 'info_separator', 'show_terms' ),
                ),
                'gallery' => array(
                  'sections' => array( 'gallery_general', 'overlay_style', 'icons' ),
                ),
                'feed'    => array(
                  'sections' => array( 'posts', 'image', 'content', 'post_style', 'text_style' ),
                  'fields'   => array( 'feed_post_spacing', 'feed_post_padding', 'image_position', 'image_spacing', 'image_width', 'show_author', 'show_comments', 'info_separator', 'show_terms', 'content_type' ),
                ),
              ),
            ),
          ),
        ),
        'posts'   => array(
          'title'  => __( 'Posts', 'fl-builder' ),
          'fields' => array(
            'match_height'      => array(
              'type'    => 'select',
              'label'   => __( 'Equal Heights', 'fl-builder' ),
              'default' => '0',
              'options' => array(
                '1' => __( 'Yes', 'fl-builder' ),
                '0' => __( 'No', 'fl-builder' ),
              ),
            ),
            'post_width'        => array(
              'type'        => 'text',
              'label'       => __( 'Post Width', 'fl-builder' ),
              'default'     => '300',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'post_columns'      => array(
              'type'       => 'unit',
              'label'      => __( 'Columns', 'fl-builder' ),
              'responsive' => array(
                'default' => array(
                  'default'    => '3',
                  'medium'     => '2',
                  'responsive' => '1',
                ),
              ),
            ),
            'post_spacing'      => array(
              'type'        => 'text',
              'label'       => __( 'Post Spacing', 'fl-builder' ),
              'default'     => '60',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'feed_post_spacing' => array(
              'type'        => 'text',
              'label'       => __( 'Post Spacing', 'fl-builder' ),
              'default'     => '40',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'post_padding'      => array(
              'type'        => 'text',
              'label'       => __( 'Post Padding', 'fl-builder' ),
              'default'     => '20',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
              'preview'     => array(
                'type'     => 'css',
                'selector' => '.fl-post-grid-text',
                'property' => 'padding',
                'unit'     => 'px',
              ),
            ),
            'feed_post_padding' => array(
              'type'        => 'text',
              'label'       => __( 'Post Padding', 'fl-builder' ),
              'default'     => '0',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'post_align'        => array(
              'type'    => 'select',
              'label'   => __( 'Post Alignment', 'fl-builder' ),
              'default' => 'default',
              'options' => array(
                'default' => __( 'Default', 'fl-builder' ),
                'left'    => __( 'Left', 'fl-builder' ),
                'center'  => __( 'Center', 'fl-builder' ),
                'right'   => __( 'Right', 'fl-builder' ),
              ),
            ),
          ),
        ),
        'image'   => array(
          'title'  => __( 'Featured Image', 'fl-builder' ),
          'fields' => array(
            'show_image'          => array(
              'type'    => 'select',
              'label'   => __( 'Image', 'fl-builder' ),
              'default' => '1',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
            ),
            'grid_image_position' => array(
              'type'    => 'select',
              'label'   => __( 'Image Position', 'fl-builder' ),
              'default' => 'above-title',
              'options' => array(
                'above-title' => __( 'Above Title', 'fl-builder' ),
                'above'       => __( 'Above Content', 'fl-builder' ),
              ),
            ),
            'image_position'      => array(
              'type'    => 'select',
              'label'   => __( 'Image Position', 'fl-builder' ),
              'default' => 'above',
              'options' => array(
                'above-title'          => __( 'Above Title', 'fl-builder' ),
                'above'                => __( 'Above Content', 'fl-builder' ),
                'beside'               => __( 'Left', 'fl-builder' ),
                'beside-content'       => __( 'Left Content', 'fl-builder' ),
                'beside-right'         => __( 'Right', 'fl-builder' ),
                'beside-content-right' => __( 'Right Content', 'fl-builder' ),
              ),
            ),
            'image_size'          => array(
              'type'    => 'photo-sizes',
              'label'   => __( 'Image Size', 'fl-builder' ),
              'default' => 'medium',
            ),
            'grid_image_spacing'  => array(
              'type'        => 'text',
              'label'       => __( 'Image Spacing', 'fl-builder' ),
              'default'     => '0',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'image_spacing'       => array(
              'type'        => 'text',
              'label'       => __( 'Image Spacing', 'fl-builder' ),
              'default'     => '0',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'image_width'         => array(
              'type'        => 'text',
              'label'       => __( 'Image Width', 'fl-builder' ),
              'default'     => '33',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => '%',
            ),
          ),
        ),
        'info'    => array(
          'title'  => __( 'Post Info', 'fl-builder' ),
          'fields' => array(
            'show_author'        => array(
              'type'    => 'select',
              'label'   => __( 'Author', 'fl-builder' ),
              'default' => '1',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
            ),
            'show_date'          => array(
              'type'    => 'select',
              'label'   => __( 'Date', 'fl-builder' ),
              'default' => '1',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
              'toggle'  => array(
                '1' => array(
                  'fields' => array( 'date_format' ),
                ),
              ),
            ),
            'date_format'        => array(
              'type'    => 'select',
              'label'   => __( 'Date Format', 'fl-builder' ),
              'default' => 'default',
              'options' => array(
                'default' => __( 'Default', 'fl-builder' ),
                'M j, Y'  => date( 'M j, Y' ),
                'F j, Y'  => date( 'F j, Y' ),
                'm/d/Y'   => date( 'm/d/Y' ),
                'm-d-Y'   => date( 'm-d-Y' ),
                'd M Y'   => date( 'd M Y' ),
                'd F Y'   => date( 'd F Y' ),
                'Y-m-d'   => date( 'Y-m-d' ),
                'Y/m/d'   => date( 'Y/m/d' ),
              ),
            ),
            'show_comments'      => array(
              'type'    => 'select',
              'label'   => __( 'Comments', 'fl-builder' ),
              'default' => '1',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
            ),
            'show_comments_grid' => array(
              'type'    => 'select',
              'label'   => __( 'Comments', 'fl-builder' ),
              'default' => '0',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
            ),
            'info_separator'     => array(
              'type'    => 'text',
              'label'   => __( 'Separator', 'fl-builder' ),
              'default' => ' | ',
              'size'    => '4',
              'preview' => array(
                'type'     => 'text',
                'selector' => '.fl-sep',
              ),
            ),
            'show_terms'         => array(
              'type'    => 'select',
              'label'   => __( 'Terms', 'fl-builder' ),
              'default' => '0',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
              'toggle'  => array(
                '1' => array(
                  'fields' => array( 'terms_separator', 'terms_list_label' ),
                ),
              ),
            ),
            'terms_list_label'   => array(
              'type'    => 'text',
              'label'   => __( 'Terms Label', 'fl-builder' ),
              'default' => __( 'Posted in ', 'fl-builder' ),
              'preview' => array(
                'type'     => 'text',
                'selector' => '.fl-terms-label',
              ),
            ),
            'terms_separator'    => array(
              'type'    => 'text',
              'label'   => __( 'Terms Separator', 'fl-builder' ),
              'default' => ', ',
              'size'    => '4',
              'preview' => array(
                'type'     => 'text',
                'selector' => '.fl-sep-term',
              ),
            ),
          ),
        ),
        'content' => array(
          'title'  => __( 'Content', 'fl-builder' ),
          'fields' => array(
            'show_content'   => array(
              'type'    => 'select',
              'label'   => __( 'Content', 'fl-builder' ),
              'default' => '1',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
            ),
            'content_type'   => array(
              'type'    => 'select',
              'label'   => __( 'Content Type', 'fl-builder' ),
              'default' => 'excerpt',
              'options' => array(
                'excerpt' => __( 'Excerpt', 'fl-builder' ),
                'full'    => __( 'Full Text', 'fl-builder' ),
              ),
            ),
            'content_length' => array(
              'type'        => 'text',
              'label'       => __( 'Content Length', 'fl-builder' ),
              'default'     => '',
              'size'        => '4',
              'description' => __( 'words', 'fl-builder' ),
            ),
            'show_more_link' => array(
              'type'    => 'select',
              'label'   => __( 'More Link', 'fl-builder' ),
              'default' => '0',
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
              'toggle'  => array(
                '1' => array(
                  'fields' => array( 'more_link_text' ),
                ),
              ),
            ),
            'more_link_text' => array(
              'type'    => 'text',
              'label'   => __( 'More Link Text', 'fl-builder' ),
              'default' => __( 'Read More', 'fl-builder' ),
            ),
          ),
        ),
      ),
    ),
    'style'      => array(
      'title'    => __( 'Style', 'fl-builder' ),
      'sections' => array(
        'typography'      => [
          'title'    => 'Typography',
            'fields' => [
            'typography'       => \BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
            'typography_title' => \BeaverDash\utils\create_setting_fields( [ 'type' => 'typography_title' ] ),
            ],
        ],
        'post_style'      => array(
          'title'  => __( 'Posts', 'fl-builder' ),
          'fields' => array(
            'bg_color'     => array(
              'type'        => 'color',
              'label'       => __( 'Post Background Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'bg_opacity'   => array(
              'type'        => 'text',
              'label'       => __( 'Post Background Opacity', 'fl-builder' ),
              'default'     => '100',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => '%',
            ),
            'border_type'  => array(
              'type'    => 'select',
              'label'   => __( 'Post Border Type', 'fl-builder' ),
              'default' => 'default',
              'options' => array(
                'default' => _x( 'Default', 'Border type.', 'fl-builder' ),
                'none'    => _x( 'None', 'Border type.', 'fl-builder' ),
                'solid'   => _x( 'Solid', 'Border type.', 'fl-builder' ),
                'dashed'  => _x( 'Dashed', 'Border type.', 'fl-builder' ),
                'dotted'  => _x( 'Dotted', 'Border type.', 'fl-builder' ),
                'double'  => _x( 'Double', 'Border type.', 'fl-builder' ),
              ),
              'toggle'  => array(
                'solid'  => array(
                  'fields' => array( 'border_color', 'border_size' ),
                ),
                'dashed' => array(
                  'fields' => array( 'border_color', 'border_size' ),
                ),
                'dotted' => array(
                  'fields' => array( 'border_color', 'border_size' ),
                ),
                'double' => array(
                  'fields' => array( 'border_color', 'border_size' ),
                ),
              ),
            ),
            'border_color' => array(
              'type'        => 'color',
              'label'       => __( 'Post Border Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'border_size'  => array(
              'type'        => 'text',
              'label'       => __( 'Post Border Size', 'fl-builder' ),
              'default'     => '1',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
          ),
        ),
        'text_style'      => array(
          'title'  => __( 'Text', 'fl-builder' ),
          'fields' => array(
            'title_color'       => array(
              'type'        => 'color',
              'label'       => __( 'Title Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'title_font_size'   => array(
              'type'        => 'text',
              'label'       => __( 'Title Font Size', 'fl-builder' ),
              'default'     => '',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'info_color'        => array(
              'type'        => 'color',
              'label'       => __( 'Post Info Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'info_font_size'    => array(
              'type'        => 'text',
              'label'       => __( 'Post Info Font Size', 'fl-builder' ),
              'default'     => '',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'content_color'     => array(
              'type'        => 'color',
              'label'       => __( 'Content Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'content_font_size' => array(
              'type'        => 'text',
              'label'       => __( 'Content Font Size', 'fl-builder' ),
              'default'     => '',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'link_color'        => array(
              'type'        => 'color',
              'label'       => __( 'Link Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'link_hover_color'  => array(
              'type'        => 'color',
              'label'       => __( 'Link Hover Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
          ),
        ),
        'gallery_general' => array(
          'title'  => '',
          'fields' => array(
            'hover_transition' => array(
              'type'    => 'select',
              'label'   => __( 'Hover Transition', 'fl-builder' ),
              'default' => 'fade',
              'options' => array(
                'fade'       => __( 'Fade', 'fl-builder' ),
                'slide-up'   => __( 'Slide Up', 'fl-builder' ),
                'slide-down' => __( 'Slide Down', 'fl-builder' ),
                'scale-up'   => __( 'Scale Up', 'fl-builder' ),
                'scale-down' => __( 'Scale Down', 'fl-builder' ),
              ),
            ),
          ),
        ),
        'overlay_style'   => array(
          'title'  => __( 'Overlay Colors', 'fl-builder' ),
          'fields' => array(
            'text_color'      => array(
              'type'        => 'color',
              'label'       => __( 'Overlay Text Color', 'fl-builder' ),
              'default'     => 'ffffff',
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'text_bg_color'   => array(
              'type'        => 'color',
              'label'       => __( 'Overlay Background Color', 'fl-builder' ),
              'default'     => '333333',
              'help'        => __( 'The color applies to the overlay behind text over the background selections.', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'text_bg_opacity' => array(
              'type'        => 'text',
              'label'       => __( 'Overlay Background Opacity', 'fl-builder' ),
              'default'     => '50',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => '%',
            ),
          ),
        ),
        'icons'           => array(
          'title'  => __( 'Icons', 'fl-builder' ),
          'fields' => array(
            'has_icon'      => array(
              'type'    => 'select',
              'label'   => __( 'Use Icon for Posts', 'fl-builder' ),
              'default' => 'no',
              'options' => array(
                'yes' => __( 'Yes', 'fl-builder' ),
                'no'  => __( 'No', 'fl-builder' ),
              ),
              'toggle'  => array(
                'yes' => array(
                  'fields' => array( 'icon', 'icon_position', 'icon_color', 'icon_size' ),
                ),
              ),
            ),
            'icon'          => array(
              'type'  => 'icon',
              'label' => __( 'Post Icon', 'fl-builder' ),
            ),
            'icon_position' => array(
              'type'    => 'select',
              'label'   => __( 'Post Icon Position', 'fl-builder' ),
              'default' => 'above',
              'options' => array(
                'above' => __( 'Above Text', 'fl-builder' ),
                'below' => __( 'Below Text', 'fl-builder' ),
              ),
            ),
            'icon_size'     => array(
              'type'        => 'text',
              'label'       => __( 'Post Icon Size', 'fl-builder' ),
              'default'     => '24',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'icon_color'    => array(
              'type'        => 'color',
              'label'       => __( 'Post Icon Color', 'fl-builder' ),
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
          ),
        ),
      ),
    ),
    'content'    => array(
      'title' => __( 'Content', 'fl-builder' ),
      'file'  => $loop_settings_path,
    ),
    'pagination' => array(
      'title'    => __( 'Pagination', 'fl-builder' ),
      'sections' => array(
        'pagination'        => array(
          'title'  => __( 'Pagination', 'fl-builder' ),
          'fields' => array(
            'pagination'         => array(
              'type'    => 'select',
              'label'   => __( 'Pagination Style', 'fl-builder' ),
              'default' => 'numbers',
              'options' => array(
                'numbers'   => __( 'Numbers', 'fl-builder' ),
                'scroll'    => __( 'Scroll', 'fl-builder' ),
                'load_more' => __( 'Load More Button', 'fl-builder' ),
                'none'      => _x( 'None', 'Pagination style.', 'fl-builder' ),
              ),
              'toggle'  => array(
                'load_more' => array(
                  'sections' => array( 'load_more_general' ),
                ),
              ),
            ),
            'posts_per_page'     => array(
              'type'    => 'text',
              'label'   => __( 'Posts Per Page', 'fl-builder' ),
              'default' => '10',
              'size'    => '4',
            ),
            'no_results_message' => array(
              'type'    => 'text',
              'label'   => __( 'No Results Message', 'fl-builder' ),
              'default' => '',
                // __( "Sorry, we couldn't find any posts. Please try a different search.", 'fl-builder' ),
            ),
            'show_search'        => array(
              'type'    => 'select',
              'label'   => __( 'Show Search', 'fl-builder' ),
              'default' => '0', // Was 1
              'options' => array(
                '1' => __( 'Show', 'fl-builder' ),
                '0' => __( 'Hide', 'fl-builder' ),
              ),
              'help'    => __( 'Shows the search form if no posts are found.' ),
            ),
          ),
        ),
        'load_more_general' => array(
          'title'  => __( 'Load More Button', 'fl-builder' ),
          'fields' => array(
            'more_btn_text'             => array(
              'type'    => 'text',
              'label'   => __( 'Button Text', 'fl-builder' ),
              'default' => __( 'Load More', 'fl-builder' ),
            ),
            'more_btn_icon'             => array(
              'type'        => 'icon',
              'label'       => __( 'Button Icon', 'fl-builder' ),
              'show_remove' => true,
            ),
            'more_btn_icon_position'    => array(
              'type'    => 'select',
              'label'   => __( 'Icon Position', 'fl-builder' ),
              'default' => 'before',
              'options' => array(
                'before' => __( 'Before Text', 'fl-builder' ),
                'after'  => __( 'After Text', 'fl-builder' ),
              ),
            ),
            'more_btn_icon_animation'   => array(
              'type'    => 'select',
              'label'   => __( 'Icon Visibility', 'fl-builder' ),
              'default' => 'disable',
              'options' => array(
                'disable' => __( 'Always Visible', 'fl-builder' ),
                'enable'  => __( 'Fade In On Hover', 'fl-builder' ),
              ),
            ),
            'more_btn_bg_color'         => array(
              'type'        => 'color',
              'label'       => __( 'Background Color', 'fl-builder' ),
              'default'     => '',
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'more_btn_bg_hover_color'   => array(
              'type'        => 'color',
              'label'       => __( 'Background Hover Color', 'fl-builder' ),
              'default'     => '',
              'show_reset'  => true,
              'connections' => [ 'color' ],
              'preview'     => array(
                'type' => 'none',
              ),
            ),
            'more_btn_text_color'       => array(
              'type'        => 'color',
              'label'       => __( 'Text Color', 'fl-builder' ),
              'default'     => '',
              'show_reset'  => true,
              'connections' => [ 'color' ],
            ),
            'more_btn_text_hover_color' => array(
              'type'        => 'color',
              'label'       => __( 'Text Hover Color', 'fl-builder' ),
              'default'     => '',
              'connections' => [ 'color' ],
              'show_reset'  => true,
              'preview'     => array(
                'type' => 'none',
              ),
            ),
            'more_btn_font_size'        => array(
              'type'        => 'text',
              'label'       => __( 'Font Size', 'fl-builder' ),
              'default'     => '14',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'more_btn_padding'          => array(
              'type'        => 'text',
              'label'       => __( 'Padding', 'fl-builder' ),
              'default'     => '10',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'more_btn_border_radius'    => array(
              'type'        => 'text',
              'label'       => __( 'Round Corners', 'fl-builder' ),
              'default'     => '4',
              'maxlength'   => '3',
              'size'        => '4',
              'description' => 'px',
            ),
            'more_btn_width'            => array(
              'type'    => 'select',
              'label'   => __( 'Width', 'fl-builder' ),
              'default' => 'auto',
              'options' => array(
                'auto' => _x( 'Auto', 'Width.', 'fl-builder' ),
                'full' => __( 'Full Width', 'fl-builder' ),
              ),
            ),
          ),
        ),
      ),
    ),
  ));
}
