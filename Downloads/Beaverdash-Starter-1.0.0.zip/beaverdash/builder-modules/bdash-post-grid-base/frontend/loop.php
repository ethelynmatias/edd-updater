<?php
/**
 * Based on: bb-plugin/modules/post-grid/includes/frontend.php
 */
namespace BeaverDash\post_grid;

use BetterDash as bdash;

function render_loop( $id, $module, $settings ) {

  $includes_path = \BDash_Post_Grid_Base::$includes_path;
  $layout_slug   = $module->get_layout_slug();

  $post_template_path = "$includes_path/post-$layout_slug.php";

  $settings->data_source = 'custom_query';
  $settings->post_type   = $module->post_type;

  /**
   * These post types have fixed order/orderby based on course builder
   * See also ../builder/loop-settings.php
   */
  //
  if ( bdash\course_builder_enabled() && in_array($module->post_type,
    [ 'sfwd-lessons', 'sfwd-topic', 'sfwd-quiz' ]
  )) {
    // Correct order in builder is passed as "post__in"; previously was using "menu_order"
    $settings->order_by = 'post__in';
    $settings->order = 'ASC';
  }

  /**
   * Support custom pagination using query string instead of URL route
   */
  global $wp_the_query;

  $paged_query_var_name = str_replace('bdash-', '', $module->slug) . '-paged';
  $current_page = isset($_GET[ $paged_query_var_name ])
    ? $_GET[ $paged_query_var_name ]
    : 1
  ;

  // Gets checked in FLBuilderLoop::get_paged()
  if ($current_page > 1) $wp_the_query->set( 'paged', $current_page );


  // Get the query data.
  $query = \FLBuilderLoop::query( $settings );

  // Render the posts.
  if ( $query->have_posts() ) :

    do_action( 'fl_builder_posts_module_before_posts', $settings, $query );

    $paged = ( \FLBuilderLoop::get_paged() > 0 ) ? ' fl-paged-scroll-to' : '';

    ?>
  <div class="fl-post-<?php echo $module->get_layout_slug() . $paged; ?>" itemscope="itemscope" itemtype="https://schema.org/Blog">
    <?php

    while ( $query->have_posts() ) {

        $query->the_post();

      if ( $settings->post_layout === 'default' ) {
            ob_start();
            include $post_template_path;
            echo do_shortcode( ob_get_clean() );
      } else {
        // Custom post layout
        // Based on: plugins/bb-theme-builder/includes/post-grid-frontend.php
        ?><div <?php $module->render_post_class(); ?> itemscope itemtype="<?php \FLPostGridModule::schema_itemtype(); ?>">
            <?php
            \FLPostGridModule::schema_meta();
            do_action( 'fl_builder_post_grid_before_content', $settings, $module );
            echo do_shortcode( \FLThemeBuilderFieldConnections::parse_shortcodes( $settings->custom_post_layout->html ) );
            do_action( 'fl_builder_post_grid_after_content', $settings, $module );
            ?>
        </div><?php
      }
    }

    ?>
    <?php if ( 'grid' == $settings->layout ) : ?>
    <div class="fl-post-grid-sizer"></div>
    <?php endif; ?>
  </div>
  <div class="fl-clear"></div>
  <?php endif; ?>
  <?php

  do_action( 'fl_builder_posts_module_after_posts', $settings, $query );

  // Render the pagination.
  if ( 'none' != $settings->pagination && $query->have_posts() && $query->max_num_pages > 1 ) :

    ?>
  <div class="fl-builder-pagination"<?php
  if ( in_array( $settings->pagination, array( 'scroll', 'load_more' ) ) ) {
    echo ' style="display:none;"';}
  ?>>
    <?php

      // Beaver's pagination does not work with LearnDash permalinks
      // \FLBuilderLoop::pagination( $query );

      /**
       * Custom pagination
       * @see https://developer.wordpress.org/reference/functions/paginate_links/
       */
      echo paginate_links(apply_filters( 'fl_loop_paginate_links_args', [
        // 'base'     => $base, // Current URL by default
        'format'   => '?' . $paged_query_var_name . '=%#%',
        'current'  => $current_page,
        'total'    => $query->max_num_pages,
        'type'     => 'list',
        'add_args' => false,
      ], $query ));

    ?>
  </div>
    <?php if ( 'load_more' == $settings->pagination && $query->max_num_pages > 1 ) : ?>
  <div class="fl-builder-pagination-load-more">
      <?php

      \FLBuilder::render_module_html( 'button', array(
        'align'            => 'center',
        'bg_color'         => $settings->more_btn_bg_color,
        'bg_hover_color'   => $settings->more_btn_bg_hover_color,
        'border_radius'    => $settings->more_btn_border_radius,
        'font_size'        => $settings->more_btn_font_size,
        'icon'             => $settings->more_btn_icon,
        'icon_position'    => $settings->more_btn_icon_position,
        'icon_animation'   => $settings->more_btn_icon_animation,
        'link'             => '#',
        'link_target'      => '_self',
        'padding'          => $settings->more_btn_padding,
        'text'             => $settings->more_btn_text,
        'text_color'       => $settings->more_btn_text_color,
        'text_hover_color' => $settings->more_btn_text_hover_color,
        'width'            => $settings->more_btn_width,
      ));

      ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
  <?php

  do_action( 'fl_builder_posts_module_after_pagination', $settings, $query );

  // Render the empty message.
  if ( ! $query->have_posts() ) :
    ?>
  <div class="fl-post-grid-empty">
    <p><?php echo $settings->no_results_message; ?></p>
    <?php if ( $settings->show_search ) : ?>
      <?php get_search_form(); ?>
    <?php endif; ?>
  </div>
    <?php
  endif;

  wp_reset_postdata();

}
