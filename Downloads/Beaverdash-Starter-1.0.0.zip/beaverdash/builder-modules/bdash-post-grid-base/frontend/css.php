<?php

namespace BeaverDash\post_grid;

use BeaverDash\utils as utils;

function render_css($id, $module, $settings, $global_settings) {

  $includes_path = \BDash_Post_Grid_Base::$includes_path;
  $layout_slug = $module->get_layout_slug();

  $template_base = "$includes_path/post-$layout_slug";
  $custom = isset( $settings->post_layout ) && 'custom' == $settings->post_layout;
  if ( fl_builder_filesystem()->file_exists( $template_base . '-common.css.php' ) ) {
  	include $template_base . '-common.css.php';
  }
  if ( ! $custom && fl_builder_filesystem()->file_exists( $template_base . '.css.php' ) ) {
  	include $template_base . '.css.php';
  }

  if ( 'load_more' == $settings->pagination ) {
  	\FLBuilder::render_module_css('button', $id, array(
  		'align'             => 'center',
  		'bg_color'          => $settings->more_btn_bg_color,
  		'bg_hover_color'    => $settings->more_btn_bg_hover_color,
  		'border_radius'     => $settings->more_btn_border_radius,
  		'font_size'         => $settings->more_btn_font_size,
  		'icon'              => $settings->more_btn_icon,
  		'icon_position'     => $settings->more_btn_icon_position,
  		'icon_animation'    => $settings->more_btn_icon_animation,
  		'link'              => '#',
  		'link_target'       => '_self',
  		'padding'           => $settings->more_btn_padding,
  		'text'              => $settings->more_btn_text,
  		'text_color'        => $settings->more_btn_text_color,
  		'text_hover_color'  => $settings->more_btn_text_hover_color,
  		'width'             => $settings->more_btn_width,
  	));
  }

  $prefix = ".fl-node-$id .fl-module-content";

  utils\render_module_css([
      'prefix'    => $prefix,
      'elements'  => [
      [ 'types' => ['typography', 'typography_title'] ],
    ],
  ], $settings, $global_settings);

}
