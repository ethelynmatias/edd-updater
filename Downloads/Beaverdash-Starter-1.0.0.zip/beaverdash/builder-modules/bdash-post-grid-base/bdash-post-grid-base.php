<?php

// Base class and utilties for custom post grid module

// See also: builder-extensions/post-grid

require __DIR__ . '/builder/post-layout.php';
require __DIR__ . '/builder/module.php';

require __DIR__ . '/frontend/loop.php';
require __DIR__ . '/frontend/js.php';
require __DIR__ . '/frontend/css.php';

class BDash_Post_Grid_Base extends \FLBuilderModule {

  static $includes_path = __DIR__ . '/includes';
  
  public $post_type;

  public function __construct( $args = [] ) {

    parent::__construct(array(
      'name'            => $args['name'],
      'description'     => $args['description'],
      'category'        => $args['category'],
      'dir'             => $args['dir'],
      'url'             => $args['url'],
      'icon'            => $args['icon'],
      'partial_refresh' => true,
      'group'           => beaverdash()->state['module_group_name'],
    ));

    $this->post_type = $args['post_type'];

    \BeaverDash\post_grid\add_post_layout_fields( $args['module_slug'] );
  }

  public function filter_settings( $settings, $helper ) {
    /**
     * Follow changes in original Post Grid module's behavior by applying the same
     * settings filter. This provides properties of $setting object expected by BB
     * Theme Builder's extensions, such as for WooCommece and Events Calendar.
     *
     * @see bb-plugin/classes/class-fl-builder-settings-compat.php
     */

    if (class_exists('FLBuilderSettingsCompat')
      && method_exists('FLBuilderSettingsCompat', 'filter_node_settings')) {

      $actual_type = $settings->type;

      $settings->type = 'post-grid';
      $settings = \FLBuilderSettingsCompat::filter_node_settings( 'module', $settings );

      $settings->type = $actual_type;
    }

    return $settings;
  }

  /**
   * @method enqueue_scripts
   */
  public function enqueue_scripts() {

    if ( \FLBuilderModel::is_builder_active() || 'columns' == $this->settings->layout ) {
      $this->add_js( 'imagesloaded' );
    }
    if ( \FLBuilderModel::is_builder_active() || 'grid' == $this->settings->layout ) {
      $this->add_js( 'imagesloaded' );
      $this->add_js( 'jquery-masonry' );

    }
    if ( \FLBuilderModel::is_builder_active() || 'gallery' == $this->settings->layout ) {
      $this->add_js( 'fl-gallery-grid' );
    }
    if ( \FLBuilderModel::is_builder_active() || 'scroll' == $this->settings->pagination || 'load_more' == $this->settings->pagination ) {
      $this->add_js( 'jquery-infinitescroll' );
    }

    if ( \FLBuilderModel::is_builder_active() || $this->settings->show_comments ) {
      $this->add_css( 'font-awesome-5' );
    }

    // Jetpack sharing has settings to enable sharing on posts, post types and pages.
    // If pages are disabled then jetpack will still show the share button in this module
    // but will *not* enqueue its scripts and fonts.
    // This filter forces jetpack to enqueue the sharing scripts.
    add_filter( 'sharing_enqueue_scripts', '__return_true' );
  }

  /**
   * @since 1.10.7
   */
  public function update( $settings ) {
    global $wp_rewrite;
    $wp_rewrite->flush_rules( false );
    return $settings;
  }

  /**
   * Returns the slug for the posts layout.
   *
   * @since 1.10
   * @return string
   */
  public function get_layout_slug() {
    return 'columns' == $this->settings->layout ? 'grid' : $this->settings->layout;
  }

  /**
   * Renders the CSS class for each post item.
   *
   * @since 1.10
   * @return void
   */
  public function render_post_class() {
    $settings   = $this->settings;
    $layout     = $this->get_layout_slug();
    $show_image = has_post_thumbnail() && $settings->show_image;
    $classes    = array( 'fl-post-' . $layout . '-post' );

    if ( $show_image ) {
      if ( 'feed' == $layout ) {
        $classes[] = 'fl-post-feed-image-' . $settings->image_position;
      }
      if ( 'grid' == $layout ) {
        $classes[] = 'fl-post-grid-image-' . $settings->grid_image_position;
      }
      if ( 'columns' == $settings->layout ) {
        $classes[] = 'fl-post-columns-post';
      }
    }

    if ( in_array( $layout, array( 'grid', 'feed' ) ) ) {
      $classes[] = 'fl-post-align-' . $settings->post_align;
    }

    post_class( apply_filters( 'fl_builder_posts_module_classes', $classes, $settings ) );
  }

  /**
   * Renders the featured image for a post.
   *
   * @since 1.10
   * @param string|array $position
   * @return void
   */
  public function render_featured_image( $position = 'above' ) {
    $settings = $this->settings;
    $render   = false;
    $position = ! is_array( $position ) ? array( $position ) : $position;
    $layout   = $this->get_layout_slug();

    if ( has_post_thumbnail() && $settings->show_image ) {

      if ( 'feed' == $settings->layout && in_array( $settings->image_position, $position ) ) {
        $render = true;
      } elseif ( 'columns' == $settings->layout && in_array( $settings->grid_image_position, $position ) ) {
        $render = true;
      } elseif ( 'grid' == $settings->layout && in_array( $settings->grid_image_position, $position ) ) {
        $render = true;
      }

      if ( $render ) {
        include __DIR__ . '/includes/featured-image.php';
      }
    }
  }

  /**
   * Checks to see if a featured image exists for a position.
   *
   * @since 1.10
   * @param string|array $position
   * @return void
   */
  public function has_featured_image( $position = 'above' ) {
    $settings = $this->settings;
    $result   = false;
    $position = ! is_array( $position ) ? array( $position ) : $position;

    if ( has_post_thumbnail() && $settings->show_image ) {

      if ( 'feed' == $settings->layout && in_array( $settings->image_position, $position ) ) {
        $result = true;
      } elseif ( 'columns' == $settings->layout && in_array( $settings->grid_image_position, $position ) ) {
        $result = true;
      } elseif ( 'grid' == $settings->layout && in_array( $settings->grid_image_position, $position ) ) {
        $result = true;
      }
    }

    return $result;
  }

  /**
   * Renders the_content for a post.
   *
   * @since 1.10
   * @return void
   */
  public function render_content() {
    ob_start();
    the_content();
    $content = ob_get_clean();

    if ( ! empty( $this->settings->content_length ) ) {
      $content = wpautop( wp_trim_words( $content, $this->settings->content_length, '...' ) );
    }

    echo $content;
  }

  /**
   * Renders the_excerpt for a post.
   *
   * @since 1.10
   * @return void
   */
  public function render_excerpt() {
    if ( ! empty( $this->settings->content_length ) ) {
      add_filter( 'excerpt_length', array( $this, 'set_custom_excerpt_length' ), 9999 );
    }

    the_excerpt();

    if ( ! empty( $this->settings->content_length ) ) {
      remove_filter( 'excerpt_length', array( $this, 'set_custom_excerpt_length' ), 9999 );
    }
  }

  /**
   * Renders the excerpt for a post.
   *
   * @since 1.10
   * @return void
   */
  public function set_custom_excerpt_length( $length ) {
    return $this->settings->content_length;
  }

  /**
   * Get the terms for the current post.
   *
   * @since 1.10.8
   * @return string|null
   */
  public function get_post_terms() {
    $post_type       = get_post_type();
    $taxonomies      = get_object_taxonomies( $post_type, 'objects' );
    $terms_list      = array();
    $terms_separator = '<span class="fl-sep-term">' . $this->settings->terms_separator . '</span>';

    if ( ! $taxonomies || empty( $taxonomies ) ) {
      return;
    }

    foreach ( $taxonomies as $name => $tax ) {
      if ( ! $tax->hierarchical ) {
        continue;
      }

      $term_list = get_the_term_list( get_the_ID(), $name, '', $terms_separator, '' );
      if ( ! empty( $term_list ) ) {
        $terms_list[] = $term_list;
      }
    }

    if ( count( $terms_list ) > 0 ) {
      return join( $terms_separator, $terms_list );
    }
  }

  /**
   * Renders the schema structured data for the current
   * post in the loop.
   *
   * @since 1.7.4
   * @return void
   */
  public static function schema_meta() {

    do_action( 'fl_before_schema_meta' );

    // General Schema Meta
    ob_start();
    echo '<meta itemscope itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="' . esc_url( get_permalink() ) . '" content="' . the_title_attribute( array(
      'echo' => false,
    ) ) . '" />';
    echo '<meta itemprop="datePublished" content="' . get_the_time( 'Y-m-d' ) . '" />';
    echo '<meta itemprop="dateModified" content="' . get_the_modified_date( 'Y-m-d' ) . '" />';

    echo apply_filters( 'fl_schema_meta_general', ob_get_clean() );

    // Publisher Schema Meta
    ob_start();
    echo '<div itemprop="publisher" itemscope itemtype="https://schema.org/Organization">';
    echo '<meta itemprop="name" content="' . get_bloginfo( 'name' ) . '">';

    // Fetch logo from theme or filter.
    $image = '';
    if ( class_exists( 'FLTheme' ) && 'image' == FLTheme::get_setting( 'fl-logo-type' ) ) {
      $image = FLTheme::get_setting( 'fl-logo-image' );
    }
    $image = apply_filters( 'fl_schema_meta_publisher_image_url', $image );
    if ( $image ) {
      echo '<div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">';
      echo '<meta itemprop="url" content="' . $image . '">';
      echo '</div>';
    }

    echo '</div>';
    echo apply_filters( 'fl_schema_meta_publisher', ob_get_clean() );

    // Author Schema Meta
    ob_start();
    echo '<div itemscope itemprop="author" itemtype="https://schema.org/Person">';
    echo '<meta itemprop="url" content="' . get_author_posts_url( get_the_author_meta( 'ID' ) ) . '" />';
    echo '<meta itemprop="name" content="' . get_the_author_meta( 'display_name', get_the_author_meta( 'ID' ) ) . '" />';
    echo '</div>';
    echo apply_filters( 'fl_schema_meta_author', ob_get_clean() );

    // Image Schema Meta
    if ( has_post_thumbnail() ) {

      $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );
      if ( is_array( $image ) ) {
        echo '<div itemscope itemprop="image" itemtype="https://schema.org/ImageObject">';
        echo '<meta itemprop="url" content="' . $image[0] . '" />';
        echo '<meta itemprop="width" content="' . $image[1] . '" />';
        echo '<meta itemprop="height" content="' . $image[2] . '" />';
        echo '</div>';
      }
    }

    // Comment Schema Meta
    ob_start();
    echo '<div itemprop="interactionStatistic" itemscope itemtype="https://schema.org/InteractionCounter">';
    echo '<meta itemprop="interactionType" content="https://schema.org/CommentAction" />';
    echo '<meta itemprop="userInteractionCount" content="' . wp_count_comments( get_the_ID() )->approved . '" />';
    echo '</div>';
    echo apply_filters( 'fl_schema_meta_comments', ob_get_clean() );

    do_action( 'fl_after_schema_meta' );
  }

  /**
   * Renders the schema itemtype for the current
   * post in the loop.
   *
   * @since 1.7.4
   * @return void
   */
  public static function schema_itemtype() {
    global $post;

    if ( ! is_object( $post ) || ! isset( $post->post_type ) || 'post' != $post->post_type ) {
      echo 'https://schema.org/CreativeWork';
    } else {
      echo 'https://schema.org/BlogPosting';
    }
  }
}
