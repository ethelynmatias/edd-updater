<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\image(
utils\module_atts( $settings, [] )
);
