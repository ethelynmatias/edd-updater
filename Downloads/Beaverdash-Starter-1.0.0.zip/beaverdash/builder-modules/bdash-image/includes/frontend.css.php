<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";

utils\render_module_css([
  'prefix' => $prefix,
  'elements' => [
    [ 'el' => '.bdash-image',
      'setting_prefix' => 'image_',
      'types' => ['border', 'box-shadow'],
    ],
  ]
], $settings, $global_settings);
