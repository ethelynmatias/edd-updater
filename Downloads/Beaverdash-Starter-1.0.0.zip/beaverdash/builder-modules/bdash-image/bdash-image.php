<?php

use BeaverDash\utils as utils;

class BDash_Image extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Image', 'beaverdash' ),
      'description' => __( 'Display featured image', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Content', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'format-image.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Image', [
  'general' => [
    'title'    => 'General',
    'sections' => [
      'border'     => [
        'title'  => 'Border',
        'fields' => utils\create_setting_fields([
          'type'   => 'border',
          'prefix' => 'image_',
        ]) + utils\create_setting_fields([
          'type'   => 'border-radius',
          'prefix' => 'image_',
        ]),
      ],
      'box_shadow' => [
        'title'  => 'Box Shadow',
        'fields' => utils\create_setting_fields([
          'type'   => 'box-shadow',
          'prefix' => 'image_',
        ]),
      ],
    ],
  ],
]);
