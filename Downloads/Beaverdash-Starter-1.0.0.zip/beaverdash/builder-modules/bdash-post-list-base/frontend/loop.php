<?php

namespace BeaverDash\post_list;

use BetterDash as bdash;

function render_loop( $id, $module, $settings ) {

  $atts = \BeaverDash\utils\module_atts( $settings, $module ) + [
    'post_type' => $module->post_type,
  ];

  echo bdash\post_list( $atts );
}
