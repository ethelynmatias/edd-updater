<?php

namespace BeaverDash\post_list;

use BeaverDash\utils as utils;

function render_css($id, $module, $settings, $global_settings) {

	$prefix = ".fl-node-$id .fl-module-content";

	utils\render_module_css([
	    'prefix'    => $prefix,
	    'elements'  => [
	    [ 'types' => ['typography'] ],
	  ],
	], $settings, $global_settings);
}
