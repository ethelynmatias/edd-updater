<?php

require __DIR__ . '/builder/index.php';
require __DIR__ . '/frontend/loop.php';
require __DIR__ . '/frontend/css.php';

class BDash_Post_List_Base extends \FLBuilderModule {

  // static $includes_path = __DIR__.'/includes';

  public $post_type;
  
  public function __construct( $args = [] ) {

    parent::__construct([
      'name'            => $args['name'],
      'description'     => $args['description'],
      'category'        => $args['category'],
      'dir'             => $args['dir'],
      'url'             => $args['url'],
      'icon'            => $args['icon'],
      'partial_refresh' => true,
      'group'           => beaverdash()->state['module_group_name'],
    ]);

    $this->post_type = $args['post_type'];
  }
}
