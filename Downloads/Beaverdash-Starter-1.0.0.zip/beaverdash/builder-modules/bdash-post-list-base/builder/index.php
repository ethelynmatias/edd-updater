<?php

namespace BeaverDash\post_list;

use BetterDash as bdash;

function register_module( $classname ) {

  \FLBuilder::register_module($classname, [
    'style' => [
        'title'    => 'Style',
        'sections' => [
          'typography' => [
            'title'  => 'Typography',
            'fields' => [
              'typography' => \BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
            ],
          ],
        ],
      ],
  ]);

}
