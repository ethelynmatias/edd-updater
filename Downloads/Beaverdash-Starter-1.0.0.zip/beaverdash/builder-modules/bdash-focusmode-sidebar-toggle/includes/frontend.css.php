<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";
$el = "$prefix .bdash-focusmode-sidebar-toggle";

utils\render_module_css([
    'prefix'    => $el,
    'elements'  => [
    [ 'types' => ['typography'] ],
  ],
], $settings, $global_settings);


if (isset($settings->background_color)) {
  ?><?= $el ?>.ld-course-navigation-heading { background-color: #<?= $settings->background_color; ?> !important; }<?php

  ?><?= $el ?> .ld-focus-sidebar-trigger { background-color: #<?= $settings->background_color; ?> !important; }<?php
}
