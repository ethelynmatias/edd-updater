<?php

namespace BeaverDash;

use BetterDash as bdash;

$layouts = \FLThemeBuilderLayoutData::get_current_page_layouts();

/**
 * This module will only display on a focus sidebar themer layout
 */
if ( ! empty( $layouts ) && array_key_exists( 'part', $layouts ) && ! empty( $layouts['part'] ) ) {
  foreach ( $layouts['part'] as $part ) {
    if ( $part['hook'] === 'bdash_focus_sidebar' ) {
        echo bdash\shortcode\focusmode\sidebar_toggle(
            utils\module_atts( $settings, $module )
        );
        break;
    }
  }
}
