<?php

class BDash_Focusmode_SidebarToggle extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Sidebar Toggle', 'beaverdash' ),
      'description' => __( 'Expand/collapse toggle for the focus sidebar template', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Focus Mode', 'beaverdash' ),
      'icon'        => 'leftright.svg',
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
    ));
  }
}

FLBuilder::register_module('BDash_Focusmode_SidebarToggle', [
  'general' => [
    'title'    => __( 'General', 'fl-builder' ),
    'sections' => [
      'general' => [
        'title'  => 'General',
        'fields' => [
          'is_permalink' => [
            'type'    => 'select',
            'label'   => __( 'Link to the course', 'beaverdash' ),
            'default' => 'true',
            'options' => [
              'true'  => __( 'Yes', 'beaverdash' ),
              'false' => __( 'No', 'beaverdash' ),
            ],
          ],
        ],
      ],
    ],
  ],
  'style'   => [
    'title'    => 'Style',
    'sections' => [
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'typography_title' => \BeaverDash\utils\create_setting_fields( [ 'type' => 'typography_title' ] ),
        ],
      ],
      'colors'     => [
        'title'  => 'Colors',
        'fields' => [
          'background_color' => [
            'type'        => 'color',
            'label'       => 'Background text color',
            'default'     => '81d742',
            'connections' => [ 'color' ],
          ],
        ],
      ],
    ],
  ],
]);
