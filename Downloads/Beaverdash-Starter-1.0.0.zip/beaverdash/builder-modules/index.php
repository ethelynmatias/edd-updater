<?php

use BetterDash as bdash;

// This module groups definition is also used to generate documentation in ../settings/doc
beaverdash()->state['module_groups'] = [
  [
    'name'    => 'LearnDash Modules',
    'prefix'  => 'bdash',
    'modules' => array_merge(
      [
        // Base classes and utility functions
        'post-grid-base',
        'post-list-base',
        'content-table-base',
        'status-base',

        // Course
        'course-nav',
        'course-content-table',
        'course-progress-bar',
        'course-grid',
        'course-list',

        // Lesson
        'lesson-content-table',
        'lesson-grid',
        'lesson-list',
        'lesson-nav',

        // Topic
        'topic-content-table',
        'topic-grid',
        'topic-list',
        'topic-nav',

        // Quiz
        'quiz-grid',
        'quiz-list',

        // Certificate
        'certificate-grid',

        // Content
        'content',
        'image',
        'video',
        'materials',
        'status',

        // Button
        'button-nav',
        'button-enroll',
        'button-mark-complete',
      ],
      ! bdash\utils\is_ld3()
      ? []
      // Modules only for LearnDash 3.0 and higher
      : [
        // Course
        'course-content-overview',
        'course-nav-sidebar',
        'course-price',

        // Navigation
        'breadcrumb',

        // Focus mode
        'focusmode-sidebar-toggle',
        'focusmode-user-dropdown',

        // User
        'user-profile',
      ]
    ), // End modules
  ], // End groups
];

add_action('init', function() {

  if ( ! class_exists( 'FLBuilder' )) return;

  /*
  Load BeaverBuilder modules, in the order that it will appear in the builder

  Module folders **and file names** must be namespaced with a prefix
  to avoid conflict with core modules.

  See: https://kb.wpbeaverbuilder.com/article/597-cmdg-02-add-a-module-to-your-plugin
  */

  foreach ( beaverdash()->state['module_groups'] as $group ) {

    $name    = $group['name'];
    $prefix  = $group['prefix'];
    $modules = $group['modules'];

    // Pass to modules
    beaverdash()->state['module_group_name'] = $name;

    foreach ( $modules as $key ) {
      include "$prefix-$key/$prefix-$key.php";
    }
  }
});
