<?php

class BDash_Lesson_Grid extends BDash_Post_Grid_Base {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Lesson Grid', 'beaverdash' ),
      'description' => __( 'Display a grid of lessons', 'beaverdash' ),
      'category'    => __( 'Lesson', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      'icon'        => 'schedule.svg',

      // Extended module args
      'module_slug' => 'bdash-lesson-grid',
      'post_type'   => 'sfwd-lessons',
    ));
  }
}

\BeaverDash\post_grid\register_module( 'BDash_Lesson_Grid' );
