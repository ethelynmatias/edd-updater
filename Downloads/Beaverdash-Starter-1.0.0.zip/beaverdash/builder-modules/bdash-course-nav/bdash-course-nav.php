<?php

use BeaverDash\utils;

class BDash_Course_Nav extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'            => __( 'Course Navigation', 'beaverdash' ),
      'description'     => __( 'Course navigation menu', 'beaverdash' ),
      'group'           => beaverdash()->state['module_group_name'],
      'category'        => __( 'Course', 'beaverdash' ),
      'dir'             => __DIR__,
      'url'             => plugins_url( '', __FILE__ ),
      'partial_refresh' => true,
      'icon'            => 'location.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Course_Nav', [
  'general'      => [
    'title'    => 'General',
    'sections' => [
      'display_settings'    => [
        'title'  => 'Display',
        'fields' => [
          'expand'              => [
            'type'    => 'select',
            'label'   => 'Expand mode',
            'default' => 'all',
            'options' => [
              'all'      => 'Expand all',
              'current'  => 'Expand current',
              'collapse' => 'Collapse all',
            ],
          ],
          'show_course_quizzes' => [
            'type'    => 'select',
            'label'   => 'Show course quizzes',
            'default' => 'false',
            'options' => [
              'false' => 'False',
              'true'  => 'True',
            ],
          ],
          'show_lesson_quizzes' => [
            'type'    => 'select',
            'label'   => 'Show lesson quizzes',
            'default' => 'false',
            'options' => [
              'false' => 'False',
              'true'  => 'True',
            ],
          ],
          'show_topic_quizzes'  => [
            'type'    => 'select',
            'label'   => 'Show topic quizzes',
            'default' => 'false',
            'options' => [
              'false' => 'False',
              'true'  => 'True',
            ],
          ],
        ],
      ],
      'pagination_settings' => [
        'title'  => 'Pagination',
        'fields' => [
          'items_per_page'          => [
            'type'        => 'text',
            'label'       => 'Items per page',
            'help'        => 'Leave empty to use course settings. Set to 0 for no pagination.',
            'default'     => '',
            'description' => '',
            'maxlength'   => '3',
            'size'        => '5',
            'placeholder' => '',
            // 'sanitize'    => 'absint',
          ],
          'pagination_label_before' => [
            'type'        => 'text',
            'label'       => 'Label (before)',
            'default'     => 'Page',
            'placeholder' => '',
          ],
          'pagination_separator'    => [
            'type'        => 'text',
            'label'       => 'Separator between page numbers',
            'default'     => '/',
            'placeholder' => '/',
          ],
          'pagination_label_after'  => [
            'type'        => 'text',
            'label'       => 'Label (after)',
            'default'     => '',
            'placeholder' => '',
          ],
        ],
      ],
    ],
  ],
  'text_style'   => [
    'title'    => 'Text Style',
    'sections' => [
      // I don't know if it's better to keep the existing system or to implement a typography field for this one
      /*
      'typography' => [
        'title'     => 'Global',
        'fields'    => [
          'typography' => \BeaverDash\utils\create_setting_fields([ 'type' => 'typography']),
        ],
      ],*/
      'lesson_styles' => [
        'title'  => 'Lesson',
        'fields' => [
          'lesson_font'                    => [
            'type'    => 'font',
            'default' => [
              'family' => 'Default',
              'weight' => 300,
            ],
            'label'   => __( 'Font', 'fl-builder' ),
            'preview' => [
              'type'     => 'font',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson',
            ],
          ],
          'lesson_font_size'               => [
            'type'        => 'text',
            'label'       => __( 'Font Size', 'fl-theme-builder' ),
            'default'     => '',
            'size'        => '5',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson',
              'property' => 'font-size',
              'unit'     => 'px',
            ],
          ],
          'lesson_letter_spacing'          => [
            'type'        => 'text',
            'label'       => __( 'Letter Spacing', 'fl-theme-builder' ),
            'default'     => '',
            'size'        => '5',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson',
              'property' => 'letter-spacing',
              'unit'     => 'px',
            ],
          ],
          'lesson_link_color'              => [
            'type'        => 'color',
            'label'       => __( 'Link Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson a',
              'property' => 'color',
            ],
          ],
          'lesson_link_hover_color'        => [
            'type'        => 'color',
            'label'       => __( 'Link Hover Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson a:hover',
              'property' => 'color',
            ],
          ],
          'lesson_current_link_color'      => [
            'type'        => 'color',
            'label'       => __( 'Current Link Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson.learndash-current-menu-item a',
              'property' => 'color',
            ],
          ],
          'lesson_current_link_font_style' => [
            'type'    => 'select',
            'label'   => __( 'Current Link Font Style', 'fl-theme-builder' ),
            'default' => 'normal',
            'options' => [
              'normal' => 'Normal',
              'italic' => 'Italic',
            ],
            'preview' => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson.learndash-current-menu-item a',
              'property' => 'font-style',
            ],
          ],
        ],
      ], // Lessons

      'topic_styles'  => [
        'title'  => 'Topic',
        'fields' => [
          'topic_font'                    => [
            'type'    => 'font',
            'default' => [
              'family' => 'Default',
              'weight' => 300,
            ],
            'label'   => __( 'Font', 'fl-builder' ),
            'preview' => [
              'type'     => 'font',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic',
            ],
          ],
          'topic_font_size'               => [
            'type'        => 'text',
            'label'       => __( 'Font Size', 'fl-theme-builder' ),
            'default'     => '',
            'size'        => '5',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic',
              'property' => 'font-size',
              'unit'     => 'px',
            ],
          ],
          'topic_letter_spacing'          => [
            'type'        => 'text',
            'label'       => __( 'Letter Spacing', 'fl-theme-builder' ),
            'default'     => '',
            'size'        => '5',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic',
              'property' => 'letter-spacing',
              'unit'     => 'px',
            ],
          ],
          'topic_link_color'              => [
            'type'        => 'color',
            'label'       => __( 'Link Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic a',
              'property' => 'color',
            ],
          ],
          'topic_link_hover_color'        => [
            'type'        => 'color',
            'label'       => __( 'Link Hover Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic a:hover',
              'property' => 'color',
            ],
          ],
          'topic_current_link_color'      => [
            'type'        => 'color',
            'label'       => __( 'Current Link Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic .learndash-current-menu-item a',
              'property' => 'color',
            ],
          ],
          'topic_current_link_font_style' => [
            'type'    => 'select',
            'label'   => __( 'Current Link Font Style', 'fl-theme-builder' ),
            'default' => 'normal',
            'options' => [
              'normal' => 'Normal',
              'italic' => 'Italic',
            ],
            'preview' => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-list .bdash-topic .learndash-current-menu-item a',
              'property' => 'font-style',
            ],
          ],
        ],
      ], // Topics

      'quiz_styles'   => [
        'title'  => 'Quiz',
        'fields' => [
          'quiz_font'                    => [
            'type'    => 'font',
            'default' => [
              'family' => 'Default',
              'weight' => 300,
            ],
            'label'   => __( 'Font', 'fl-builder' ),
            'preview' => [
              'type'     => 'font',
              'selector' => '.fl-module-content .bdash-quiz',
            ],
          ],
          'quiz_font_size'               => [
            'type'        => 'text',
            'label'       => __( 'Font Size', 'fl-theme-builder' ),
            'default'     => '',
            'size'        => '5',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-quiz',
              'property' => 'font-size',
              'unit'     => 'px',
            ],
          ],
          'quiz_letter_spacing'          => [
            'type'        => 'text',
            'label'       => __( 'Letter Spacing', 'fl-theme-builder' ),
            'default'     => '',
            'size'        => '5',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-quiz',
              'property' => 'letter-spacing',
              'unit'     => 'px',
            ],
          ],
          'quiz_link_color'              => [
            'type'        => 'color',
            'label'       => __( 'Link Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-quiz a',
              'property' => 'color',
            ],
          ],
          'quiz_link_hover_color'        => [
            'type'        => 'color',
            'label'       => __( 'Link Hover Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-quiz a:hover',
              'property' => 'color',
            ],
          ],
          'quiz_current_link_color'      => [
            'type'        => 'color',
            'label'       => __( 'Current Link Color', 'fl-theme-builder' ),
            'show_reset'  => true,
            'connections' => [ 'color' ],
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-quiz.learndash-current-menu-item a',
              'property' => 'color',
            ],
          ],
          'quiz_current_link_font_style' => [
            'type'    => 'select',
            'label'   => __( 'Current Link Font Style', 'fl-theme-builder' ),
            'default' => 'normal',
            'options' => [
              'normal' => 'Normal',
              'italic' => 'Italic',
            ],
            'preview' => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-quiz.learndash-current-menu-item a',
              'property' => 'font-style',
            ],
          ],
        ],
      ], // Quizzes

    ], // Text Style: Sections
  ], // Text Style


  'item_spacing' => [
    'title'    => 'Spacing',
    'sections' => [
      'lesson_list' => [
        'title'  => 'Lesson List',
        'fields' => [
          'lesson_list_padding' => [
            'type'        => 'dimension',
            'label'       => '',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list',
              'property' => 'padding',
              'unit'     => 'px',
            ],
            'placeholder' => '0',
            'responsive'  => true,
          ],
        ],
      ],
      'lesson'      => [
        'title'  => 'Lesson',
        'fields' => [
          'lesson_padding' => [
            'type'        => 'dimension',
            'label'       => '',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-lesson',
              'property' => 'padding',
              'unit'     => 'px',
            ],
            'placeholder' => '0',
            'responsive'  => true,
          ],
        ],
      ],
      'topic'       => [
        'title'  => 'Topic',
        'fields' => [
          'topic_padding' => [
            'type'        => 'dimension',
            'label'       => '',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-list .bdash-topic',
              'property' => 'padding',
              'unit'     => 'px',
            ],
            'placeholder' => '0',
            'responsive'  => true,
          ],
        ],
      ],
      'course_quiz' => [
        'title'  => 'Course Quiz',
        'fields' => [
          'course_quiz_padding' => [
            'type'        => 'dimension',
            'label'       => '',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-course-quiz',
              'property' => 'padding',
              'unit'     => 'px',
            ],
            'placeholder' => '0',
            'responsive'  => true,
          ],
        ],
      ],
      'lesson_quiz' => [
        'title'  => 'Lesson Quiz',
        'fields' => [
          'lesson_quiz_padding' => [
            'type'        => 'dimension',
            'label'       => '',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-lesson-quiz',
              'property' => 'padding',
              'unit'     => 'px',
            ],
            'placeholder' => '0',
            'responsive'  => true,
          ],
        ],
      ],
      'topic_quiz'  => [
        'title'  => 'Topic Quiz',
        'fields' => [
          'topic_quiz_padding' => [
            'type'        => 'dimension',
            'label'       => '',
            'description' => 'px',
            'preview'     => [
              'type'     => 'css',
              'selector' => '.fl-module-content .bdash-topic-quiz',
              'property' => 'padding',
              'unit'     => 'px',
            ],
            'placeholder' => '0',
            'responsive'  => true,
          ],
        ],
      ],
    ],
  ], // Item Spacing

  'icons'        => [
    'title'    => 'Icons',
    'sections' => [
      'status'                => [
        'title'  => 'Status',
        'fields' => [
          'main_list_status_icon_visibility' => [
            'type'    => 'select',
            'label'   => 'Show status icon',
            'default' => 'true',
            'options' => [
              'true'  => 'Show',
              'false' => 'Hide',
            ],
          ],
        ],
      ],
      'status_started'        => [
        'title'  => 'Status: Started',
        'fields' => utils\create_setting_fields([
          'type'   => 'icon',
          'prefix' => 'main_list_status_',
          'suffix' => '__started',
          'custom' => [
            'icon_text_on_hover' => [
              'default' => 'Started',
            ],
            'icon_padding'       => [
              'preview' => [
                'selector' => '.fl-module-content .bdash-navigation .bdash-status-icon--started',
              ],
            ],
          ],
        ]),
      ],
      'status_completed'      => [
        'title'  => 'Status: Completed',
        'fields' => utils\create_setting_fields([
          'type'   => 'icon',
          'prefix' => 'main_list_status_',
          'suffix' => '__completed',
          'custom' => [
            'icon_text_on_hover' => [
              'default' => 'Completed',
            ],
            'icon_padding'       => [
              'preview' => [
                'selector' => '.fl-module-content .bdash-navigation .bdash-status-icon--completed',
              ],
            ],
          ],
        ]),
      ],
      'status_locked'         => [
        'title'  => 'Status: Locked',
        'fields' => utils\create_setting_fields([
          'type'   => 'icon',
          'prefix' => 'main_list_status_',
          'suffix' => '__locked',
          'custom' => [
            'icon_text_on_hover' => [
              'default' => 'Locked',
            ],
            'icon_padding'       => [
              'preview' => [
                'selector' => '.fl-module-content .bdash-navigation .bdash-status-icon--locked',
              ],
            ],
          ],
        ]),
      ],
      'video_indicator'       => [
        'title'  => 'Indicator: Video',
        'fields' => [
          'main_list_video_indicator_visibility' => [
            'type'    => 'select',
            'label'   => 'Show video indicator icon',
            'default' => 'false',
            'options' => [
              'true'  => 'Show',
              'false' => 'Hide',
            ],
          ],
        ] + utils\create_setting_fields([
          'type'   => 'icon',
          'prefix' => 'main_list_video_indicator_',
          'custom' => [
            'icon_text_on_hover' => [
              'default' => 'Video',
            ],
            'icon_padding'       => [
              'preview' => [
                'selector' => '.fl-module-content .bdash-navigation .bdash-video-indicator',
              ],
            ],
          ],
        ]),
      ],
      'quiz_indicator'        => [
        'title'  => 'Indicator: Quiz',
        'fields' => [
          'main_list_quiz_indicator_visibility' => [
            'type'    => 'select',
            'label'   => 'Show quiz indicator icon',
            'default' => 'false',
            'options' => [
              'true'  => 'Show',
              'false' => 'Hide',
            ],
          ],
        ] + utils\create_setting_fields([
          'type'   => 'icon',
          'prefix' => 'main_list_quiz_indicator_',
          'custom' => [
            'icon_text_on_hover' => [
              'default' => 'Quiz',
            ],
            'icon_padding'       => [
              'preview' => [
                'selector' => '.fl-module-content .bdash-navigation .bdash-quiz-indicator',
              ],
            ],
          ],
        ]),
      ],
      'certificate_indicator' => [
        'title'  => 'Indicator: Certificate',
        'fields' => [
          'main_list_certificate_indicator_visibility' => [
            'type'    => 'select',
            'label'   => 'Show certificate indicator icon',
            'default' => 'true',
            'options' => [
              'true'  => 'Show',
              'false' => 'Hide',
            ],
          ],
        ] + utils\create_setting_fields([
          'type'   => 'icon',
          'prefix' => 'main_list_certificate_indicator_',
          'custom' => [
            'icon_text_on_hover' => [
              'default' => 'Certificate',
            ],
            'icon_padding'       => [
              'preview' => [
                'selector' => '.fl-module-content .bdash-navigation .bdash-certificate-indicator',
              ],
            ],
          ],
        ]),
      ],
    ],
  ],
]);
