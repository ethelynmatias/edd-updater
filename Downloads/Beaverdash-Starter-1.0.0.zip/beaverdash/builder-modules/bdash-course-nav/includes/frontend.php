<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\course_navigation(
  utils\module_atts( $settings, $module )
);
