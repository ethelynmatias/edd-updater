jQuery(document).ready(function($) {

  var activate = window.BDash && window.BDash.activateNavigation
	var selector = '.fl-node-<?= $id ?> .bdash-course-navigation'

  if (activate) activate(selector)

});