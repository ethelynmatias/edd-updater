<?php

use BeaverDash\utils as utils;

utils\render_module_css([
    'prefix'    => ".fl-node-$id .fl-module-content",
    'elements'  => [
    [ 'types' => ['typography'] ],
  ],
], $settings, $global_settings);