<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\materials(
utils\module_atts($settings, [
    'item',
  ])
);
