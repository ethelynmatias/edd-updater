<?php

namespace BeaverDash;

use BetterDash as bdash;

foreach ( [ 'before', 'after' ] as $value ) {

  if ( isset( $settings->{$value . '_status_text_type'} ) ) {
      if ($settings->{$value . '_status_text_type'} === 'html')
          ${$value . '_content'} = $settings->{$value . '_status_html'};
      elseif ($settings->{$value . '_status_text_type'} === 'text')
          ${$value . '_content'} = $settings->{$value . '_status_text'};
  }
}
?>

<div class="bdash-course-price bdash-course-price-<?= bdash\course_price_type() ?>">
    <?= $before_content ?> 
    <?= bdash\course_price() ?>
    <?= $after_content ?> 
</div>

