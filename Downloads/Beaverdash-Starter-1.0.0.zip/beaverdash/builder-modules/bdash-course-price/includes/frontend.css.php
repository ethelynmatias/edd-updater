<?php

use BeaverDash\status as status;

/**
 * @see  bdash-status-base/css.php
 */
status\render_css($id, $module, $settings, $global_settings, 'bdash-course-price');

$prefix = ".fl-node-$id .fl-module-content";

foreach (['subscribe','closed','paynow','free','open'] as $type) {
  
  if (isset($settings->{'course_text_color_' . $type})) {

    if (isset($settings->{'course_text_color_' . $type})) {
        ?><?= $prefix ?> .bdash-course-price-<?= $type ?> { color: #<?= $settings->{'course_text_color_' . $type}; ?>; }<?php
    }   
  }
}
