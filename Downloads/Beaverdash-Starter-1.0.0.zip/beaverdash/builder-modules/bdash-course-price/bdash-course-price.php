<?php

namespace BeaverDash\course_price;

use BeaverDash\utils as utils;
use BeaverDash\status as status;

class BDash_Course_Price extends \FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Course Price', 'beaverdash' ),
      'description' => __( 'Display course price', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Course', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      // 'icon'        => 'format-video.svg',
    ));
  }
}



\FLBuilder::register_module('BeaverDash\course_price\BDash_Course_Price', [

  // General
  'general' => [
    'title'    => 'General',
    'sections' => array_merge(
      status\create_setting_sections( [ 'type' => 'text' ] ),
      create_setting_section_course_type()
    ),
  ],
  // End general

  // Style
  'style'   => [
    'title'    => 'Style',
    'sections' => status\create_setting_sections( [ 'type' => 'style' ] ),
  ],
  // End style

]);

function create_setting_section_course_type() {

  $price_type_fields = array();
  $price_type        = array(
    'subscribe' => 'Subscribe',
    'closed'    => 'Closed',
    'paynow'    => 'Buy Now',
    'free'      => 'Free',
    'open'      => 'Open',
  );

  foreach ( $price_type as $key => $label ) {
    $price_type_fields = array_merge($price_type_fields, [
      'course_' . $key => [
        'title'  => 'Type: ' . $label,
        'fields' => [
          'course_text_color_' . $key => [
            'type'        => 'color',
            'label'       => 'Color',
            'default'     => '0086b0',
            'connections' => [ 'color' ],
          ],
        ],
      ],
    ]);
  }

  return $price_type_fields;
}
