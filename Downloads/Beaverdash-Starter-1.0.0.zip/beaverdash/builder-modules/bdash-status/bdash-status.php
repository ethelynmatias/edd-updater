<?php

class BDash_Status extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Status', 'beaverdash' ),
      'description' => __( 'Display course/lesson/topic/quiz status', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Content', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      // 'icon'        => 'format-video.svg',
    ));
  }
}

\BeaverDash\status\register_module( 'BDash_Status' );

