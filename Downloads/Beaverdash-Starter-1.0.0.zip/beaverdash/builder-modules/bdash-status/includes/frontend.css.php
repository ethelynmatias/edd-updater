<?php

/**
 * @see  bdash-status-base/css.php
 */
\BeaverDash\status\render_css($id, $module, $settings, $global_settings);