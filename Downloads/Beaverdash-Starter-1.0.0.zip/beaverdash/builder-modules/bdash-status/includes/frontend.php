<?php

namespace BeaverDash;

use BetterDash as bdash;

$atts = utils\module_atts( $settings, $module );

$status = '';

$source = isset( $settings->source ) ? $settings->source : 'current';

switch ( $source ) {
  case 'parent':
    $parent = $settings->parent;
    $status = $parent === 'course_parent' ? bdash\course_status() : bdash\lesson_status();
        break;

  case 'course':
    $id     = (int) $settings->course_id;
    $status = bdash\course_status( $id );
        break;

  case 'lesson':
    $id     = (int) $settings->lesson_id;
    $status = bdash\lesson_status( $id );
        break;

  case 'topic':
    $id     = (int) $settings->topic_id;
    $status = bdash\topic_status( $id );
        break;

  case 'quiz':
    $id     = (int) $settings->quiz_id;
    $status = bdash\quiz_status( $id );
        break;

  default:
    if (bdash\is_course()) $status     = bdash\course_status();
    elseif (bdash\is_lesson()) $status = bdash\lesson_status();
    elseif (bdash\is_topic()) $status  = bdash\topic_status();
    elseif (bdash\is_quiz()) $status   = bdash\quiz_status();
        break;
}

$prefix  = 'before_status';
$type    = @$atts[ "{$prefix}_text_type" ] === 'html' ? 'html' : 'text';
$content = @$atts[ "{$prefix}_$type" ];

$type = @$atts[ "{$prefix}_text_type" ];

switch ( $status ) {
  case 'open':
  case 'started':
  case 'completed':
  case 'locked':
    $prefix   = "status_{$status}";
    $type     = @$atts[ "{$prefix}_text_type" ] === 'html' ? 'html' : 'text';
    $content .= @$atts[ "{$prefix}_$type" ];
        break;
  default:
    $content = ucfirst( $status );
        break;
}


$prefix   = 'after_status';
$type     = in_array( @$atts[ "{$prefix}_text_type" ], [ 'html', 'text', 'none', 'icon', 'texticon' ] ) ? @$atts[ "{$prefix}_text_type" ] : 'text';
$content .= @$atts[ "{$prefix}_$type" ];

$type = @$atts[ "status_{$status}_text_type" ];

if ( isset( $type ) && $type !== 'none' ) {

  switch ( $type ) {
    case 'text':
      $classes = 'bdash-status-' . $status;
          break;

    case 'texticon':
      $classes = 'bdash-status-' . $status . ' ' . @$atts[ "status_{$status}_icon" ];
          break;

    case 'icon':
      $classes = @$atts[ "status_{$status}_icon" ];
          break;

    default:
      $classes = 'bdash-status-' . $status;
          break;
  }

  echo '<span class="' . $classes . '">';
  echo in_array( $type, [ 'text', 'html', 'texticon' ] ) ? do_shortcode( $content ) : '';
  echo '</span>';
}
