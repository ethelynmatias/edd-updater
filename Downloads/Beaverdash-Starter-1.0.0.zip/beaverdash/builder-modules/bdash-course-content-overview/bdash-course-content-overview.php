<?php

use BeaverDash\content_overview;
use \BeaverDash\utils as utils;

class BDash_Course_Content_Overview extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'Course Content', 'beaverdash' ),
      'description' => __( 'Display course content overview', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'Course', 'beaverdash' ),
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
      'icon'        => 'editor-table.svg',
    ));
  }
}

FLBuilder::register_module('BDash_Course_Content_Overview', [
  'style' => [
    'title'    => 'Style',
    'sections' => [
      'custom_styles' => [
        'title'  => 'Styles',
        'fields' => [
          'content_overview_bg_color'         => [
            'type'        => 'color',
            'label'       => 'Background color',
            'default'     => 'ffffff',
            'connections' => [ 'color' ],
          ],
          'content_overview_primary_color'    => [
            'type'        => 'color',
            'label'       => 'Primary color',
            'default'     => '80d642',
            'connections' => [ 'color' ],
          ],
          'content_overview_text_color'       => [
            'type'        => 'color',
            'label'       => 'Text color',
            'default'     => '555555',
            'connections' => [ 'color' ],
          ],
          'content_overview_text_hover_color' => [
            'type'        => 'color',
            'label'       => 'Hover text color',
            'default'     => '80d642',
            'connections' => [ 'color' ],
          ],
        ],
      ],
      'typography'    => [
        'title'  => 'Typography',
        'fields' => [
          'typography'       => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography' ] ),
          'typography_title' => BeaverDash\utils\create_setting_fields( [ 'type' => 'typography_title' ] ),
        ],
      ],
    ],
  ],
]);
