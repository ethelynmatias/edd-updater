<?php

// Global: $id, $module, $settings, $global_settings

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";
$el = "$prefix .bdash-course-content-overview";

utils\render_module_css([
    'prefix'    => $el,
    'elements'  => [
    [ 'types' => ['typography', 'typography_title'] ],
  ],
], $settings, $global_settings);


if (isset($settings->content_overview_bg_color)) {
  ?><?= $el ?> .learndash-wrapper .ld-item-list .ld-item-list-item { background-color: #<?= $settings->content_overview_bg_color; ?>; color: #<?= $settings->content_overview_bg_color ?>; }<?php
}

if (isset($settings->content_overview_primary_color)) {
  ?><?= $el ?> .learndash-wrapper .ld-section-heading .ld-expand-button, <?= $el ?> .learndash-wrapper .ld-expand-button .ld-icon::before, <?= $el ?> .learndash-wrapper .ld-primary-background { 
    background-color: #<?= $settings->content_overview_primary_color ?> !important; 
  }<?php

  ?><?= $el ?> .learndash-wrapper .ld-primary-color { 
    color: #<?= $settings->content_overview_primary_color ?> !important; 
  }<?php
}

if (isset($settings->content_overview_text_color)) {
  ?><?= $el ?> .learndash-wrapper .ld-item-list .ld-item-list-item .ld-item-name  { color: #<?= $settings->content_overview_text_color ?>; }<?php
}

if (isset($settings->content_overview_text_hover_color)) {
  ?><?= $el ?> .learndash-wrapper .ld-item-list .ld-item-list-item a.ld-item-name:hover, <?= $el ?> .learndash-wrapper .ld-item-title:hover, <?= $el ?> .learndash-wrapper .ld-primary-color-hover:hover { color: #<?= $settings->content_overview_text_hover_color ?> !important; }<?php
}
