<?php

namespace BeaverDash;

use BetterDash as bdash;

echo bdash\shortcode\course_content_overview(
  utils\module_atts( $settings, $module )
);
