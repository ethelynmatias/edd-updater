<?php

namespace BeaverDash;

echo do_shortcode( '[ld_profile]' );
