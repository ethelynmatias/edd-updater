<?php

use BeaverDash\utils as utils;

$prefix = ".fl-node-$id .fl-module-content";

utils\render_module_css([
    'prefix'    => $prefix,
    'elements'  => [
    [ 'types' => ['typography', 'typography_title'] ],
  ],
], $settings, $global_settings);