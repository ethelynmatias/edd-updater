<?php

use BeaverDash\utils as utils;

class BDash_User_Profile extends FLBuilderModule {

  public function __construct() {
    parent::__construct(array(
      'name'        => __( 'User Profile', 'beaverdash' ),
      'description' => __( 'Display the user profile and links to enrolled courses', 'beaverdash' ),
      'group'       => beaverdash()->state['module_group_name'],
      'category'    => __( 'User', 'beaverdash' ),
      // 'icon'        => '',
      'dir'         => __DIR__,
      'url'         => plugins_url( '', __FILE__ ),
      // 'partial_refresh' => true,
    ));
  }
}

FLBuilder::register_module('BDash_User_Profile', [
  'style' => [
    'title'    => 'Style',
    'sections' => [
      'typography' => [
        'title'  => 'Typography',
        'fields' => [
          'typography'       => utils\create_setting_fields( [ 'type' => 'typography' ] ),
          'typography_title' => utils\create_setting_fields( [ 'type' => 'typography_title' ] ),
        ],
      ],
    ],
  ],
]);
