<?php

namespace BeaverDash;

// Render Post Grid setting section
// @see plugins/bb-plugin/settings/ui-loop-settings.php

add_action('fl_builder_loop_settings_after_form', function( $settings, $custom_grid_options = [] ) {

  // Show only for these post types
  $allowed_types = [
  'sfwd-courses',
  'sfwd-lessons',
  'sfwd-topic',
  'sfwd-quiz',
  'sfwd-certificates',
  ];

  $setting_class = '';

  if ( ! isset( $settings->post_type ) || ! in_array( $settings->post_type, $allowed_types ) ) {
    $setting_class = 'fl-custom-query-filter';
    foreach ( $allowed_types as $key ) {
      $setting_class .= " fl-custom-query-$key-filter";
    }
  }

  // Set default limit based on current preview's post type

  $current_post_type        = utils\get_preview_post_type();
  $default_limit_to_current = 'false';

  if ( $settings->post_type === 'sfwd-lessons' ) {
    $default_limit_to_current = 'true'; // Current course
  } elseif ( $settings->post_type === 'sfwd-topic' ) {
    $default_limit_to_current = 'lesson';
  } elseif ( $settings->post_type === 'sfwd-quiz' ) {
    if ( $current_post_type === 'sfwd-lessons' ) {
      $default_limit_to_current = 'lesson';
    } elseif ( $current_post_type === 'sfwd-topic' ) {
      $default_limit_to_current = 'topic';
    } else {
      $default_limit_to_current = 'true';
    }
  } elseif ( $settings->post_type === 'sfwd-certificates' ) {
    $default_limit_to_current = $current_post_type === 'sfwd-quiz'
    ? 'quiz'
    : 'true';
  }

  ?>
<div class="fl-custom-query fl-loop-data-source" data-source="custom_query">
  <div class="<?= $setting_class ?>">
    <div id="fl-builder-settings-section-general" class="fl-builder-settings-section">

        <h3 class="fl-builder-settings-title">
            <span class="fl-builder-settings-title-text-wrap"><?php
            _e( 'LearnDash Filters', 'fl-builder' );
            ?></span>
        </h3>
        <table class="fl-form-table">
  <?php

    	\FLBuilder::render_settings_field('limit_to_current_course', [
    		'type'    => 'select',
    		'label'   => __( 'Limit to current', 'fl-builder' ),
        'default' => $default_limit_to_current,
    		'options' => [
    			'false'  => __( 'None', 'fl-builder' ),
    			'true'   => __( 'Course', 'fl-builder' ),
    			'lesson' => __( 'Lesson', 'fl-builder' ),
    			'topic'  => __( 'Topic', 'fl-builder' ),
    			'quiz'   => __( 'Quiz', 'fl-builder' ),
    		],
        'toggle' => [
          'true'    => ['fields' => ['include_child_quizzes']],
          'lesson'  => ['fields' => ['include_child_quizzes_lesson']],
        ],
    	], $settings);

      if ( $settings->post_type === 'sfwd-quiz' ) {

        \FLBuilder::render_settings_field('include_child_quizzes', [
          'type'    => 'select',
          'label'   => __( 'Include child quizzes', 'fl-builder' ),
          'default' => 'false',
          'options' => [
            'false'   => __( "Don't include child quizzes", 'fl-builder' ),
            'true'    => __( 'Include all child quizzes', 'fl-builder' ),
            'lesson'  => __( 'Include lesson quizzes only', 'fl-builder' ),
            'topic'   => __( 'Include topic quizzes only', 'fl-builder' ),
          ]
        ], $settings);

        \FLBuilder::render_settings_field('include_child_quizzes_lesson', [
          'type'    => 'select',
          'label'   => __( 'Include child quizzes', 'fl-builder' ),
          'default' => 'false',
          'options' => [
            'false'   => __( "Don't include child quizzes", 'fl-builder' ),
            'true'    => __( 'Include all child quizzes', 'fl-builder' ),
          ]
        ], $settings);

      }
  ?>
      </table>

    </div>
  </div>
</div>
  <?php

});
