<?php

namespace BeaverDash;

use BetterDash as bdash;

/**
 * Post Grid: Provide CSS classes based on course/lesson/topic/user status
 *
 * @see plugins/bb-plugin/modules/post-grid/post-grid.php
 */

add_filter('fl_builder_posts_module_classes', function( $classes, $settings ) {

  return bdash\post_classes( $classes );

}, 10, 2);
