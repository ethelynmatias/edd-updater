<?php

namespace BeaverDash;

use BetterDash as bdash;

// Filter Post Grid posts query
// @see bb-plugin/classes/class-fl-builder-loop.php custom_query()

add_filter('fl_builder_loop_query_args', function( $args ) {

  /**
   * NOTE: The settings property should be guaranteed, but in one case
   * it didn't exist and raised a warning. Possibly another plugin is
   * using the filter wrong.
   */
  if (!isset($args['settings'])) return $args;

  global $post;

  if ( ! empty( $post ) ) {
    $current_post_type = $post->post_type;
    $current_post_id   = $post->ID;
  } else {
    // When paged, current post is empty for some reason
    $current_post_type = '';
    $current_post_id   = 0;
  }

  $settings       = $args['settings'];
  $list_post_type = @$args['post_type'];

  $is_listing_certificates = $list_post_type === 'sfwd-certificates';
  $is_listing_quizzes      = $list_post_type === 'sfwd-quiz';

  if (!isset($settings->limit_to_current_course)) {
    // Provide default value in case this setting does not exist
    // @see ./settings.php, $default_limit_to_current
    $settings->limit_to_current_course = 'false';
  }

  // Get the right child setting according to the current post type limit
  $setting_key = $settings->limit_to_current_course === 'lesson'
    ? 'include_child_quizzes_lesson'
    : 'include_child_quizzes';

  $include_child_quizzes = $is_listing_quizzes &&
    isset($settings->$setting_key) && $settings->$setting_key !== 'false'
    ? $settings->$setting_key
    : false;

  switch ($settings->limit_to_current_course) {

    case 'true': // true is course for compatibility reasons
      $current_post_id = bdash\course_id($current_post_id);
      $current_post_type = 'sfwd-courses';
      break;

    case 'lesson':
      $current_post_id = bdash\lesson_id($current_post_id);
      $current_post_type = 'sfwd-lessons';
      break;

    case 'topic':
      $current_post_id = bdash\topic_id($current_post_id);
      $current_post_type = 'sfwd-topic';
      break;
  }

  $is_shared_steps = bdash\course_builder_shared_steps();

  $matching_ids = false;

  // Limit to current course, lesson, topic or quiz

  $valid_limits       = [ 'true', 'lesson', 'topic', 'quiz' ];
  $valid_post_types   = [ 'sfwd-courses', 'sfwd-lessons', 'sfwd-topic', 'sfwd-quiz' ];
  $is_valid_post_type = in_array( $current_post_type, $valid_post_types );

  $should_apply_post_type_limit =
    $is_valid_post_type
    && in_array( $settings->limit_to_current_course, $valid_limits );

  if ( ! $should_apply_post_type_limit ) return $args;

  if ( $should_apply_post_type_limit ) {

    // Get IDs of this post type that belongs to current course/lesson/topic/quiz

    $matching_ids = [];

    $items = [];

    if ( $is_shared_steps ) {
      if ( $list_post_type === 'sfwd-lessons' ) {
         $items = bdash\lessons( $current_post_id );
      } elseif ( $list_post_type === 'sfwd-topic' ) {
         $items = bdash\topics( $current_post_id );
      } elseif ( $list_post_type === 'sfwd-quiz' ) {
         $items = bdash\quizzes( $current_post_id );
      } else {
        $items = bdash\all_posts($list_post_type, [ 'fields' => 'id' ]);
      }
    } else {
      $items = bdash\all_posts($list_post_type, [ 'fields' => 'id' ]);
    }

    $is_course = $current_post_type === 'sfwd-courses';
    $is_lesson = $current_post_type === 'sfwd-lessons';
    $is_topic  = $current_post_type === 'sfwd-topic';
    $is_quiz   = $current_post_type === 'sfwd-quiz';

    // Quizzes
    $quiz_ids = [];
    if ( $is_listing_quizzes && ! $include_child_quizzes ) {

      // Only include current item's quizzes

      $quiz_ids = array_map(function( $quiz ) {
        return $quiz->ID;
      }, bdash\quizzes( $current_post_id ));
    }

    // Certificates
    $certificate_ids = [];
    if ( $is_listing_certificates ) {
      $certificate_ids = bdash\certificate_ids( $current_post_id );
    }

    foreach ( $items as $item ) {

      // If item matches condition

      $item_id    = $item->ID;
      $compare_id = 0;

      if ( $is_listing_certificates ) {
        if ( in_array( $item_id, $certificate_ids ) ) {
            $matching_ids[] = $item_id;
        }
        continue;
      }

      if ( ! $is_shared_steps ) {
        if ( $is_course ) {
          $compare_id = bdash\course_id( $item_id );
        } elseif ( $is_lesson ) {
            $compare_id = bdash\lesson_id( $item_id );
        } elseif ( $is_topic ) {
            $compare_id = bdash\topic_id( $item_id );
        } elseif ( $is_quiz ) {
        }
      }

      if( $is_listing_quizzes ) {

        switch ($settings->limit_to_current_course) {

          case 'true': // true is course for compatibility reasons
            $compare_id = bdash\course_id( $item_id );
            if( empty($compare_id) ) continue 2;

            $is_topic_child   = !empty(bdash\topic_id( $item_id ));
            $is_lesson_child  = !$is_topic_child && !empty(bdash\lesson_id( $item_id ));

            if( $include_child_quizzes === 'lesson' && !$is_lesson_child ) continue 2;
            if( $include_child_quizzes === 'topic' && !$is_topic_child ) continue 2;
            if( $include_child_quizzes === false && ($is_lesson_child || $is_topic_child) ) continue 2;
            break;

          case 'lesson':
            $compare_id = bdash\lesson_id( $item_id );
            $is_topic_child = !empty(bdash\topic_id( $item_id ));
            if( $include_child_quizzes === false && $is_topic_child ) continue 2;
            break;

          case 'topic':
            $compare_id = bdash\topic_id( $item_id );
            $current_post_id = bdash\topic_id( $current_post_id );
            break;
        }
      }

      if ($is_listing_quizzes && ! $include_child_quizzes
        && $settings->limit_to_current_course === 'false'
        && ! in_array( $item_id, $quiz_ids )
      ) continue;

      if ( $is_shared_steps || $compare_id == $current_post_id ) {
        $matching_ids[] = $item_id;
      }
    }
  }

  // Pass filtered query

  if ( empty( $matching_ids ) ) {

    // Empty post__in query results in all posts returned
    // https://core.trac.wordpress.org/ticket/28099

    // Work-around for empty result
    $args['post__in'] = [ -1 ];

  } else {

    $args['post__in'] = $matching_ids;

    if ( empty( $args['orderby'] ) ) {
      $args['orderby'] = 'post__in';
    }

    // Exclude posts manually, since post__in overrides post__not_in

    if (isset($args['post__not_in'])) {

      foreach ($args['post__not_in'] as $exclude_id) {
        $pos = array_search($exclude_id, $args['post__in']);
        if ($pos!==false) {
          array_splice($args['post__in'], $pos, 1);
        }
      }

      if (empty($args['post__in'])) {
        $args['post__in'] = [ -1 ]; // Force empty
      }
    }
  }

  return $args;

}, 10, 1);
