<?php

require __DIR__ . '/post-grid/index.php';
