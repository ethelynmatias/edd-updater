<?php

beaverdash()->state['shortcode_callbacks'] = [];

/**
 * Beaver-specific shortcodes - Unused for now
 */
/*
foreach ([

] as $tag) {

  $fn = "\BeaverDash\shortcode\\$tag";

  add_shortcode("bdash_$tag", $fn);
  beaverdash()->state['shortcode_callbacks'][$tag] = $fn;
}
*/

/**
 * Remove stats shortcodes for Starter variant
 */
add_filter('betterdash_shortcode_groups', function( $shortcode_groups ) {
  unset( $shortcode_groups['Stats'] );
  return $shortcode_groups;
}, 10, 1);
