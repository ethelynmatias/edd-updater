// Config for Tangible Builder

const assets = {
  bloopsBase: 'builder-modules/bloops-base/assets'
}

module.exports = {
  build: [
    {
      task: 'js',
      src: `${assets.bloopsBase}/src/item-template-builder/index.js`,
      dest: `${assets.bloopsBase}/build/item-template-builder.js`,
      watch: `${assets.bloopsBase}/src/item-template-builder/**/*.{js,ts,tsx}`
    },
    {
      task: 'sass',
      src: `${assets.bloopsBase}/src/item-template-builder/index.scss`,
      dest: `${assets.bloopsBase}/build/item-template-builder.css`,
      watch: `${assets.bloopsBase}/src/item-template-builder/**/*.scss`
    }
  ]
}
