<?php
/**
 * Plugin Name: Tangible: BeaverDash - Starter Edition
 * Plugin URI: https://tangibleplugins.com/beaverdash
 * Description: LearnDash integration for Beaver Builder
 * Version: 1.2.8
 * Author: Team Tangible
 * Author URI: https://teamtangible.com
 * License: GPLv2 or later
 */

define( 'BeaverDash_VER', '1.2.8' );
define( 'BeaverDash_FILE', __FILE__ );
define( 'BeaverDash_DIR', plugin_dir_path( __FILE__ ) );
define( 'BeaverDash_URL', plugins_url( '/', __FILE__ ) );
define( 'BeaverDash_PATH', plugin_basename( __FILE__ ) );

require __DIR__ . '/vendor/tangible/logic/index.php';
require __DIR__ . '/vendor/tangible/betterdash/index.php';
require __DIR__ . '/vendor/tangible/plugin-framework/index.php';

require __DIR__ . '/base.php';
require __DIR__ . '/settings/index.php';
require __DIR__ . '/utils/index.php';
require __DIR__ . '/modules/index.php';
require __DIR__ . '/shortcodes/index.php'; // Define shortcodes after modules

add_action('plugins_loaded', function() {

  if ( ! class_exists( 'FLBuilder' )) return;

  include __DIR__ . '/field-connections/index.php';
  include __DIR__ . '/builder-extensions/index.php';
  include __DIR__ . '/builder-modules/index.php';
  include __DIR__ . '/themer-extensions/index.php';

}, 10);
