<?php

/*
"Modules" - features with CSS & JS, that build on core functions

Scripts are registered, then enqueued as needed
Styles are all enqueued, to avoid flash of unstyled content

*/
