<?php

namespace BeaverDash\utils;

function php_to_js_keys( $src, $options = [] ) {
  return beaverdash()->framework->php_to_js_keys( $src, $options );
}

function js_to_php_keys( $src, $options = [] ) {
  return beaverdash()->framework->js_to_php_keys( $src, $options );
}
