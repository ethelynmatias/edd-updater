<?php

namespace BeaverDash\utils;

function get_preview_post_type() {

  // Get currently previewing post's type, inside builder

  \FLThemeBuilderRulesLocation::set_preview_query();

  global $post;
  $current_post      = $post;
  $current_post_type = ! empty( $current_post ) ? $current_post->post_type : '';

  \FLThemeBuilderRulesLocation::reset_preview_query();

  return $current_post_type;
}
