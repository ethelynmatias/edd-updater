<?php

namespace BeaverDash\utils;

// Utility function to create common setting fields from templates

function create_setting_fields( $config, $template_fields = [] ) {

  $type = $config['type'];

  if ( empty( $template_fields ) ) {
    $templates       = beaverdash()->state['setting_field_templates'];
    $template_fields = $templates[ $type ];
  }

  $prefix = isset( $config['prefix'] ) ? $config['prefix'] : '';
  $suffix = isset( $config['suffix'] ) ? $config['suffix'] : '';
  $custom = isset( $config['custom'] ) ? $config['custom'] : [];

  $fields = [];

  foreach ( $template_fields as $key => $field_config ) {

    $field_key            = "{$prefix}{$key}{$suffix}";
    $fields[ $field_key ] = $field_config;

    if ( ! isset( $custom[ $key ] )) continue;
    foreach ( $custom[ $key ] as $custom_key => $custom_value ) {
      if ( ! is_array( $custom_value ) ) {
        $fields[ $field_key ][ $custom_key ] = $custom_value;
        continue;
      }
      $fields[ $field_key ][ $custom_key ] = array_merge(
        $fields[ $field_key ][ $custom_key ], $custom_value
      );
    }
  }

  return $fields;
}

beaverdash()->state['setting_field_templates'] = [
  'icon'             => [
    'icon_text_on_hover' => [
      'type'    => 'text',
      'label'   => 'Text on hover',
      'default' => '',
    ],
    'icon'               => [
      'type'        => 'icon',
      'label'       => 'Icon',
      'show_remove' => true,
    ],
    'icon_color'         => [
      'type'        => 'color',
      'label'       => 'Icon color',
      'show_reset'  => true,
      'connections' => [ 'color' ],
    ],
    'icon_size'          => [
      'type'        => 'text',
      'label'       => 'Icon size',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '',
    ],
    'icon_padding'       => [
      'type'        => 'dimension',
      'label'       => 'Padding',
      'description' => 'px',
      'preview'     => [
        'type'     => 'css',
        'selector' => '', // Should be set by template consumer
        'property' => 'padding',
        'unit'     => 'px',
      ],
      'placeholder' => '0',
      'responsive'  => true,
    ],
  ],
  'border'           => [
    'border_width' => [
      'type'        => 'text',
      'label'       => 'Border width',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
      'sanitize'    => 'absint',
    ],
    'border_color' => [
      'type'        => 'color',
      'label'       => 'Border color',
      'default'     => 'ddd',
      'connections' => [ 'color' ],
      'show_reset'  => true,
    ],
  ],
  'border-radius'    => [
    'border_radius' => [
      'type'        => 'text',
      'label'       => 'Border radius',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
      'sanitize'    => 'absint',
    ],
  ],
  'box-shadow'       => [
    'box_shadow_enabled' => [
      'type'    => 'select',
      'label'   => 'Box shadow enabled',
      'default' => 'false',
      'options' => [
        'false' => 'False',
        'true'  => 'True',
      ],
    ],
    'box_shadow_x'       => [
      'type'        => 'text',
      'label'       => 'Horizontal',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
      'sanitize'    => 'absint',
    ],
    'box_shadow_y'       => [
      'type'        => 'text',
      'label'       => 'Vertical',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
      'sanitize'    => 'absint',
    ],
    'box_shadow_blur'    => [
      'type'        => 'text',
      'label'       => 'Blur',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
      'sanitize'    => 'absint',
    ],
    'box_shadow_spread'  => [
      'type'        => 'text',
      'label'       => 'Spread',
      'default'     => '',
      'description' => 'px',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
      'sanitize'    => 'absint',
    ],
    'box_shadow_color'   => [
      'type'        => 'color',
      'label'       => 'Color',
      'show_reset'  => true,
      'connections' => [ 'color' ],
    ],
    'box_shadow_opacity' => [
      'type'        => 'text',
      'label'       => 'Opacity',
      'default'     => '1',
      'description' => '',
      'maxlength'   => '3',
      'size'        => '5',
      'placeholder' => '0',
    ],
  ],

  'font'             => [
    'font' => [
      'type'    => 'font',
      'default' => [
        'family' => 'Default',
        'weight' => 300,
      ],
      'label'   => 'Font',
      'preview' => [
        'type'     => 'font',
        'selector' => '.fl-module-content',
      ],
    ],
  ],
  'font-size'        => [
    'font_size' => [
      'type'        => 'text',
      'label'       => 'Font Size',
      'default'     => '',
      'size'        => '5',
      'description' => 'px',
      'preview'     => [
        'type'     => 'css',
        'selector' => '.fl-module-content',
        'property' => 'font-size',
        'unit'     => 'px',
      ],
    ],
  ],
  'align'            => [
    'align' => [
      'type'    => 'select',
      'label'   => 'Alignment',
      'default' => 'left',
      'options' => [
        'left'   => 'Left',
        'center' => 'Center',
        'right'  => 'Right',
      ],
    ],
  ],

  'typography'       => [
    'type'       => 'typography',
    'label'      => __( 'Text', 'fl-builder' ),
    'responsive' => true,
    'preview'    => [
      'type'      => 'css',
      'selector'  => '{node} .fl-module-content, {node} .fl-module-conten button',
      'important' => true,
    ],
  ],
  'typography_title' => [
    'type'       => 'typography',
    'label'      => __( 'Title', 'fl-builder' ),
    'responsive' => true,
    'preview'    => [
      'type'      => 'css',
      'selector'  => '{node} .fl-module-content h3, {node} .fl-module-content h2',
      'important' => true,
    ],
  ],
];
