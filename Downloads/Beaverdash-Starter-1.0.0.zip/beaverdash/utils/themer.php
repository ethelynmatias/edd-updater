<?php

namespace BeaverDash;

// See: ../field-connections

beaverdash()->state['themer_groups']                 = [];
beaverdash()->state['undefined_shortcode_callbacks'] = []; // For debug

/**
 * Add Beaver Themer property group
 *
 * Stores settings and registers on hook automatically
 *
 * @param string $group      Group name (optional)
 * @param array  $properties Properties
 *
 * @see https://kb.wpbeaverbuilder.com/article/391-customize-field-connections-themer
 */

function add_beaver_themer_group( $group = '', $properties = [] ) {

  if ( is_array( $group ) ) {
    // Group not specified
    $properties = $group;
    $group      = 'general';
  }

  $groups = beaverdash()->state['themer_groups'];

  if ( ! isset( $groups[ $group ] ) ) {
    $groups[ $group ] = $properties;
  } else {
    $groups[ $group ] = array_merge( $groups[ $group ], $properties );
  }

  beaverdash()->state['themer_groups'] = $groups;
}

// ------------ Register on hook ------------

add_action('fl_page_data_add_properties', function() {

  $groups = beaverdash()->state['themer_groups'];

  foreach ( $groups as $group => $properties ) {
    add_beaver_themer_group_properties( $group, $properties );
  }
});

function add_beaver_themer_group_properties( $group, $properties ) {

  $default_groups = [
    'general',
  'comments',
  'author',
  'user',
  'site',
  'advanced',
  'woocommerce',
  ];

  if ( ! in_array( $group, $default_groups ) ) {
    \FLPageData::add_group($group, [
      'label' => $group,
    ]);
  }

  $betterdash_shortcodes = bdash()->state['shortcode_callbacks'];
  $beaverdash_shortcodes = beaverdash()->state['shortcode_callbacks'];

  foreach ( $properties as $config ) {

    if ( ! isset( $config['group'] )) $config['group'] = $group;

    $name     = $config['name'];
    $settings = isset( $config['settings'] ) ? $config['settings'] : null;

    // Connection type: post, site, archive
    $connection_type = isset( $config['connection_type'] ) ? $config['connection_type'] : 'post';

    // Don't pass to add_{$connection_type}_property
    unset( $config['name'] );
    unset( $config['settings'] );
    unset( $config['connection_type'] );

    $is_defined = false;

    // Prefix functions with namespace
    foreach ( [ 'getter', 'form' ] as $key ) {

      if ( ! isset( $config[ $key ] )) continue;

      $tag = substr( $config[ $key ], 6 ); // Remove "bdash_"
      $fn  = false;
      if ( isset( $betterdash_shortcodes[ $tag ] ) ) {
        $fn         = $betterdash_shortcodes[ $tag ];
        $is_defined = true;
      } elseif ( isset( $beaverdash_shortcodes[ $tag ] ) ) {
        $fn         = $beaverdash_shortcodes[ $tag ];
        $is_defined = true;
      }

      if ($fn) $config[ $key ]                                    = $fn;
      else beaverdash()->state['undefined_shortcode_callbacks'][] = $config[ $key ];
    }

    if ( ! $is_defined) continue;

    switch ( $connection_type ) {
      case 'archive':
          \FLPageData::add_archive_property( $name, $config );
        if ( ! empty( $settings ) ) {
          \FLPageData::add_archive_property_settings_fields( $name, $settings );
        }
            break;
      case 'site':
          \FLPageData::add_site_property( $name, $config );
        if ( ! empty( $settings ) ) {
          \FLPageData::add_site_property_settings_fields( $name, $settings );
        }
            break;
      case 'post':
      default:
          \FLPageData::add_post_property( $name, $config );
        if ( ! empty( $settings ) ) {
          \FLPageData::add_post_property_settings_fields( $name, $settings );
        }
            break;
    }
  }
}
