<?php

namespace BeaverDash\utils;

/**
 * Extract specified keys from module settings object
 */
function module_atts( $settings, $keys = [] ) {

  $atts = [];

  if ( is_object( $keys ) ) {
    $keys = module_fields( $keys );
  }

  foreach ( $keys as $key ) {
    if ( ! isset( $settings->$key )) continue;
    $atts[ $key ] = $settings->$key;
  }

  return $atts;
}

/**
 * Extract field names from module object
 */
function module_fields( $module ) {

  $fields = [];

  foreach ( $module->form as $group => $data ) {

    if ($group === 'advanced') continue; // Skip default settings

    foreach ( $data['sections'] as $section_key => $section ) {
      foreach ( $section['fields'] as $field_key => $field_settings ) {
        $fields [] = $field_key;
        if ( isset( $field_settings['type'] ) && $field_settings['type'] === 'unit' ) {
          $fields [] = $field_key . '_unit'; // Support for both value and unit for unit fields
        }
      }
    }
  }

  return $fields;
}
