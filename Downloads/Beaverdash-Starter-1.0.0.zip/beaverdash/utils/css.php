<?php

namespace BeaverDash\utils;

function render_module_css($config, $settings, $global_settings) {

  $prefix = $config['prefix'];

  foreach ($config['elements'] as $c) {

    $el = isset($c['el']) ? "{$prefix} {$c['el']}" : $prefix;
    $setting_prefix = @$c['setting_prefix'];
    $setting_suffix = @$c['setting_suffix'];
    $setting_types = $c['types'];

    foreach ($setting_types as $setting_type) {

      // Default: target the whole module, but can be more selective if $el is set
      if ($setting_type === 'typography') {

        // Apply typo settings (BeaverBuilder method)
        \FLBuilderCSS::typography_field_rule([
            'settings'     => $settings,
            'setting_name' => "{$setting_prefix}typography{$setting_suffix}",
            'selector'     => $el,
        ]);

        continue;
      }

      if ($setting_type === 'typography_title') {

        // Apply typo settings (BeaverBuilder method)
        \FLBuilderCSS::typography_field_rule([
            'settings'     => $settings,
            'setting_name' => "{$setting_prefix}typography_title{$setting_suffix}",
            'selector'     => "$el h3, $el h2",
        ]);

        continue;
      }

      // Text

      if ($setting_type=='text') {

        // See: plugins/bb-plugin/classes/class-fl-builder-fonts.php
        $s = "{$setting_prefix}font{$setting_suffix}";
        if ( ! empty( $settings->$s ) && 'Default' != $settings->$s['family'] ) {
          ?><?= $el ?> { <?php \FLBuilderFonts::font_css( $settings->$s ); ?> }<?php
        }

        $s = "{$setting_prefix}font_size{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> { font-size: <?= $settings->$s ?>px; }<?php
        }

        $s = "{$setting_prefix}align{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> { text-align: <?= $settings->$s ?>; }<?php
        }

        $s = "{$setting_prefix}line_height{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> { line-height: <?= $settings->$s ?>px; }<?php
        }

        $s = "{$setting_prefix}letter_spacing{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> { letter-spacing: <?= $settings->$s ?>px; }<?php
        }

        continue;
      } // Text

      if ($setting_type=='link') {

        $s = "{$setting_prefix}link_color{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> a { color: #<?= $settings->$s ?>; }<?php
        }

        $s = "{$setting_prefix}link_font_style{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> a { font-style: <?= $settings->$s ?>; }<?php
        }

        $s = "{$setting_prefix}link_hover_color{$setting_suffix}";
        if ( ! empty( $settings->$s ) ) {
          ?><?= $el ?> a:hover { color: #<?= $settings->$s ?>; }<?php
        }

        continue;
      } // Link

      // Spacing

      if ($setting_type=='spacing') {
        foreach (['', 'medium', 'responsive'] as $res) {

          $is_responsive = !empty($res);
          if ($is_responsive && !$global_settings->responsive_enabled) continue;

          $res_suffix = '';

          if ($is_responsive) {
            $res_suffix = "_{$res}";
            $breakpoint = "{$res}_breakpoint";
            ?>@media (max-width: <?= $global_settings->$breakpoint.'px' ?>) {<?php
          }

          ?><?= $el ?> {<?php
            foreach (['top', 'right', 'bottom', 'left'] as $dir) {
              // Margin
              $s = "{$setting_prefix}margin{$setting_suffix}_{$dir}{$res_suffix}";
              if (!empty($settings->$s)) {
                ?><?= "margin-$dir" ?>: <?= $settings->$s ?>px;<?php
              }

              // Padding
              $s = "{$setting_prefix}padding{$setting_suffix}_{$dir}{$res_suffix}";
              if (!empty($settings->$s)) {
                ?><?= "padding-$dir" ?>: <?= $settings->$s ?>px;<?php
              }
            }
          ?>} <?php

          if ($is_responsive) { ?>}<?php }
        }

        continue;
      }

      // Max width

      if ($setting_type=='max-width') {

        $s = "{$setting_prefix}max_width{$setting_suffix}";

        if ( isset( $settings->$s ) ) {
          $max_width = !empty($settings->$s) ? $settings->$s.'px' : '100%';
          ?><?= $el ?> { max-width: <?= $max_width ?>; }<?php
        }

        continue;
      }

      // Border

      if ($setting_type=='border') {

        $width_key = "{$setting_prefix}border_width{$setting_suffix}";
        $color_key = "{$setting_prefix}border_color{$setting_suffix}";

        if (isset($settings->$width_key) && isset($settings->$color_key)) {
          ?><?= $el ?> { border: <?= $settings->$width_key ?>px solid #<?= $settings->$color_key ?>; }<?php
        } elseif (isset($settings->$width_key)) {
          ?><?= $el ?> { border-width: <?= $settings->$width_key ?>px; }<?php
        } elseif (isset($settings->$color_key)) {
          ?><?= $el ?> { border-color: #<?= $settings->$color_key ?>; }<?php
        }

        $s = "{$setting_prefix}border_radius{$setting_suffix}";
        if ( isset( $settings->$s ) ) {
          ?><?= $el ?> { border-radius: <?= $settings->$s ?>px; }<?php
        }

        continue;
      }

      if ($setting_type=='box-shadow') {

        $s = "{$setting_prefix}box_shadow_enabled{$setting_suffix}";
        if (isset($settings->$s) && $settings->$s==='true') {

          $x_key = "{$setting_prefix}box_shadow_x{$setting_suffix}";
          $y_key = "{$setting_prefix}box_shadow_y{$setting_suffix}";
          $blur_key = "{$setting_prefix}box_shadow_blur{$setting_suffix}";
          $spread_key = "{$setting_prefix}box_shadow_spread{$setting_suffix}";

          $color_key = "{$setting_prefix}box_shadow_color{$setting_suffix}";
          $opacity_key = "{$setting_prefix}box_shadow_opacity{$setting_suffix}";
          $rgba = hex2rgba($settings->$color_key, $settings->$opacity_key);

          // offset-x | offset-y | blur-radius | spread-radius | color
          $rule = $settings->$x_key.'px '.$settings->$y_key.'px '.$settings->$blur_key.'px '
            .$settings->$spread_key.'px '.$rgba;

          ?><?= $el ?> {<?php
            foreach (['-webkit-', '-moz-', '-o-', ''] as $b) {
              ?><?= "{$b}box-shadow" ?>: <?= $rule ?>;<?php
            }
          ?>}<?php
        }

        continue;
      }

      // Icon

      if ($setting_type=='icon') {

        $s = "{$setting_prefix}icon_color{$setting_suffix}";
        if ( isset( $settings->$s ) ) {
          ?><?= $el ?> i { color: #<?= $settings->$s ?>; }<?php
        }

        $s = "{$setting_prefix}icon_size{$setting_suffix}";
        if ( isset( $settings->$s ) ) {
          ?><?= $el ?> i { font-size: <?= $settings->$s ?>px; }<?php
        }

        foreach (['', 'medium', 'responsive'] as $res) {

          $is_responsive = !empty($res);
          if ($is_responsive && !$global_settings->responsive_enabled) continue;

          $res_suffix = '';

          if ($is_responsive) {
            $res_suffix = "_{$res}";
            $breakpoint = "{$res}_breakpoint";
            ?>@media (max-width: <?= $global_settings->$breakpoint.'px' ?>) {<?php
          }

          ?><?= $el ?> {<?php
            foreach (['top', 'right', 'bottom', 'left'] as $dir) {
              // Padding
              $s = "{$setting_prefix}icon_padding{$setting_suffix}_{$dir}{$res_suffix}";
              if (!empty($settings->$s)) {
                ?><?= "padding-$dir" ?>: <?= $settings->$s ?>px;<?php
              }
            }
          ?>} <?php

          if ($is_responsive) { ?>}<?php }
        }

        continue;
      }

    } // For each setting type
  }
}
