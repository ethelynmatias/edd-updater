<?php

return [
  [
    'name' => 'themer-extension-focus-mode', // Name of the feature folder
    'title' => 'Themer Extension: Focus Mode',
    'default' => false // Optional: Disable feature by default
  ],
];
