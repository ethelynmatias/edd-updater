<?php

require_once __DIR__.'/../../themer-extensions/focus-mode/index.php';
