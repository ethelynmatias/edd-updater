=== BeaverDash ===
Requires at least: 4.0
Tested up to: 5.2.2
Requires PHP: 7
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags:

LearnDash integration for Beaver Builder

== Description ==

**BeaverDash** provides features to build LearnDash course, lesson, quiz and topic templates with the speed and ease of Beaver Builder.

== Installation ==

1. Install & activate in the admin: *Plugins -&gt; Add New -&gt; Upload Plugins*

== Changelog ==

= 1.2.8 =

Release Date: 2023-12-12

- Mark complete button: Fix issue with video progression
- Improve compatibility with PHP 8.2
- Update dependencies

= 1.2.7 =

Release Date: 2022-05-25

- Improves builder performances

= 1.2.6 =

Release Date: 2022-01-13

- Post Grid base module (Course/Lesson/Topic/Quiz/Certificate Grid)
  - Implement custom pagination that works with LearnDash permalinks
  - Ensure correct post order

= 1.2.4 =

Release Date: 2021-04-30

- Status module: If user has no access to lesson/topic/quiz, treat as "locked"

= 1.2.3 =

Release Date: 2021-04-19

- Add Lesson and Topic Navigation modules
- BetterDash modules with CSS: Manually enqueue styles on demand to ensure they're included in Beaver cache
- Video module: Ensure placeholder is replaced when no video exists

= 1.2.2 =

Release Date: 2020-12-10

- Improve "next post" logic from topic to first lesson quiz
- Update dependencies: plugin framework

= 1.2.1 =

Release Date: 2020-11-18

- Course Price module: Apply available LearnDash translations
- Update dependencies

= 1.1.9 =

Release Date: 2020-11-03

- Video module: Adds the possibility to play/pause a Vimeo video when the controls are disabled

= 1.1.8 =

Release Date: 2020-11-03

- Post Grid modules: Follow changes in native BB Post Grid module's settings behavior

= 1.1.7 =

Release Date: 2020-10-03

- Fix namespace issue in plugin updater

= 1.1.6 =

Release Date: 2020-09-29

- Video progression - Fix issue with the mark complete button not being disable/enable properly

= 1.1.5 =

Release Date: 2020-09-21

- Lesson/topic/quiz grid - Fixed orderby and order settings when course builder enabled
- Update dependencies

= 1.1.3 =

Release Date: 2020-08-14

- Post grid: In query filter, handle edge case when settings is not passed

= 1.1.2 =

Release Date: 2020-08-07

- Carbon library for date formatting and localization
  - Update dependencies
  - Convert code base to unique namespace, to ensure compatibility with other plugins that use a different version of the same library
- Drip date: Fix format

= 1.1.0 =

Release Date: 2020-08-03

- Address issue with undefined function for course grid activated

= 1.0.9 =

Release Date: 2020-06-04

- Post Grid: Fix "Limit to current" setting

= 1.0.8 =

Release Date: 2020-05-20

- Focus mode: Fix builder when editing focus mode parts

= 1.0.7 =

Release Date: 2020-04-30

- Enroll Button: Add support for when course is closed and the button is a link
- Quiz Grid: Add conditions to include (or not) all child quizzes, lesson/topic quizzes

= 1.0.5 =

Release Date: 2020-03-13

- Themer Extension: Focus Mode
  - Fix output buffering
  - Separate as optional feature, disabled by default

= 1.0.4 =

Release Date: 2020-02-04

- Post Grid visibility filter, Status module: Query performance improvements
- Course navigation: Detect current lesson when on a quizz page

= 1.0.3 =

Release Date: 2020-01-23

- Improve getting settings fields' prefix and suffix
- Post Grid: Improve filter query logic
- Remove setting to make "groups" post type public

= 1.0.1 =

Release Date: 2019-12-13

- Return early if BeaverBuilder is not installed
- Video module: Fix display issues

= 1.0.0 =

Release Date: 2019-11-22

- Organize features for plugin variants
- Course Progress Bar: Add units choice for width field
- Course Progress Bar: Add background color and gradient settings
- Course Progress Bar: Improve text and border settings
