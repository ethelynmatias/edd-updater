<?php

function beaverdash() {

  static $o;

  return isset($o) ? $o : ($o = new class {
    public $framework;
    public $plugin;
    public $loop;
    public $state = [
      'version' => BeaverDash_VER,
      'url' => BeaverDash_URL,
      'dir' => BeaverDash_DIR
    ];
  });
}

add_action('plugins_loaded', function() {
	
  // Get the path to the current plugin directory
  $pluginDirPath = plugin_dir_path(__FILE__);

  // Specify your plugin's specific file
  $jsonFilePath = $pluginDirPath . 'plugin-cloud-settings.json';
  $jsonContent = file_get_contents($jsonFilePath);

  if (!file_exists($jsonFilePath)) {
	  echo "File identifier does not exist, please contact support.";
	  exit;
  }
  
  $itemId = null;
  if ($jsonContent === false) {
    // Handle error if the file could not be read
	  echo "Cannot read file, please contact support";
	  exit;
    
  } else {
     // Decode the JSON content into a PHP associative array
    $data = json_decode($jsonContent, true);

    $itemId = $data['pluginId'];
  }
  
  if ($itemId === null) {
	  echo "Item is not recognize, please contact support";
	  exit;
  }

  $framework = tangible();

  $beaverdash = beaverdash();
  $beaverdash->framework = $framework;
  $beaverdash->plugin = $framework->register_plugin([
    'name' => 'beaverdash',
    'title' => 'BeaverDash',
    'setting_prefix' => 'bdash',

    'file_path' => BeaverDash_FILE,
    'version' => BeaverDash_VER,
    'item_id' => $itemId,

    'dependencies' => [
      'sfwd-lms/sfwd_lms.php' => [
        'title' => 'LearnDash',
        'url' => 'https://www.learndash.com/',
        'fallback_check' => function() { return defined('LEARNDASH_VERSION'); }
      ],
      'bb-plugin/fl-builder.php' => [
        'title' => 'Beaver Builder',
        'url' => 'https://www.wpbeaverbuilder.com/?fla=1682',
        'fallback_check' => function() { return class_exists('FLBuilder'); }
      ],
    ],

    'settings_css' => plugins_url('settings/assets/style.css', __FILE__),
    'settings_js' => plugins_url('settings/assets/script.js', __FILE__),
    'settings_title_callback' => '\BeaverDash\Settings\settings_title_callback',
    'setting_tabs' => [
      'doc' => [
        'title' => 'Documentation',
        'callback' => '\BeaverDash\Settings\render_documentation',
      ],
      // No settings currently
      // 'settings' => [
      //   'title' => 'Settings',
      //   'callback' => '\BeaverDash\Settings\render_settings',
      // ],
      'recommend' => [
        'title' => 'Recommendations',
        'callback' => '\BeaverDash\Settings\render_recommend',
      ],
    ],

    'admin_notice' => '\BeaverDash\Settings\admin_notice',

    'recommended_products' => [
      'external' => [
        [
          'title' => 'Beaver Builder',
          'description' => 'Upgrading to a paid version of Beaver Builder will get you additional modules, expert support, pre-made layout templates, and the useful ability to save, export, reuse full-page layouts, rows, and modules.',
          'url' => "https://www.wpbeaverbuilder.com/pricing/?fla=1682",
          'affiliate' => true,
        ],
        [
          'title' => 'Beaver Themer',
          'description' => 'Beaver Themer lets you create layouts for archive pages, post types, 404 and search pages, and create parts like headers and footers. Field connections allow you to connect your layouts to the data inside each type of template.',
          'url' => "https://www.wpbeaverbuilder.com/beaver-themer/?fla=1682",
          'affiliate' => true,
        ],
        [
          'title' => 'Ultimate Addon for Beaver Builder',
          'description' => 'Ultimate Addons is a premium extension for Beaver Builder that adds 45+ modules, 250+ templates and works on top of any WordPress theme.',
          'url' => "http://www.ultimatebeaver.com/?bsf=312",
          'affiliate' => true,
        ]
      ],
      'tangible' => [
        'learndash-materials',
        'memberdash',
      ],
    ],
  ]);

  $beaverdash->plugin->register_features([

    // Title of settings tab (optional)
    'title' => 'Features',

    // Path to features folder
    'path' => __DIR__.'/features',

    // Array of feature definitions
    'features' => require_once __DIR__.'/features/index.php'

  ]);
});
